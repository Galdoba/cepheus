package main

import (
	"fmt"
	"io"
	"os"
	"strings"
	"time"

	"github.com/charmbracelet/bubbles/list"
	"github.com/charmbracelet/bubbles/table"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type model struct {
	choices  []string         // items on the to-do list
	cursor   int              // which to-do list item our cursor is pointing at
	selected map[int]struct{} // which to-do items are selected
	screen   int
	data     map[int]string
	lister   list.Model
	tabler   table.Model
}

func initialModel() model {
	data := make(map[int]string)
	data[1] = "aaa"
	data[2] = "BBB"
	data[3] = "CCC"
	data[4] = "DD"
	data[5] = "EE"
	data[6] = "aFF"
	data[7] = "aGG"

	return model{
		data:   data,
		screen: 1,
		lister: createList(data),
	}
}

func createList(data map[int]string) list.Model {
	items := []list.Item{}
	for _, entry := range listData(data) {
		items = append(items, item(entry))
	}

	var defaultWidth = 50
	var listHeight = 50

	l := list.New(items, itemDelegate{}, defaultWidth, listHeight)
	l.Title = "This is LIST"

	//	l.Styles.Title = titleStyle
	//	l.Styles.PaginationStyle = paginationStyle
	//	l.Styles.HelpStyle = helpStyle
	return l
}

func createTable(data map[int]string) table.Model {
	tableBuffer := ""
	sep := "|||"
	for i := 0; i < 100; i++ {
		switch i % 2 {
		case 0:
			tableBuffer += data[i] + sep
		case 1:
			tableBuffer += data[i] + "\n"
		}
	}
	table := table.New(
		table.WithColumns([]table.Column{
			{Title: "EVEN", Width: 50},
			{Title: "ODD ", Width: 50},
		}),
	)
	table.FromValues(tableBuffer, sep)
	return table
}

func (m model) Init() tea.Cmd {
	// Just return `nil`, which means "no I/O right now, please."

	return nil
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	// 	m.list.SetWidth(msg.Width)
	// 	return m, nil

	case tea.KeyMsg:
		switch m.screen {
		case 1:
			m.messageOnScreen1(msg)
			m.lister, cmd = m.lister.Update(msg)
			//return m.keyMessageOnScreen0(msg)
		case 2:
			m.messageOnScreen2(msg)
			m.lister, cmd = m.lister.Update(msg)

		}
		// switch keypress := msg.String(); keypress {
		// case "q", "ctrl+c":
		// 	return m, tea.Quit
		// case "enter":
		// 	return m, nil
		// }
	}

	return m, cmd

}

func (m *model) messageOnScreen1(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	// 	m.list.SetWidth(msg.Width)
	// 	return m, nil
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "q", "ctrl+c":
			return m, tea.Quit
		case "enter":
			m.data = addData(m.data)
			entry := item(m.data[len(m.data)])
			cmd = m.lister.InsertItem(len(m.lister.Items())+1, entry)
		case "2":
			m.screen = 2
			m.tabler = createTable(m.data)
		}
	}

	//m.lister, cmd = m.lister.Update(msg)
	return m, cmd
}

func (m *model) messageOnScreen2(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	// 	m.list.SetWidth(msg.Width)
	// 	return m, nil
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "q", "ctrl+c":
			return m, tea.Quit
		case "enter":
			//m.data = deleteData(m.data)
			// entry := item("new data: " + time.Now().Format(time.DateTime))
			// cmd = m.lister.InsertItem(len(m.lister.Items())+1, entry)
			m.tabler.SetCursor(2)
			c := m.tabler.Cursor()

			row := m.tabler.Rows()[c]
			val := row[1]
			for k, v := range m.data {
				if v == val {
					m.data[k] = "PPPP"
				}
			}

		case "1":
			m.screen = 1
			m.lister = createList(m.data)
		}
	}

	m.lister, cmd = m.lister.Update(msg)
	return m, cmd
}

func addData(data map[int]string) map[int]string {

	data[len(data)+1] = "new data: " + time.Now().Format(time.DateTime)
	return data
}

func deleteData(data map[int]string) map[int]string {
	delete(data, len(data))
	return data
}

func (m model) View() string {
	s := "me header: screen " + fmt.Sprintf("%v\n", m.screen)
	switch m.screen {
	// case 1:
	// 	for _, bar := range listData(m.data) {
	// 		s += bar + "\n"
	// 	}
	case 1:
		s += m.lister.View()
	// for _, bar := range listData(m.data) {
	// 	s += "list 2: " + bar + "\n"
	// }
	case 2:
		s += m.tabler.View()
	}

	// Send the UI for rendering
	return s
}

func main() {
	p := tea.NewProgram(initialModel())
	if _, err := p.Run(); err != nil {
		fmt.Printf("Alas, there's been an error: %v", err)
		os.Exit(1)
	}
}

// //////LIST

var (
	itemStyle         = lipgloss.NewStyle().PaddingLeft(2) //.PaddingLeft(4)
	selectedItemStyle = lipgloss.NewStyle()                //.PaddingLeft(2).Foreground(lipgloss.Color("126"))

// titleStyle        = lipgloss.NewStyle().MarginLeft(8)
// paginationStyle   = list.DefaultStyles().PaginationStyle.PaddingLeft(4)
// helpStyle         = list.DefaultStyles().HelpStyle.PaddingLeft(4).PaddingBottom(1)
// quitTextStyle = lipgloss.NewStyle().Margin(1, 0, 2, 4)
)

type item string

func (i item) FilterValue() string { return "" }

type itemDelegate struct{}

func (d itemDelegate) Height() int                             { return 1 }
func (d itemDelegate) Spacing() int                            { return 0 }
func (d itemDelegate) Update(_ tea.Msg, _ *list.Model) tea.Cmd { return nil }
func (d itemDelegate) Render(w io.Writer, m list.Model, index int, listItem list.Item) {
	i, ok := listItem.(item)
	if !ok {
		return
	}

	str := fmt.Sprintf("%d. %s", index+1, i)

	fn := itemStyle.Render
	if index == m.Index() {
		fn = func(s ...string) string {
			return selectedItemStyle.Render("> " + strings.Join(s, " "))
		}
	}

	fmt.Fprint(w, fn(str))
}

func listData(data map[int]string) []string {
	out := []string{}
	for i := 0; i < 100; i++ {
		if val, ok := data[i]; ok {
			out = append(out, fmt.Sprintf("%v", val))
		}
	}
	return out
}
