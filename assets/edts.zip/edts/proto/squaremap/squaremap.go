package squaremap

type squaremap[T any] struct {
	maps    []map[uint]T
	zeroval T
}

func new[T any](rows, cols uint, zeroValue T) *squaremap[T] {
	sq := squaremap[T]{}
	for i := uint(0); i < rows; i++ {
		sq.maps = append(sq.maps, make(map[uint]T))
		// for j := uint(0); j < cols; j++ {
		// 	sq.maps[i][j] = zeroValue
		// }
	}
	sq.zeroval = zeroValue
	return &sq
}

func (sq *squaremap[T]) Get(r, c uint) (T, bool) {
	if r > uint(len(sq.maps)-1) {
		panic("squaremap rows out of bounds")
	}
	// if c > uint(len(sq.maps[0])-1) {
	// 	panic("squaremap cols out of bounds")
	// }
	if val, ok := sq.maps[r][c]; ok {
		return val, ok
	}
	return sq.zeroval, false
}

func (sq *squaremap[T]) Set(r, c uint, value T) {
	if r > uint(len(sq.maps)-1) {
		panic("squaremap rows out of bounds")
	}
	if c > uint(len(sq.maps[0])-1) {
		panic("squaremap cols out of bounds")
	}
	sq.maps[r][c] = value
}
