package squaremap

import (
	"fmt"
	"testing"
)

func Test_new(t *testing.T) {
	sq := new[string](3, 3, "no val")
	sq.Set(0, 2, "+++")
	fmt.Println(sq)

	sq2 := new(3, 3, 6)
	sq2.Set(0, 2, 9)
	fmt.Println(sq2)

	sq3 := new[myInterf](3, 3, nil)
	sq3.Set(0, 2, &myType{"+++", 6})
	out, ok := sq3.Get(0, 2)
	fmt.Println(ok)
	fmt.Println(sq3)
	fmt.Println(out)
	fmt.Println(out.String())
	fmt.Println(out.Count())

}

type myType struct {
	val  string
	val2 int
}

type myInterf interface {
	fmt.Stringer
	Count() int
}

func (mt *myType) String() string {
	return fmt.Sprintf("value is: %v %v", mt.val, mt.val2)
}

func (mt *myType) Count() int {
	return mt.val2
}
