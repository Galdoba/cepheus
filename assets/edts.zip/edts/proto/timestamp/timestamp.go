package timestamp

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"
)

func Now() string {
	t := time.Now()
	tf := t.Format("060102150405.9999999")
	dp := strings.Split(tf, ".")
	out := dp[0]
	micr := strings.Split(dp[1], "")
	m := strings.Join(micr[0:3], "")
	out += m
	return out
}

func GetFrom(ts string) (time.Time, error) {
	re := regexp.MustCompile(`([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([.0-9]{3})(.*)`)
	submatch := re.FindStringSubmatch(ts)
	if len(submatch) < 8 {
		return time.Time{}, fmt.Errorf("failed to parse data from '%v'", ts)
	}
	t := time.Time{}
	t = t.AddDate(unsafeAtoi(submatch[1])+1999, unsafeAtoi(submatch[2])-1, unsafeAtoi(submatch[3])-1)
	t = t.Add(time.Duration(unsafeAtoi(submatch[4])) * time.Hour)
	t = t.Add(time.Duration(unsafeAtoi(submatch[5])) * time.Minute)
	t = t.Add(time.Duration(unsafeAtoi(submatch[6])) * time.Second)
	t = t.Add(time.Duration(unsafeAtoi(submatch[7])) * time.Millisecond)
	return t, nil
}

func unsafeAtoi(s string) int {
	i, _ := strconv.Atoi(s)
	return i
}

func NowInt64() int64 {
	ts := Now()
	i64, err := strconv.ParseInt(ts, 10, 64)
	if err != nil {
		panic("timestamp.NowInt64(): " + err.Error())
	}
	return i64
}
