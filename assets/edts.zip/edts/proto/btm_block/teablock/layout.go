package teablock

import (
	"fmt"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type Layout struct {
	stack    []coords
	byCoords map[coords]*Block
	active   int
}

type coords struct {
	vertical   int
	horisontal int
}

func Coordinates(vertical, horisontal int) coords {
	return coords{vertical, horisontal}
}

func nextHorisontal(crd coords) coords {
	crd.horisontal++
	return crd
}

func nextVertical(crd coords) coords {
	crd.horisontal = 0
	crd.vertical++
	return crd
}

const (
	invalid  = 0
	start    = 1
	right    = 2
	down     = 3
	end      = 4
	notFound = 5
)

func (l *Layout) nextDirection(crd coords) int {
	found := false
	for i, have := range l.stack {
		switch crd == have {
		case true:
			found = true
		case false:
			continue
		}
		if i == len(l.stack)-1 {
			return end
		}
		if nextHorisontal(have) == l.stack[i+1] {
			return right
		}
		if nextVertical(have) == l.stack[i+1] {
			return down
		}
	}
	if !found {
		return notFound
	}
	return invalid
}

func NewLayout() *Layout {
	l := Layout{}
	l.byCoords = make(map[coords]*Block)
	l.active = -1
	return &l
}

func (l *Layout) Blocks() []*Block {
	blks := []*Block{}
	for _, coords := range l.stack {
		blks = append(blks, l.byCoords[coords])
	}
	l.active = -1
	return blks
}

func (l *Layout) Next() *Block {
	l.active++
	if bl, ok := l.byCoords[l.stack[l.active]]; ok {
		return bl
	}
	l.active = -1
	return nil
}

func (l *Layout) AddHorisontal(bl *Block) {
	crd := coords{}
	if len(l.stack) > 0 {
		crd = l.stack[len(l.stack)-1]
	}
	crd = nextHorisontal(crd)
	l.byCoords[crd] = bl
	l.stack = append(l.stack, crd)
}

func (l *Layout) AddVertical(bl *Block) {
	crd := coords{}
	if len(l.stack) > 0 {
		crd = l.stack[len(l.stack)-1]
	}
	crd = nextVertical(crd)
	l.byCoords[crd] = bl
	l.stack = append(l.stack, crd)
}

func (l *Layout) Swap(newModel *tea.Model, crd coords) error {
	for c := range l.byCoords {
		if c == crd {
			l.byCoords[crd].TeaModel = *newModel
			return nil
		}
	}
	return fmt.Errorf("model coordinates (%v) not found", crd)
}

func (l *Layout) Init() tea.Cmd {
	return nil
}

func (l *Layout) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	for _, bl := range l.Blocks() {
		var cmd tea.Cmd
		switch bl.inFocus {
		case true:
			blM := bl.TeaModel
			blM, cmd = blM.Update(msg)
			bl.TeaModel = blM
		case false:

			continue
		}

		if cmd != nil {
			cmds = append(cmds, cmd)
		}
	}
	return l, tea.Batch(cmds...)

}

func (l *Layout) View() string {
	layout := [][]string{}
	layout = append(layout, []string{})
	currentRow := 0
	direction := start
	for _, crd := range l.stack {
		switch direction {
		case start:
			layout[0] = append(layout[0], l.byCoords[crd].View())
		case right:
			layout[currentRow] = append(layout[currentRow], l.byCoords[crd].View())
		case down:
			layout = append(layout, []string{})
			currentRow++
			layout[currentRow] = append(layout[currentRow], l.byCoords[crd].View())
		case end:
		}
		direction = l.nextDirection(crd)
	}
	s := ""
	column := []string{}
	for _, row := range layout {
		column = append(column, lipgloss.JoinHorizontal(lipgloss.Left, row...))
	}
	s = lipgloss.JoinVertical(lipgloss.Left, column...) + "\n"
	return s
}
