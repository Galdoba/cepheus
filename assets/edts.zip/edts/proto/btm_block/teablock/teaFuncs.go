package teablock

import (
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/x/ansi"
)

// /////////////////
func (bl *Block) Init() tea.Cmd {
	return nil
}

func (bl *Block) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	// switch bl.inFocus {
	// case true:
	bl.TeaModel, cmd = bl.TeaModel.Update(msg)
	// case false:
	// }
	return bl, cmd
}

func (bl *Block) View() string {
	internal := bl.TeaModel.View()
	lines := strings.Split(internal, "\n")
	trimmed := []string{}
	//trim horisontal
	for _, line := range lines {
		trimmed = append(trimmed, ansi.Truncate(line, bl.contentWidth, bl.trimHorisontal))
	}
	//trim vertical
	if len(trimmed) > bl.contentHeight-1 {
		trimmed = trimmed[0 : bl.contentHeight-1]
		trimmerLine := trimmerLine(bl.trimHorisontal, bl.trimVertical, bl.contentWidth)
		trimmed = append(trimmed, ansi.Truncate(trimmerLine, bl.contentWidth, bl.trimHorisontal))
	}
	wrapped := strings.Join(trimmed, "\n")
	return bl.Style.Render(wrapped) // + "\n"
}

func trimmerLine(trHor, trVert string, width int) string {
	trimmer := ""
	for len(strings.Split(trimmer, "")) < width-len(strings.Split(trHor, ""))-len(strings.Split(trVert, ""))-3 {
		trimmer += "   " + trVert
	}
	return trimmer
}
