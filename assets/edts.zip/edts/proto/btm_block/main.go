package main

import (
	"fmt"
	"strings"
	"time"

	"github.com/Galdoba/edts/proto/btm_block/teablock"
	"github.com/charmbracelet/bubbles/help"
	"github.com/charmbracelet/bubbles/key"
	"github.com/charmbracelet/bubbles/progress"
	"github.com/charmbracelet/bubbles/textarea"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

func main() {
	m1 := initialModel()
	m2 := initialModel()
	m3 := initialModel()
	m2.textarea.Blur()
	m3.textarea.Blur()
	m2.textarea.Prompt = "aasd"
	bll := teablock.Confine(m1, 30, 40,
		//teablock.WithTrimmers(teablock.NoTrimmer, teablock.NoTrimmer),
		teablock.WithStyle(teablock.DefaultStyle.BorderForeground(lipgloss.Color("2")).Border(teablock.DefaultStyle.GetBorderStyle(), true, false, false, true)),
	)
	blr := teablock.Confine(m2, 20, 30,
		//teablock.WithTrimmers(teablock.NoTrimmer, teablock.NoTrimmer),
		teablock.WithStyle(teablock.DefaultStyle.BorderForeground(lipgloss.Color("3")).Border(teablock.DefaultStyle.GetBorderStyle(), false, true, false, false)),
		teablock.WithFocus(false),
	)
	bld := teablock.Confine(m3, 300, 20,
		//teablock.WithTrimmers(teablock.NoTrimmer, teablock.NoTrimmer),
		teablock.WithStyle(teablock.DefaultStyle.BorderForeground(lipgloss.Color("4"))),
	)

	// tckM := teablock.Confine(TickModel(), 80, 20,
	// 	teablock.WithStyle(teablock.DefaultStyle.BorderForeground(lipgloss.Color("4"))),
	// 	teablock.WithFocus(false),
	// )

	lay := teablock.NewLayout()
	lay.AddHorisontal(bll)
	lay.AddHorisontal(blr)
	lay.AddVertical(bld)
	err := lay.Swap(&blr.TeaModel, teablock.Coordinates(1, 0))
	if err != nil {
		panic(err.Error())
	}
	//bl.Focus()
	p := tea.NewProgram(lay)
	fmt.Println("         |         |         |         |         |         |         |         |         |")
	p.Run()

}

func filter(teaModel tea.Model, msg tea.Msg) tea.Msg {
	if _, ok := msg.(tea.QuitMsg); !ok {
		return msg
	}

	m := teaModel.(modelText)
	if m.hasChanges {
		return nil
	}

	return msg
}

type modelText struct {
	textarea   textarea.Model
	help       help.Model
	keymap     keymap
	saveText   string
	hasChanges bool
	quitting   bool
}

type keymap struct {
	save key.Binding
	quit key.Binding
}

func initialModel() modelText {
	ti := textarea.New()
	ti.Placeholder = "Only the best words"
	ti.Focus()

	return modelText{
		textarea: ti,
		help:     help.New(),
		keymap: keymap{
			save: key.NewBinding(
				key.WithKeys("ctrl+s"),
				key.WithHelp("ctrl+s", "save"),
			),
			quit: key.NewBinding(
				key.WithKeys("esc", "ctrl+c"),
				key.WithHelp("esc", "quit"),
			),
		},
	}
}

func (m modelText) Init() tea.Cmd {
	return textarea.Blink
}

func (m modelText) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if m.quitting {
		return m.updatePromptView(msg)
	}

	return m.updateTextView(msg)
}

func (m modelText) updateTextView(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	var cmd tea.Cmd

	switch msg := msg.(type) {
	case tea.KeyMsg:
		m.saveText = ""
		switch {
		case key.Matches(msg, m.keymap.save):
			m.saveText = "Changes saved!"
			m.hasChanges = false
		case key.Matches(msg, m.keymap.quit):
			m.quitting = true
			return m, tea.Quit
		case msg.Type == tea.KeyRunes:
			m.saveText = ""
			m.hasChanges = true
			fallthrough
		default:
			if !m.textarea.Focused() {
				cmd = m.textarea.Focus()
				cmds = append(cmds, cmd)
			}
		}
	}
	m.textarea, cmd = m.textarea.Update(msg)
	cmds = append(cmds, cmd)
	return m, tea.Batch(cmds...)
}

func (m modelText) updatePromptView(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.KeyMsg:
		// For simplicity's sake, we'll treat any key besides "y" as "no"
		if key.Matches(msg, m.keymap.quit) || msg.String() == "y" {
			m.hasChanges = false
			return m, tea.Quit
		}
		m.quitting = false
	}

	return m, nil
}

func (m modelText) View() string {
	if m.quitting {
		if m.hasChanges {
			text := lipgloss.JoinHorizontal(lipgloss.Top, "You have unsaved changes. Quit without saving?", choiceStyle.Render("[yn]"))
			return quitViewStyle.Render(text)
		}
		return "Very important, thank you\n"
	}

	helpView := m.help.ShortHelpView([]key.Binding{
		m.keymap.save,
		m.keymap.quit,
	})

	return fmt.Sprintf(
		"\nType some importasdl;fkasdkf;asdkfaksd;fkasdfkasdkf;askdl;fk';asdkf;asasdfjasdlfjasdlkjflasdkjfl;asdjl;fjasdlfjl;asdjflasdjl;fjasldjfasjdl;fjasldfjlasdjfl;ajsl;dfjl;asdjflasjdfl;asjl;dfjl;sjfldk;fkasd;fk';asdkf;asdkfkasd;fk;asdkf;asd;fkas;dkf;askdfkasd;fka;sdkf;asdkf;aksd;fkas;dfk;asdkfant things.\n\n%s\n\n %s\n %s",
		m.textarea.View(),
		saveTextStyle.Render(m.saveText),
		helpView,
	) + "\n\n"
}

var (
	choiceStyle   = lipgloss.NewStyle().PaddingLeft(1).Foreground(lipgloss.Color("241"))
	saveTextStyle = lipgloss.NewStyle().Foreground(lipgloss.Color("170"))
	quitViewStyle = lipgloss.NewStyle().Padding(1).Border(lipgloss.RoundedBorder()).BorderForeground(lipgloss.Color("170"))
)

// ////////////////////
const (
	padding  = 2
	maxWidth = 80
)

var helpStyle = lipgloss.NewStyle().Foreground(lipgloss.Color("#626262")).Render

type tickMsg time.Time

type model struct {
	percent  float64
	progress progress.Model
}

func TickModel() model {
	return model{0.0, progress.Model{}}
}

func (m model) Init() tea.Cmd {
	return tickCmd()
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.KeyMsg:
		return m, tea.Quit

	case tea.WindowSizeMsg:
		m.progress.Width = msg.Width - padding*2 - 4
		if m.progress.Width > maxWidth {
			m.progress.Width = maxWidth
		}
		return m, nil

	case tickMsg:
		m.percent += 0.25
		if m.percent > 1.0 {
			m.percent = 1.0
			return m, tea.Quit
		}
		return m, tickCmd()

	default:
		return m, nil
	}
}

func (m model) View() string {
	pad := strings.Repeat(" ", padding)
	return "\n" +
		pad + m.progress.ViewAs(m.percent) + "\n\n" +
		pad + helpStyle("Press any key to quit")
}

func tickCmd() tea.Cmd {
	return tea.Tick(time.Second, func(t time.Time) tea.Msg {
		return tickMsg(t)
	})
}
