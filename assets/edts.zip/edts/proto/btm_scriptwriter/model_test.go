package btmscriptwriter

import (
	"fmt"
	"testing"
)

func TestNew(t *testing.T) {

	// sc := New()
	// sc.AddSource("file1.mp4", "video")
	// sc.AddSource("file2.srt", "subtitle")
	// //sc.AddSource("file3.srt", "hardsub")
	// sc.IN_DIR = `/home/pemaltynov/IN/`
	// sc.PROC_DIR = `/home/pemaltynov/IN/_IN_PROGRESS/`
	// fmt.Println(sc.Compile())

	fc := newFC()
	fc.addStatement(newStatement(
		Keys("0:v:0"),
		Statement("scale=1920:-2"),
		Statement("setsar=(1/1)"),
		Statement("unsharp=3:3:0.3:3:3:0"),
		MapOutput("video"),
	))
	fc.addStatement(newStatement(
		Keys("0:a:0"),
		Statement("aresample=48000"),
		Statement("atempo=25/(24)"),
		MapOutput("audio"),
	))
	fmt.Println(fc)

	// scale=1920:-2,setsar=1/1,unsharp=3:3:0.3:3:3:0,pad=1920:1080:-1:-1
}
