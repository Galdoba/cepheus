package btmscriptwriter

type ScriptWriter struct {
	Script     string
	IN_DIR     string
	PROC_DIR   string
	TARG_DIR   string
	ARCHVE_DIR string
	Input      []inputValue
	OutBase    string
	HSUB       hsubValue
	beforeCMDS []string
	afterCMDS  []string
	errors     []error
	script     []string
	command    string
}

func New() *ScriptWriter {
	return &ScriptWriter{}
}

/*
declare input
declare outbase
declare paths
declare inputByType
*/

/*
input
FILE1="V_poteryannyh_zemlyah--FILM--InTheLostLands_HD25f_RUS20LR_RUS51LRCLfeLsRs_LOC.mxf"

outbase
OUTBASE="V_poteryannyh_zemlyah"

destination
ROOT="/mnt/pemaltynov"
EDIT="/ROOT/EDIT/25_04_21"
EDIT_PATH="${ROOT}${EDIT}"

archive
ARCHIVE_PATH="/mnt/pemaltynov/ROOT/IN/_VOLGA_FILM"


FC_AUD="aresample=48000,atempo=25/(25)"
AUDIO_OUT1="_AUDIORUS51"
HSUBFILE="/home/pemaltynov/IN/V_poteryannyh_zemlyah--FILM--In_the_Lost_Land_Rus_Forced_25fps.srt"
HSUB="subtitles=filename=${HSUBFILE}:original_size=1920x1080:force_style='FontName=Segoe UI,Fontsize=19.4,PrimaryColour='&H00EBEBEB',SecondaryColour='&H000000FF',OutlineColour='&H00000000',BackColour='&H80000000',Underline=0,StrikeOut=0,ScaleX=1,ScaleY=1,Spacing=0,Angle=0,BorderStyle=1,Outline=0.5,Shadow=0,Alignment=2,MarginL=5,MarginR=5,MarginV=40,Encoding=1',"
REV="_HD"
SRT="V_poteryannyh_zemlyah--FILM--In_the_Lost_Land_Rus_25fps.srt"
mkdir -p ${ARCHIVE_PATH}/_DONE/${OUTBASE}
mkdir -p ${EDIT_PATH}
clear && mv /home/pemaltynov/IN/${FILE} /home/pemaltynov/IN/_IN_PROGRESS/  && fflite -r 25 -i /home/pemaltynov/IN/_IN_PROGRESS/${FILE} \
-filter_complex "[0:v:0]${HSUB}split=2[vidHD][inProxy]; [inProxy]scale=iw/2:ih, setsar=(1/1)*2[vidHD_pr]; [0:a:2][0:a:3][0:a:4][0:a:5][0:a:6][0:a:7]amerge=inputs=6,${FC_AUD}[arus_in];  [arus_in]asplit=2[arus][arus_pr]" \
  -map "[vidHD]" -c:v libx264 -preset medium -crf 16 -pix_fmt yuv420p -g 0 -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}.mp4  \
  -map "[vidHD_pr]" -c:v libx264 -x264opts interlaced=1 -preset superfast -pix_fmt yuv420p  -b:v 2000k -maxrate 2000k -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}_proxy.mp4  \
  -map "[arus]" -c:a alac -compression_level 0 -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}${AUDIO_OUT1}.m4a \
  -map "[arus_pr]" -c:a ac3 -b:a 128k ${EDIT_PATH}/${OUTBASE}${REV}${AUDIO_OUT1}_proxy.ac3 \
&& touch ${EDIT_PATH}/${OUTBASE}.ready \
&& echo "${EDIT}/${OUTBASE}.ready" > /home/pemaltynov/IN/notifications/${OUTBASE}.done \
&& mv /home/pemaltynov/IN/_IN_PROGRESS/${FILE} /home/pemaltynov/IN/_DONE/  && at now + 10 hours <<< "mv /home/pemaltynov/IN/_DONE/${FILE} ${ARCHIVE_PATH}/_DONE/${OUTBASE}" \
&& cp /home/pemaltynov/IN/${SRT} ${EDIT_PATH}/${OUTBASE}${REV}.srt && mv /home/pemaltynov/IN/${SRT} ${ARCHIVE_PATH}/_DONE/${OUTBASE} && clear && mv "$0" /home/pemaltynov/IN/_DONE/bash/
*/

type inputValue struct {
	name     string
	position int
	source   []string
}

type hsubValue struct {
	name    string
	fc_text string
}
