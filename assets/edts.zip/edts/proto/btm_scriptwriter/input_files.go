package btmscriptwriter

import "fmt"

const (
	source_tag_video    = "video"
	source_tag_audio    = "audio"
	source_tag_subtitle = "subtitle"
	source_tag_hardsub  = "hardsub"
)

func (sc *ScriptWriter) AddSource(name string, tags ...string) {
	input := inputValue{}
	input.name = name
	input.source = tags
	input.position = -1
	if err := validateInput(input); err != nil {
		sc.errors = append(sc.errors, fmt.Errorf("source '%v' injection: %v", name, err))
	}
	sc.Input = append(sc.Input, input)
}

func validateInput(input inputValue) error {
	if input.name == "" {
		return fmt.Errorf("no input name provided")
	}
	tagmap := make(map[string]int)
	for i, tag := range input.source {
		switch tag {
		case source_tag_audio, source_tag_video, source_tag_hardsub, source_tag_subtitle:
			tagmap[tag]++
			if tagmap[tag] > 1 {
				return fmt.Errorf("repeating tag %v", tag)
			}
		case "":
			return fmt.Errorf("blank tag (%v)", i)
		default:
			return fmt.Errorf("unknown tag '%v'", tag)
		}
	}
	return nil
}
