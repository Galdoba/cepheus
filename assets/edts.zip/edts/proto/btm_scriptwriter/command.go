package btmscriptwriter

type CommandNode struct {
	main     string
	onSucces *CommandNode
	onFail   *CommandNode
	next     *CommandNode
}

func Command(str string) *CommandNode {
	cn := CommandNode{}
	cn.main = str
	return &cn
}

func (cn *CommandNode) OnSuccess(cmd *CommandNode) *CommandNode {
	cn.onSucces = cmd
	return cn
}

func (cn *CommandNode) OnFail(cmd *CommandNode) *CommandNode {
	cn.onFail = cmd
	return cn
}

func (cn *CommandNode) Next(cmd *CommandNode) *CommandNode {
	cn.next = cmd
	return cn
}
