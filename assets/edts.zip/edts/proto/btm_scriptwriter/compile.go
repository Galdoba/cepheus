package btmscriptwriter

import (
	"fmt"
	"strings"
)

func (sc *ScriptWriter) Compile() string {

	sc.script = binbash()
	sc.command = "ffmpeg "
	fcomplex := ""
	sc.declareInput()
	sc.setPreparationCommansds()
	//sc.beforeCMDS = append(sc.beforeCMDS, fmt.Sprintf(`mv %v%v %v | continue`, sc.IN_DIR, input, sc.PROC_DIR))
	fcomplex = sc.filter_complex()
	sc.script = append(sc.script, "#")
	sc.script = append(sc.script, sc.command+fcomplex)
	switch len(sc.errors) {
	case 0:
	default:
		sc.script = append(sc.script, "#")
		sc.script = append(sc.script, fmt.Sprintf("#compiler met %v errors:", len(sc.errors)))
		for i, err := range sc.errors {
			sc.script = append(sc.script, fmt.Sprintf("#  %v: %v", i+1, err))
		}
	}
	return strings.Join(sc.script, "\n")
}

func (sc *ScriptWriter) declareInput() {
	added := 0
	for i, input := range sc.Input {
		sc.script = append(sc.script, fmt.Sprintf(`FILE%v="%v"        #source of %v`, i, input.name, input.source))
		if contains(input.source, "video", "audio") {
			sc.command += fmt.Sprintf("-i %v ", sc.PROC_DIR+input.name)
			sc.Input[i].position = added
			added++
		}
		sc.beforeCMDS = append(sc.beforeCMDS, fmt.Sprintf(`mv %v%v %v | continue`, sc.IN_DIR, input.name, sc.PROC_DIR))
	}
}

func (sc *ScriptWriter) setPreparationCommansds() {
	sc.script = append(sc.script, "#")
	for _, before := range sc.beforeCMDS {
		sc.script = append(sc.script, before)
	}
}

func (sc *ScriptWriter) filter_complex() string {
	fc := newFC()
	//hardsub video  audio
	for _, input := range filteredInputs(sc.Input, "video") {
		stmnt := newStatement(
			Keys(fmt.Sprintf("%v:v:0", input.position)),
			Statement("setsar=(1/1)"),
			MapOutput("video"),
		)
		stmnt.statements = append(stmnt.statements, "scale=1920:1080:0:-1")
		for _, hsInput := range filteredInputs(sc.Input, "hardsub") {
			stmnt.statements = append(stmnt.statements, fmt.Sprintf("subtitles=filename=%v:original_size=1920x1080:force_style='FontName=Segoe UI,Fontsize=19.4,PrimaryColour='&H00EBEBEB',SecondaryColour='&H000000FF',OutlineColour='&H00000000',BackColour='&H80000000',Underline=0,StrikeOut=0,ScaleX=1,ScaleY=1,Spacing=0,Angle=0,BorderStyle=1,Outline=0.5,Shadow=0,Alignment=2,MarginL=5,MarginR=5,MarginV=40,Encoding=1'", sc.PROC_DIR+hsInput.name))
		}
		fc.addStatement(stmnt)
	}
	audioSources := filteredInputs(sc.Input, "audio")
	keys := []string{}
	for _, src := range audioSources {
		keys = append(keys, fmt.Sprintf("%v:a:0", src.position))
	}
	// stmnt := newStatement(
	// 	Keys(keys...),
	// 	MapOutput("audio"),
	// )

	return fc.String()
}

/*
subtitles=filename=${HSUBFILE}:original_size=1920x1080:force_style='FontName=Segoe UI,Fontsize=19.4,PrimaryColour='&H00EBEBEB',SecondaryColour='&H000000FF',OutlineColour='&H00000000',BackColour='&H80000000',Underline=0,StrikeOut=0,ScaleX=1,ScaleY=1,Spacing=0,Angle=0,BorderStyle=1,Outline=0.5,Shadow=0,Alignment=2,MarginL=5,MarginR=5,MarginV=40,Encoding=1'
*/

func binbash() []string {
	return []string{
		"#!/bin/bash ",
		"# ",
		"set -o nounset        # error when referencing undefined variable ",
		"set -o errexit        # exit when command fails ",
		"shopt -s extglob ",
		"shopt -s nullglob ",
		"# 		",
	}
}

func contains(slice []string, values ...string) bool {
	for _, value := range values {
		if contain(slice, value) {
			return true
		}
	}
	return false
}

func contain(slice []string, value string) bool {
	for _, s := range slice {
		if s == value {
			return true
		}
	}
	return false
}

func filteredInputs(inputs []inputValue, filter string) []inputValue {
	filtered := []inputValue{}
	for _, input := range inputs {
		if contains(input.source, "video") {
			filtered = append(filtered, input)
		}
	}
	return filtered
}

const (
	hs_low = "subtitles=filename={{FILENAME}}:original_size=1920x1080:force_style='FontName=Segoe UI,Fontsize=19.4,PrimaryColour='&H00EBEBEB',SecondaryColour='&H000000FF',OutlineColour='&H00000000',BackColour='&H80000000',Underline=0,StrikeOut=0,ScaleX=1,ScaleY=1,Spacing=0,Angle=0,BorderStyle=1,Outline=0.5,Shadow=0,Alignment=2,MarginL=5,MarginR=5,MarginV=40,Encoding=1'"
)
