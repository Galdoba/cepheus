package btmscriptwriter

import (
	tea "github.com/charmbracelet/bubbletea"
)

func (sw *ScriptWriter) Init() tea.Cmd {

	return nil
}

func (sw *ScriptWriter) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	//var cmd tea.Cmd
	var cmds []tea.Cmd

	switch msg := msg.(type) {
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "q":
			return sw, tea.Quit
		default:
			//sw.debugMessage = fmt.Sprintf("key pressed: %v", keypress)

		}
	}

	return sw, tea.Batch(cmds...)
}

func (sw *ScriptWriter) View() string {

	return "scriptwriter view"
}
