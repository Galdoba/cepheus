package main

import (
	"fmt"

	"github.com/Galdoba/edts/proto/testquery/quer"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/huh"
)

func main() {
	m, err := tea.NewProgram(CounterWithText{}).Run()
	if err != nil {
		fmt.Println("err", err)
	}
	fmt.Println("=========")
	fmt.Println(m.View())
}

type CounterWithText struct {
	Count      int
	Text       string
	Selector   quer.SelectionModel
	activeForm int
}

func (c CounterWithText) Init() tea.Cmd {
	return nil
}

func (c CounterWithText) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	// var cmd tea.Cmd
	// var cmds []tea.Cmd
	switch msgTyped := msg.(type) {
	case tea.KeyMsg:
		//		cl.data.Events = append(cl.data.Events, msgTyped.String()+" pressed")
		switch keypress := msgTyped.String(); keypress {
		case "q", "Q", "й", "Й":
			return c, tea.Quit
		case "up":
			c.Count++
			return c, nil
		case "down":
			c.Count--
			return c, nil
		case "enter":
			switch c.activeForm {
			case 0:
				c.Selector = quer.NewSelection("select type", "FILM", "TRAILER")
				c.activeForm = 1
			case 1:

				switch c.Selector.State {
				case huh.StateNormal:
					f, cmd := c.Selector.Update(msg)
					c.Selector = f.(quer.SelectionModel)
					c.Text = c.Selector.Selected()
					c.activeForm = 0
					return c, cmd
				case huh.StateCompleted:

				}

			}

		default:

		}
	default:
	}
	return c, nil
}

func (c CounterWithText) View() string {
	s := fmt.Sprintf("counter: %v\n", c.Count)
	switch c.activeForm {
	case 0:
		s += fmt.Sprintf("   text: %v", c.Text)
	case 1:
		s += fmt.Sprintf("%v", c.Selector.View())
	}
	return s
}
