package quer

import (
	"fmt"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/huh"
)

func Input() string {
	var output string
	huh.NewSelect[string]().
		Title("select type").
		Options(
			huh.NewOption("film", "FLM"),
			huh.NewOption("trailer", "TRL"),
		).
		Value(&output).Run()
	if output == "" {
		return "<NO TEXT>"
	}
	return output
}

type SelectionModel struct {
	form     *huh.Form
	selected string
	State    huh.FormState
}

func (s *SelectionModel) Selected() string {
	return s.selected
}

func (s SelectionModel) Init() tea.Cmd {
	return s.form.Init()
}

func (s SelectionModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	form, cmd := s.form.Update(msg)
	if f, ok := form.(*huh.Form); ok {
		s.State = f.State
		s.form = f
	}

	return s.form, cmd
}

func (s SelectionModel) View() string {
	form := s.form
	return form.View()
}

func NewSelection(title string, options ...string) SelectionModel {
	s := SelectionModel{}
	ops := []huh.Option[string]{}
	for _, o := range options {
		ops = append(ops, huh.NewOption[string](o, o))
		fmt.Println("add", o)
	}
	s.form = huh.NewForm(
		huh.NewGroup(
			huh.NewSelect[string]().
				Title(title).Options(ops...).
				Value(&s.selected),
		),
	)
	return s
}
