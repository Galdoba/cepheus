package querry

import (
	"fmt"

	tea "github.com/charmbracelet/bubbletea"
)

func (qm *QuerryModel) Init() tea.Cmd {
	return nil
}

func (qm *QuerryModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "q", "ctrl+c":
			qm.Done = true
			return qm, tea.Quit
		}
	}

	switch qm.ResponseMethod {
	case Single, Multiple:
	case Undefined:
		panic(fmt.Sprintf("querry '%v' response method was not set", qm.Title))
	default:
		panic(fmt.Sprintf("querry '%v' response method unknown", qm.Title))
	}
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	case tea.KeyMsg:
		if qm.Done {
			return qm, nil
		}
		switch keypress := msg.String(); keypress {
		case "esc":
			qm.ChosenSingle = nil
			qm.ChosenMultiple = nil
			qm.Done = true
		case "enter":
			switch qm.ResponseMethod {
			case Single:
				qm.ChosenSingle = &qm.Items[qm.cursorPosition]
			case Multiple:
				for c, item := range qm.Items {
					if qm.OptionsMarked[c] {
						qm.ChosenMultiple = append(qm.ChosenMultiple, &item)
					}
				}
			}
			qm.Done = true
			return qm, nil
		case " ":
			switch qm.ResponseMethod {
			case Multiple:
				qm.toggleSelection()
			}
		case "right":
		case "left":
		case "up", "k", "л":
			qm.cursorPosition--
			if qm.cursorPosition < 0 {
				qm.cursorPosition = 0
			}
		case "down", "j", "о":
			qm.cursorPosition++
			if qm.cursorPosition > len(qm.Items)-1 {
				qm.cursorPosition = len(qm.Items) - 1
			}
			//qm.List, cmd = qm.List.Update(msg)
		default:

		}
	}

	return qm, cmd
}

func (qm *QuerryModel) View() string {
	s := "" // fmt.Sprintf("%v", qm) + "\n"
	switch qm.Done {
	case true:
		s += doneView(qm)
	case false:
		s += notDoneView(qm)
	}
	s = qm.mainStyle.Render(s)
	return s
}

func doneView(qm *QuerryModel) string {
	s := ""
	s += renderHeader(qm) + "\n"
	s += renderTitle(qm) + "\n"
	switch qm.ResponseMethod {
	case Single:
		s += qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render("selected: ") + "\n"
		s += qm.cursor.Passive + qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render(qm.ChosenSingle.key) + "\n"
	case Multiple:
		s += qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render("selected: ") + "\n"
		selectionPassed := false
		for i, item := range qm.Items {
			if qm.OptionsMarked[i] {
				s += qm.cursor.Passive + qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render(item.key) + "\n"
				selectionPassed = true
			}
		}
		if !selectionPassed {
			s += qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render("<<NO ITEMS SELECTED>>") + "\n"
		}

	}

	return s
}

func notDoneView(qm *QuerryModel) string {
	s := ""
	s += renderHeader(qm) + "\n"
	s += renderTitle(qm) + "\n"
	s += renderItems(qm) + "\n"
	s += renderTail(qm)
	return s
}

func (qm *QuerryModel) toggleSelection() {
	qm.OptionsMarked[qm.cursorPosition] = !qm.OptionsMarked[qm.cursorPosition]
}
