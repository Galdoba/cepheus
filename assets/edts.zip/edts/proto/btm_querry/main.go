package main

import (
	"fmt"

	"github.com/Galdoba/edts/proto/btm_querry/querry"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

func main() {

	qm := querry.New(
		querry.WithTitle("This is a question?"),
		querry.WithItems(
			querry.NewItem(querry.WithKey("item 1"), querry.WithDescription("мама")),
			querry.NewItem(querry.WithKey("item 2"), querry.WithDescription("мыла раму")),
			querry.NewItem(querry.WithKey("item 3"), querry.WithDescription("поднебесная радыла")),
			querry.NewItem(querry.WithKey("item 4"), querry.WithDescription("5 + 8 = 13")),
		),
		querry.WithResponseMethod(querry.Multiple),
		querry.WithHeader("fill me", querry.DefaultStyle.Border(lipgloss.NormalBorder(), true).BorderForeground(lipgloss.Color("15"))),
		querry.WithGaps(1, 0, 1, 0),
		querry.WithTail("naskashfk", querry.DefaultStyle.Foreground(lipgloss.Color("166"))),

	//querry.WithStyles(style),
	)
	fmt.Println("12345678901234567890123456789012345678901234567890")
	fmt.Println("         |         |         |         |         |")
	p := tea.NewProgram(&qm)
	_, err := p.Run()
	if err != nil {
		panic(err.Error())
	}
	switch qm.ResponseMethod {
	case querry.Single:
		fmt.Println(qm.Single())
	case querry.Multiple:
		fmt.Println(qm.Multiple())
	}

}

//│    What shall we do wi…│
//012345678901234567890123456789
//│    What shall we do with t…│
