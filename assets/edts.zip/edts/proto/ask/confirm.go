package ask

import "github.com/charmbracelet/huh"

func Confirm(title string) (bool, error) {
	answer := false
	if err := huh.NewConfirm().Title(title).Value(&answer).Run(); err != nil {
		return answer, err
	}
	return answer, nil
}

func Select(title string, options ...string) (string, error) {
	answer := ""
	opts := []huh.Option[string]{}
	for _, o := range options {
		opts = append(opts, huh.NewOption[string](o, o))
	}
	if err := huh.NewSelect[string]().Title(title).Options(opts...).Value(&answer).Run(); err != nil {
		return answer, err
	}
	return answer, nil
}
