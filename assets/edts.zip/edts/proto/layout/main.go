package main

import (
	"fmt"
	"strings"
)

func main() {
	list := []string{}
	for i := 0; i < 20; i++ {
		ev := ""

		ev = fmt.Sprintf("event %v: ", i+1)

		for len(ev) < i%5*10 {
			ev += fmt.Sprintf("++%v--;", i%5*20)
		}

		list = append(list, ev)
	}

	for i, l := range list {
		fmt.Println(i, l)
	}
	fmt.Println("---------------")
	list = wrap(list, 27)
	for _, l := range list {
		fmt.Println(l)
	}

}

/*
+-----------+
| LAYER:    |
+           +
+ main/table+

---------+
LAYER:   |
---------+  
     MAIN|
  PROJECT|
    FIELD|
> SOURCES|
  PREVIEW|



*/

func wrap(lines []string, width int) []string {
	wrapped := header(width)
	for _, line := range lines {
		glyphs := strings.Split(line, "")
		for len(glyphs) > width {

			wrapped = append(wrapped, strings.Join(glyphs[0:width], ""))
			glyphs = glyphs[width:]
		}
		wrapped = append(wrapped, strings.Join(glyphs, ""))

	}
	return wrapped
}

func header(w int) []string {
	l1 := "+-"
	for len(l1) < w-1 {
		l1 += "-"
	}
	l1 += "+"
	text := "| event log"
	for len(text) < w-1 {
		text += " "
	}
	text += "|"
	return []string{l1, text, l1}
}
