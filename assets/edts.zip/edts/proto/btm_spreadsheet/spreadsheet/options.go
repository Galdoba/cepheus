package spreadsheet

import (
	"errors"
	"fmt"
	"math"
	"slices"
	"strings"
)

type SpreadsheetOption func(*Spreadsheet)

func WithColumns(columnNum int) SpreadsheetOption {
	return func(s *Spreadsheet) {
		s.Columns = make(map[int]string)
		for i := 0; i < columnNum; i++ {
			s.Columns[i] = defaultColumnTitle(i)
			//panic("TODO: переделать numberToCode и codeToNumber в отдельную библиотеку 'ncconv' (нужно для eHex)")
		}
	}
}

func WithRows(rowsNum int) SpreadsheetOption {
	return func(s *Spreadsheet) {
		s.Rows = make(map[int]string)
		for i := 0; i < rowsNum; i++ {
			s.Rows[i] = fmt.Sprintf("%v", i)
			//panic("TODO: переделать numberToCode и codeToNumber в отдельную библиотеку 'ncconv' (нужно для eHex)")
		}
	}
}

var ColumnCodes = []string{
	"A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
	"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
	"U", "V", "W", "X", "Y", "Z"}

func defaultColumnTitle(i int) string {
	code, err := numberToCode(ColumnCodes, i)
	if err == nil {
		return code
	}
	panic(err.Error())
}

func numberToCode(codeValues []string, i int) (string, error) {
	if i < 0 {
		return "", fmt.Errorf("negaive number provided: %v", i)
	}
	if i >= 0 && i <= len(codeValues)-1 {
		return codeValues[i], nil
	}
	suffix_nums := []int{}
	current := i
	rest := current
	columnCodesNum := len(codeValues)
	for current > columnCodesNum-1 {
		code := current % (columnCodesNum)
		rest = (current / columnCodesNum) - 1
		current = rest
		suffix_nums = append(suffix_nums, code)
	}
	suffix_nums = append(suffix_nums, rest)
	code := ""
	for l := len(suffix_nums) - 1; l >= 0; l-- {
		code += codeValues[suffix_nums[l]]
	}
	return code, nil
}

func codeToNumber(codeValues []string, code string) (int, error) {
	if code == "" {
		return 0, errors.New("code is empty")
	}
	codeSplits := strings.Split(code, "")
	vals := []int{}
codeLoop:
	for _, split := range codeSplits {
		for i, val := range codeValues {
			if val == split {
				vals = append(vals, i)
				continue codeLoop
			}
		}
		return 0, fmt.Errorf("no value %v from code %v in codeValues provided: %v", split, code, codeValues)
	}
	num := 0
	switch len(vals) {
	case 1:
		return vals[0], nil
	default:
		codeSliced := strings.Split(code, "")
		slices.Reverse(codeSliced)
		for p, val := range codeSliced {
			switch p {
			case 0:
				sliceNum, err := codeToNumber(codeValues, val)
				if err != nil {
					return 0, err
				}
				num += sliceNum
			default:
				sliceNum, err := codeToNumber(codeValues, val)
				if err != nil {
					return 0, err
				}
				valuePowered := powerOf(len(codeValues), p) * (sliceNum + 1)
				num += valuePowered
			}
		}
	}
	return num, nil
}

func powerOf(int1, p int) int {
	f1 := float64(int1)
	power := float64(p)
	val := math.Pow(f1, power)
	return int(val)
}
