package spreadsheet

import tea "github.com/charmbracelet/bubbletea"

func (s *Spreadsheet) Init() tea.Cmd {
	return nil
}

func (s *Spreadsheet) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	return s, nil
}

func (s *Spreadsheet) View() string {
	return "Spreadsheet View"
}
