package spreadsheet

import (
	"fmt"
	"testing"
	"time"
)

func Test_defaultColumnTitle(t *testing.T) {
	for i := 0; i < 72000000; i = i + 1 {
		code := defaultColumnTitle(i)
		num, err := codeToNumber(ColumnCodes, code)
		if err != nil {
			fmt.Println("ERROR!! ", err.Error())
			panic("55")
		}
		fmt.Printf("%v : %v : %v                                \n", i, code, num)

		time.Sleep(time.Millisecond * 300)
	}
}
