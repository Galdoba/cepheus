package spreadsheet

import "github.com/charmbracelet/lipgloss"

const ()

type Spreadsheet struct {
	Data            map[string]string
	Columns         map[int]string
	Rows            map[int]string
	SelectionMethod int
}

func New(options ...SpreadsheetOption) (*Spreadsheet, error) {
	s := Spreadsheet{}
	s.Data = make(map[string]string)
	s.Columns = make(map[int]string)
	s.Rows = make(map[int]string)
	return &s, nil
}

type Cell struct {
	Col         int
	Row         int
	Text        string
	Note        string
	RenderMode  string
	UnderCursor bool
	IsSelected  bool
}

func (c *Cell) RenderText(style lipgloss.Style) string {
	return style.Render(c.Text)
}

func (c *Cell) RenderNote(style lipgloss.Style) string {
	return style.Render(c.Note)
}

type CellSeparator struct {
	Top            string
	TopLeftCorner  string
	TopMiddle      string
	TopRightCorner string
}

/*
2111311131114
5***E***E***B
6DDDFDDDFDDDC
5***E***E***B
6DDDFDDDFDDDC
5***E***E***B
788898889888A

2111311131114
5***E***E***B
5***E***E***B
5***E***E***B
788898889888A

1 - Top
2 - TopLeftCorner
3 - TopMiddle
4 - TopLeftCorner
5 - Left
6 - LeftMiddle
7 - LeftCornerBottom
8 - Bottom
9 - BottomMiddle
A - RightCornerBottom
B - Right
C - RightMiddle
D - HorisontalBetween
E - VerticalBetween
F - HorisontalMiddle
*/
