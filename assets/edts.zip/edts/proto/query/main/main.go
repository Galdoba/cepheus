package main

import (
	"fmt"

	"github.com/Galdoba/edts/proto/query/main/querry"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

func main() {
	qm := querry.New(
		querry.WithTitle("This is a question?"),
		querry.WithItems(
			querry.NewItem(querry.WithKey("item 1"), querry.WithDescription("мама")),
			querry.NewItem(querry.WithKey("item 2"), querry.WithDescription("мыла раму")),
			querry.NewItem(querry.WithKey("item 3"), querry.WithDescription("поднебесная радыла")),
			querry.NewItem(querry.WithKey("item 4"), querry.WithDescription("5 + 8 = 13")),
		),
		querry.WithResponseMethod(querry.Multiple),
		querry.WithHeader("fill me", querry.DefaultStyle.Border(lipgloss.NormalBorder(), true).BorderForeground(lipgloss.Color("15"))),
		querry.WithGaps(1, 0, 1, 0),
		querry.WithTail("naskashfk", querry.DefaultStyle.Foreground(lipgloss.Color("166"))),

	//querry.WithStyles(style),
	)
	qm2 := querry.New(
		querry.WithTitle("This is a question2?"),
		querry.WithItems(
			querry.NewItem(querry.WithKey("item 11"), querry.WithDescription("мама")),
			querry.NewItem(querry.WithKey("item 12"), querry.WithDescription("мыла раму")),
			querry.NewItem(querry.WithKey("item 13"), querry.WithDescription("поднебесная радыла")),
			querry.NewItem(querry.WithKey("item 44"), querry.WithDescription("5 + 8 = 13")),
		),
		querry.WithResponseMethod(querry.Single),
		querry.WithHeader("me title second", querry.DefaultStyle.Border(lipgloss.NormalBorder(), true).BorderForeground(lipgloss.Color("15"))),
		querry.WithGaps(1, 0, 1, 0),
		querry.WithTail("whoosh-showh", querry.DefaultStyle.Foreground(lipgloss.Color("66"))),

	//querry.WithStyles(style),
	)

	st := querry.NewQueryStack(qm, qm2)

	fmt.Println("12345678901234567890123456789012345678901234567890")
	fmt.Println("         |         |         |         |         |")
	p := tea.NewProgram(&st)
	_, err := p.Run()
	if err != nil {
		panic(err.Error())
	}
	// switch qm.ResponseMethod {
	// case querry.Single:
	// 	fmt.Println(qm.Single())
	// case querry.Multiple:
	// 	fmt.Println(qm.Multiple())
	// }

	chosen := st.Chosen()
	for k, vals := range chosen {
		fmt.Print(k)
		for _, v := range vals {
			fmt.Printf(" %v", v.Payload())
		}
		fmt.Println()
	}

}

//│    What shall we do wi…│
//012345678901234567890123456789
//│    What shall we do with t…│
