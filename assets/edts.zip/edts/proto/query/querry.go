package querry

import (
	"github.com/charmbracelet/lipgloss"
)

const (
	Undefined = 0
	Single    = 1
	Multiple  = 2
	Confirm   = 3
)

type QuerryModel struct {
	Header Header
	Tail   Tail
	Title  string
	Items  []Item

	cursorPosition int
	titleStyle     lipgloss.Style
	enumerator     Enumerator
	separator      Separator
	mark           Mark
	cursor         Cursor
	itemStyles     ItemStyles
	mainStyle      lipgloss.Style

	Width             int
	Height            int
	gap_header_title  int
	gap_title_items   int
	gap_between_items int
	gap_items_tail    int

	UseHeader      bool
	UseTail        bool
	UseDescription bool
	UseEnumeration bool
	UseSeparator   bool
	Done           bool

	OptionsMarked  map[int]bool
	ResponseMethod int

	ChosenSingle   *Item
	ChosenMultiple []*Item
}

func New(options ...QuerryOption) QuerryModel {
	qm := defaultQuerryModel()
	for _, modify := range options {
		modify(&qm)
	}

	return qm
}

type QuerryOption func(*QuerryModel)

func defaultQuerryModel() QuerryModel {
	qm := QuerryModel{}
	qm.OptionsMarked = make(map[int]bool)
	qm.enumerator = DefaultEnumerator
	qm.separator = DefaultSeparator
	qm.mark = DefaultMark
	qm.cursor = DefaultCursor
	qm.titleStyle = styleBasedValue("", color_defaultTitle)
	qm.itemStyles = DefaultItemStyles
	qm.mainStyle = defaultStyle()

	return qm
}

func styleBasedValue(literal, colorCode string) lipgloss.Style {
	return lipgloss.NewStyle().SetString(literal).Foreground(lipgloss.Color(colorCode))
}

func defaultStyle() lipgloss.Style {
	return styleBasedValue("", color_gray)
}

//////OUT

func (qm *QuerryModel) Single() *Item {
	return qm.ChosenSingle
}

func (qm *QuerryModel) Multiple() []*Item {
	return qm.ChosenMultiple
}
