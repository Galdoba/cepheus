package v2

import "fmt"

type Item struct {
	key         string
	description string
	payload     interface{}
}

func NewItem(opts ...ItemOption) Item {
	item := Item{}
	for _, modify := range opts {
		modify(&item)
	}
	return item
}

type ItemOption func(*Item)

func WithKey(key string) ItemOption {
	return func(i *Item) {
		i.key = key
	}
}

func WithDescription(description string) ItemOption {
	return func(i *Item) {
		i.description = description
	}
}

func WithPayload(payload interface{}) ItemOption {
	return func(i *Item) {
		i.payload = payload
	}
}

func (i Item) Key() string {
	if i.key != "" {
		return i.key
	}
	return fmt.Sprintf("%v", i.payload)
}

func (i Item) Description() string {
	return i.description
}

func (i Item) Payload() interface{} {
	return i.payload
}

func KeysToItems(keys ...string) []Item {
	items := []Item{}
	for _, k := range keys {
		items = append(items, NewItem(WithKey(k)))
	}
	return items
}
