package v2

type QuerryModel struct {
	Done      bool
	Questions []Question
}

type Question struct {
	Prompt           string
	Responses        []*Item
	MultipleExpected bool
	NoneAllowed      bool
	Selected         []*Item
}

// return anwsers
func (qm *QuerryModel) Submit() map[int][]interface{} {
	subbmited := make(map[int][]interface{})
	for i, q := range qm.Questions {
		subbmited[i] = append(subbmited[i], q.Selected)
	}
	return subbmited
}
