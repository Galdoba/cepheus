package reaction

type Status struct {
	Inbox                 string
	File                  string
	EventRead             bool
	SubscribtionConfirmed bool
	ReactionDetected      string
	ReactionCompleted     bool
	Published             bool
	FileDeleted           bool
}

func NewStatus() *Status {
	return &Status{}
}
