package version

import (
	"fmt"
	"time"
)

type Version struct {
	Major      int
	Minor      int
	Patch      int
	Branch     string
	Qualifiers []string
	Build      int
}

func New(branch string) *Version {
	v := Version{}
	v.Branch = branch
	v.Build = 1
	return &v
}

func (v *Version) Update(qual ...string) {
	v.Qualifiers = qual
	v.Patch++
	v.Build++
}

func (v *Version) UpgradeMinor(qual ...string) {
	v.Qualifiers = qual
	v.Minor++
	v.Patch = 0
	v.Build++
}
func (v *Version) UpgradeMajor(qual ...string) {
	v.Qualifiers = qual
	v.Major++
	v.Minor = 0
	v.Patch = 0
	v.Build++
}

func (v *Version) String() string {
	s := ""
	s += fmt.Sprintf("%v", v.Major)
	s += fmt.Sprintf(".%v", v.Minor)
	s += fmt.Sprintf(".%v", v.Patch)
	if v.Branch != "" {
		s += fmt.Sprintf("-%v", v.Branch)
	}
	q := ":"
	for _, qual := range v.Qualifiers {
		q += qual + "-"
	}
	q += formatBuildTime()

	s += q
	s += fmt.Sprintf(" [build %v]", v.Build)
	return s
}

func formatBuildTime() string {
	tm := time.Now()
	mn := int(tm.Month())
	mnth := fmt.Sprintf("%v", mn)
	if len(mnth) < 2 {
		mnth = "0" + mnth
	}
	bt := fmt.Sprintf("%v%v%v", stringed(tm.Year()), stringed(int(tm.Month())), stringed(tm.Day()))
	return bt
}

func stringed(i int) string {
	s := fmt.Sprintf("%v", i)
	for len(s) < 2 {
		s = "0" + s
	}
	return s
}
