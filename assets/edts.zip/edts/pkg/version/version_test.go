package version

import (
	"fmt"
	"testing"
)

func TestVersion_String(t *testing.T) {
	v := New("")
	v.Update()
	v.Update()
	v.Update()
	v.UpgradeMinor()
	v.Update()
	v.UpgradeMajor("d", "fc")
	for i := 0; i < 26; i++ {
		v.Update(fmt.Sprintf("patch %v", (i+1)/3))
	}
	fmt.Println(v.String())
}
