package kval

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"time"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/pkg/pathfinder"
)

type Dictionary struct {
	Values map[string]Value `json:"Kval Dictionary"`
}

var dict *Dictionary

func newDict() error {
	errFormat := "failed to create new dictionary: %v"
	if dict != nil {
		return fmt.Errorf(errFormat, "dict loaded")
	}
	d := Dictionary{}
	d.Values = make(map[string]Value)
	dict = &d
	f, err := os.Create(defaultPath())
	if err != nil {
		return fmt.Errorf(errFormat, err)
	}
	bt, err := json.Marshal(dict)
	if err != nil {
		return fmt.Errorf(errFormat, err)
	}
	_, err = f.Write(bt)
	if err != nil {
		return fmt.Errorf(errFormat, err)
	}
	if err := f.Close(); err != nil {
		return fmt.Errorf(errFormat, err)
	}

	return nil
}

func load() error {
	errFormat := "failed to load: %v"
	path := defaultPath()
	if err := os.MkdirAll(filepath.Dir(path), 0666); err != nil {
		return err
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0666)
	if err != nil {
		if err := newDict(); err != nil {
			return fmt.Errorf(errFormat, err)
		}
		return nil
	}
	f.Close()
	bt, err := os.ReadFile(path)
	d := Dictionary{}
	d.Values = make(map[string]Value)
	err = json.Unmarshal(bt, &d)
	if err != nil {
		return fmt.Errorf(errFormat, err)
	}
	dict = &d
	return nil
}

func save() error {
	bt, err := json.MarshalIndent(dict, "", "  ")
	if err != nil {
		panic(err.Error())
	}
	f, err := os.OpenFile(defaultPath(), os.O_CREATE|os.O_RDWR, 0666)
	if err != nil {
		panic(err.Error())
	}
	if err := f.Truncate(0); err != nil {
		panic(err.Error())
	}
	_, err = f.Write(bt)
	if err != nil {
		panic(err.Error())
	}
	err = f.Close()
	if err != nil {
		panic(err.Error())
	}
	return nil
}

func assertKey(key string) error {
	switch key {
	case "":
		return fmt.Errorf("empty key provided")
	}
	return nil
}

func defaultPath() string {
	path, err := pathfinder.NewPath(pathfinder.WithProgram(definitions.UTILITY_KVAL), pathfinder.WithFileName("dict.kval"),
		pathfinder.IsSlashed())
	if err != nil {
		panic(err)
	}
	return path
}

func newErrNotExists(key string) *errKeyNotExist {
	err := errKeyNotExist{}
	err.Key = key
	return &err
}

func Default(key, value string, comments ...string) error {
	_, err := Get(key)
	if err != nil {
		switch err.Error() {
		case newErrNotExists(key).Error():
			if len(comments) == 0 {
				comments = append(comments, "default value")
			}
			return Set(key, value, comments...)
		default:
			return err
		}
	}
	return nil
}

func Set(key, val string, withComment ...string) error {
	errFormat := "failed to Set key '%v': %v"
	if key == "" {
		return fmt.Errorf(errFormat, key, "empty key is not allowed")
	}
	if err := load(); err != nil {
		err = newDict()
		if err != nil {
			return fmt.Errorf(errFormat, key, err)
		}

	}
	comment := ""
	for _, c := range withComment {
		comment = c
	}
	dict.Values[key] = newValue(val, comment)
	if err := save(); err != nil {
		return fmt.Errorf(errFormat, key, err)
	}
	return nil
}

func Get(key string) (string, error) {
	if key == "" {
		return "", fmt.Errorf("empty key is not allowed")
	}
	if err := load(); err != nil {
		return "", fmt.Errorf("load error: %v", err)
	}
	if val, ok := dict.Values[key]; ok {
		return val.String, nil
	}
	return "", newErrNotExists(key)
}

func Info(key string) (string, []string, time.Time, error) {
	if err := load(); err != nil {
		return "", nil, time.Time{}, newErrNotExists(key)
	}
	if val, ok := dict.Values[key]; ok {
		return val.String, val.Comments, val.TimeOfCreation, nil
	}
	return "", nil, time.Time{}, newErrNotExists(key)
}

func Delete(key string) error {
	if err := load(); err != nil {
		return fmt.Errorf("delete failed: %v", err)
	}
	delete(dict.Values, key)
	return nil
}

func List() []string {
	load()
	list := []string{}
	for k := range dict.Values {
		list = append(list, k)
	}
	slices.Sort(list)
	return list
}

func DictionaryPath() string {
	return defaultPath()
}
