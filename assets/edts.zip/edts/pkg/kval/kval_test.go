package kval

import (
	"fmt"
	"testing"
)

func Test_defaultPath(t *testing.T) {
	// fmt.Println(Dict)
	// fmt.Println(openDict())
	// fmt.Println(Dict)
	// Set("3", "3355", "comm")
	// fmt.Println(Get("1"))
	// fmt.Println(Get("3"))
	fmt.Println(dict)
}
