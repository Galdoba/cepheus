package kval

import "fmt"

type errKeyNotExist struct {
	Key string
}

type ErrKeyNotExist interface {
	error
}

func (err *errKeyNotExist) Error() string {
	return fmt.Sprintf("key '%v' does not exist", err.Key)
}
