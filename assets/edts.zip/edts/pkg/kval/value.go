package kval

import "time"

type Value struct {
	String         string    `json:"value"`
	Comments       []string  `json:"comments,omitempty"`
	TimeOfCreation time.Time `json:"created"`
}

func newValue(val string, comments ...string) Value {
	v := Value{}
	v.String = val
	v.Comments = comments
	v.TimeOfCreation = time.Now()
	return v
}
