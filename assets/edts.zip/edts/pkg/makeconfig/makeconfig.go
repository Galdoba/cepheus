package makeconfig

import (
	"fmt"
	"os"

	toml "github.com/pelletier/go-toml/v2"
)

const (
	Field_Version             = "version"
	Field_UpdateCycleSeconds  = "update cycle (seconds)"
	Field_TrackDirectoriess   = "track directories"
	Field_OperationMaxAtempts = "operations max atempts"
	Field_OperationDelay      = "operations delay if failed (millseconds)"
	Field_EventInbox          = "event inbox directory"
	Field_EventOutbox         = "event outbox directory"
	Field_DataStorage         = "service storage directory"
	Field_InboxesList         = "send events to"
	Field_OutboxesList        = "collect events from"
	Field_EventsToConsumers   = "event type to consumers"
	Field_StartList           = "app autostart list"
	Field_TriggerTimeout      = "app trigger timeout"
)

type Configuration struct {
	header                  string
	BuildVersion            string                         `toml:"version"`
	Parameters_Bool         map[string]bool                `toml:"BOOLEANS,omitempty"`
	Parameters_Int          map[string]int64               `toml:"INTEGERS,omitempty"`
	Parameters_Float        map[string]float64             `toml:"FLOATS,omitempty"`
	Parameters_String       map[string]string              `toml:"STRINGS,omitempty"`
	Parameters_Slice        map[string][]string            `toml:"LISTS,omitempty"`
	Parameters_NamedInt     map[string]map[string]int64    `toml:"NAMED INTEGERS,omitempty"`
	Parameters_NamedFloats  map[string]map[string]float64  `toml:"NAMED FLOATS,omitempty"`
	Parameters_NamedStrings map[string]map[string]string   `toml:"NAMED STRINGS,omitempty"`
	Parameters_NamedLists   map[string]map[string][]string `toml:"NAMED LISTS,omitempty"`
}

func New(options ...ConfigOption) *Configuration {
	c := Configuration{}
	settings := newSettings()
	for _, modify := range options {
		modify(&settings)
	}
	c.Parameters_Bool = settings.parameters_Bool
	c.Parameters_Int = settings.parameters_Int
	c.Parameters_Float = settings.parameters_Float
	c.Parameters_String = settings.parameters_String
	c.Parameters_Slice = settings.parameters_Slice
	c.Parameters_NamedInt = settings.parameters_NamedInt
	c.Parameters_NamedFloats = settings.parameters_NamedFloats
	c.Parameters_NamedStrings = settings.parameters_NamedStrings
	c.Parameters_NamedLists = settings.parameters_NamedLists
	return &c
}

type configurationSettings struct {
	appName                 string
	buildVersion            string
	path                    string
	parameters_Bool         map[string]bool
	parameters_Int          map[string]int64
	parameters_Float        map[string]float64
	parameters_String       map[string]string
	parameters_Slice        map[string][]string
	parameters_NamedInt     map[string]map[string]int64
	parameters_NamedFloats  map[string]map[string]float64
	parameters_NamedStrings map[string]map[string]string
	parameters_NamedLists   map[string]map[string][]string
}

func newSettings() configurationSettings {
	cs := configurationSettings{}
	cs.parameters_Bool = make(map[string]bool)
	cs.parameters_Int = make(map[string]int64)
	cs.parameters_Float = make(map[string]float64)
	cs.parameters_String = make(map[string]string)
	cs.parameters_Slice = make(map[string][]string)
	cs.parameters_NamedStrings = make(map[string]map[string]string)
	cs.parameters_NamedLists = make(map[string]map[string][]string)
	return cs
}

type ConfigOption func(*configurationSettings)

func AppName(name string) ConfigOption {
	return func(cs *configurationSettings) {
		cs.appName = name
	}
}

func BuildVersion(version string) ConfigOption {
	return func(cs *configurationSettings) {
		cs.buildVersion = version
	}
}

func WithBool(field string, defaultValue bool) ConfigOption {
	return func(cs *configurationSettings) {
		cs.parameters_Bool[field] = defaultValue
	}
}

func WithInt(field string, defaultValue int64) ConfigOption {
	return func(cs *configurationSettings) {
		cs.parameters_Int[field] = defaultValue
	}
}

func WithFloat(field string, defaultValue float64) ConfigOption {
	return func(cs *configurationSettings) {
		cs.parameters_Float[field] = defaultValue
	}
}

func WithString(field string, defaultValue string) ConfigOption {
	return func(cs *configurationSettings) {
		cs.parameters_String[field] = defaultValue
	}
}

func WithSlice(field string, listedValues ...string) ConfigOption {
	return func(cs *configurationSettings) {
		cs.parameters_Slice[field] = listedValues
	}
}

func WithMapString(field string, m map[string]string) ConfigOption {

	return func(cs *configurationSettings) {
		if cs.parameters_NamedStrings == nil {
			cs.parameters_NamedStrings = make(map[string]map[string]string)
		}
		cs.parameters_NamedStrings[field] = m
	}
}

func WithMapInt(field string, m map[string]int64) ConfigOption {

	return func(cs *configurationSettings) {
		if cs.parameters_NamedInt == nil {
			cs.parameters_NamedInt = make(map[string]map[string]int64)
		}
		cs.parameters_NamedInt[field] = m
	}
}

func WithMapFloat(field string, m map[string]float64) ConfigOption {

	return func(cs *configurationSettings) {
		if cs.parameters_NamedFloats == nil {
			cs.parameters_NamedFloats = make(map[string]map[string]float64)
		}
		cs.parameters_NamedFloats[field] = m
	}
}

func WithMapListed(field string, m map[string][]string) ConfigOption {
	return func(cs *configurationSettings) {
		if cs.parameters_NamedLists == nil {
			cs.parameters_NamedLists = make(map[string]map[string][]string)
		}
		cs.parameters_NamedLists[field] = m
	}
}

func Read(path string) (*Configuration, error) {
	bt, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read file: %v", err)
	}
	cfg := Configuration{}
	cfg.Parameters_Bool = make(map[string]bool)
	err = toml.Unmarshal(bt, &cfg)
	if err != nil {
		return nil, fmt.Errorf("unmarshal: %v", err)
	}
	return &cfg, nil
}

/*
Create
Read


Validate
Load

localConf {
	port int
	text string
}

localConf, err := Convert(cfg *makeconfig.Configuration)


#####################################################
#                                                   #
#  Файл использует формат сериализации данных TOML. #
#  Спецификации формата можно прочитать по ссылке:  #
#         https://ru.wikipedia.org/wiki/TOML        #
#                                                   #
#####################################################
*/

func Header() string {
	return "#####################################################\n" +
		"#                                                   #\n" +
		"#  Файл использует формат сериализации данных TOML. #\n" +
		"#  Спецификации формата можно прочитать по ссылке:  #\n" +
		"#         https://ru.wikipedia.org/wiki/TOML        #\n" +
		"#                                                   #\n" +
		"#####################################################\n"

}
