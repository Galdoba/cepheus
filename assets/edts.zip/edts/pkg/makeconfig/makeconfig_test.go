package makeconfig

import (
	"encoding/json"
	"fmt"
	"testing"

	toml "github.com/pelletier/go-toml/v2"
	"gopkg.in/yaml.v3"
)

func TestConfig(t *testing.T) {
	cfg := New(AppName("test"),
		WithFloat("delay", 3.14),
		WithString("path", "here be my path"),
		WithInt("port", 24),
		WithInt("answer", 42),
		WithSlice("ips",
			"192.168.0.100",
			"192.168.0.206",
			"192.168.0.124",
		),
		WithMapString("directories", map[string]string{
			"buffer":   "BUFFER_IN",
			"progress": "_IN_PROGRESS",
		}),
	)
	fmt.Println(cfg)
	Marshal(cfg)
}

func Marshal(cfg *Configuration) {
	//	bt, err := json.MarshalIndent(cfg, "", "  ")
	bt, err := yaml.Marshal(cfg)
	fmt.Println(string(bt))
	fmt.Println(err)

	bt, err = json.MarshalIndent(cfg, "", "  ")
	fmt.Println(string(bt))
	fmt.Println(err)

	bt, err = toml.Marshal(cfg)
	fmt.Println(string(bt))
	fmt.Println(err)
}

/*
YAML
App: ""
Build version: ""
--comment--: this is a comment
INTEGERS:
    answer: 42
    port: 24
FLOATS:
    delay: 3.14
STRINGS:
    path: here be my path
LISTS:
    ips:
        - 192.168.0.100
        - 192.168.0.206
        - 192.168.0.124
KEY-VALUE PAIRS:
    directories:
        buffer: BUFFER_IN
        progress: _IN_PROGRESS




JSON
{
  "App": "",
  "Build version": "",
  "--comment--": "this is a comment",
  "INTEGERS": {
    "answer": 42,
    "port": 24
  },
  "FLOATS": {
    "delay": 3.14
  },
  "STRINGS": {
    "path": "here be my path"
  },
  "LISTS": {
    "ips": [
      "192.168.0.100",
      "192.168.0.206",
      "192.168.0.124"
    ]
  },
  "KEY-VALUE PAIRS": {
    "directories": {
      "buffer": "BUFFER_IN",
      "progress": "_IN_PROGRESS"
    }
  }
}


TOML
App = ""
"Build version" = ""
--comment-- = "this is a comment"

[INTEGERS]
  answer = 42
  port = 24

[FLOATS]
  delay = 3.14

[STRINGS]
  path = "here be my path"

[LISTS]
  ips = ["192.168.0.100", "192.168.0.206", "192.168.0.124"]

["KEY-VALUE PAIRS"]
  ["KEY-VALUE PAIRS".directories]
    buffer = "BUFFER_IN"
    progress = "_IN_PROGRESS"
*/
