package main

import (
	"fmt"
	"testing"

	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/render"
)

func TestRender(t *testing.T) {
	ev, _ := events.Assemble(`c:\Users\pemaltynov\Programs\galdoba\edts\edts-event-broker-service\events\outbox\250331152127451_project_modified.event`)

	fmt.Println(render.Render(ev))

}
