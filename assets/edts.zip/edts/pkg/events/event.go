package events

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/Galdoba/edts/pkg/events/payload"
	"github.com/Galdoba/edts/pkg/timestamp"
)

const (
	Key_EventType      = "event_type"
	Key_EventTimestamp = "event_timestamp"
	Key_EventPublisher = "event_publisher"
)

type event struct {
	EventType string            `json:"event"`     //descriptor
	Timestamp int64             `json:"timestamp"` //UnixNano
	Publisher string            `json:"publisher"` //app name (from publisher)
	Payload   map[string]string `json:"payload"`   //other (may be absent)
}

type Event interface {
	Type() string
	TimeNano() int64
	Signature() string
	Disassemble() map[string]string
}

func (e *event) Type() string {
	return e.EventType
}

func (e *event) TimeNano() int64 {
	return e.Timestamp
}

func (e *event) Signature() string {
	return e.Publisher
}

func (e *event) Disassemble() map[string]string {
	return read(*e)
}

func newEvent(evType string, paydata ...payload.PayloadData) event {
	ts := timestamp.NowInt64()
	e := event{}
	e.EventType = evType
	e.Timestamp = ts
	if publisher.Name == "" {
		panic("publisher name was now set")
	}
	if publisher.Destination == "" {
		panic("publisher destination was now set")
	}
	e.Publisher = publisher.Name
	data := payload.Container{}
	data.String = make(map[string]string)
	for _, addTo := range paydata {
		addTo(&data)
	}
	if len(data.String) > 0 {
		e.Payload = make(map[string]string)
		e.Payload = data.String
	}
	return e
}

func Construct(evType string, evTime time.Time, evPublisher string, evFields map[string]string) event {
	ev := event{}
	ev.EventType = evType
	ev.Publisher = evPublisher
	ev.Timestamp = timestamp.FromTime(evTime)
	ev.Payload = evFields
	return ev
}

func FileName(ev event) string {
	return fmt.Sprintf("%v_%v.event", ev.Timestamp, typeToName(ev.EventType))
}

func DateTimeNano(ev Event) (string, string, string) {
	tn := time.Unix(ev.TimeNano(), ev.TimeNano())
	ts := timestamp.FromTime(tn)
	tss := fmt.Sprintf("%v", ts)
	splited := strings.Split(tss, "")
	date, tm, nano := "", "", ""
	for i, s := range splited {
		switch i {
		case 0, 1, 2, 4:
			date += s
		case 3, 5:
			date += s + "/"
		case 6, 8, 10:
			tm += s
		case 7, 9:
			tm += s + ":"
		default:
			nano += s
		}
	}
	return date, tm, nano
}

func read(ev event) map[string]string {
	evmap := make(map[string]string)
	evmap[Key_EventType] = ev.EventType
	evmap[Key_EventTimestamp] = fmt.Sprintf("%v", ev.Timestamp)
	evmap[Key_EventPublisher] = ev.Publisher
	for k, v := range ev.Payload {
		evmap[k] = v
	}
	return evmap
}

func Read(path string) (map[string]string, error) {
	bt, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read path: %v", err)
	}
	ev := event{}
	err = json.Unmarshal(bt, &ev)
	if err != nil {
		return nil, fmt.Errorf("failed to unmarshal json: %v", err)
	}
	return read(ev), nil
}

func typeToName(s string) string {
	name := strings.ToLower(s)
	name = strings.ReplaceAll(name, " ", "_")
	return name
}

func reassemble(evmap map[string]string) (*event, error) {
	ev := &event{}
	for k, v := range evmap {
		switch k {
		case Key_EventType:
			ev.EventType = v
		case Key_EventTimestamp:
			i, err := strconv.ParseInt(v, 10, 64)
			if err == nil {
				ev.Timestamp = i
			}
		case Key_EventPublisher:
			ev.Publisher = v
		default:
			if ev.Payload == nil {
				ev.Payload = make(map[string]string)
			}
			ev.Payload[k] = v
		}
	}

	if ev.EventType == "" || ev.Timestamp == 0 || ev.Publisher == "" {
		return nil, fmt.Errorf(`event reassembling failed event{type: "%v"; timestamp: %v; publisher: "%v"; payload: %v}`, ev.EventType, ev.Timestamp, ev.Publisher, ev.Payload)
	}
	return ev, nil
}

func Filename(ev Event) string {
	return fmt.Sprintf("%v_%v.event", ev.TimeNano(), ev.Type())
}

func Assemble(path string) (Event, error) {
	ev, err := Read(path)
	if err != nil {
		return nil, fmt.Errorf("event assembling failed: %v", err)
	}
	event, err := reassemble(ev)
	if err != nil {
		return nil, err
	}
	return event, nil
}

func CustomType(custom string) string {
	custom = strings.ToLower(custom)
	for _, gl := range []string{
		" ", "'", `"`, "`", "!", "?", "#", "@", ":", ";",
	} {
		custom = strings.ReplaceAll(custom, gl, "_")
	}
	parted := strings.Split(custom, "_")
	custom = ""
	for _, part := range parted {
		if part != "" {
			custom += part + "_"
		}
	}
	custom = strings.TrimSuffix(custom, "_")
	return custom
}
