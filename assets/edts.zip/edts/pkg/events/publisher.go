package events

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/Galdoba/edts/pkg/events/payload"
)

type Publisher struct {
	Name        string //app who publish
	Destination string //where to publish
}

var publisher Publisher

func SetupPublisher(name, destination string) {
	if publisher.Name != "" || publisher.Destination != "" {
		panic(fmt.Sprintf("publisher can't be overwritten!\n  current settings:\n    name: %v\n    destination:%v", publisher.Name, publisher.Destination))
	}
	publisher.Name = name
	publisher.Destination = strings.TrimSuffix(destination, "/") + "/"
}

func PublishNewEvent(eType string, data ...payload.PayloadData) error {
	if publisher.Destination == "" {
		panic("publisher destination was not set")
	}
	fi, err := os.Stat(publisher.Destination)
	if err != nil {
		panic(fmt.Sprintf("publisher destination error: %v", err))
	}
	if !fi.IsDir() {
		panic("publisher destination is not directory")
	}
	//var err error
	for atempt := 0; atempt < 1000; atempt++ {
		ev := newEvent(eType, data...)
		bt, errM := json.Marshal(&ev)
		if errM != nil {
			err = errM
			return fmt.Errorf("failed to marshal event: %v", errM)
		}
		f, errF := os.OpenFile(publisher.Destination+FileName(ev), os.O_CREATE|os.O_EXCL|os.O_RDWR, 0644)
		if errF != nil {
			err = errF
			time.Sleep(time.Millisecond)
			continue
		}
		w, errW := f.Write(bt)
		if w == 0 {
			err = fmt.Errorf("nothing was written for %v", FileName(ev))
			continue
		}
		if errW != nil {
			err = fmt.Errorf("write error: %v", errF)
			continue
		}
		if errC := f.Close(); errC != nil {
			err = errC
			continue
		}
		return nil
	}
	return fmt.Errorf("failed to publish event: %v", err)
}
