package unstructured

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/Galdoba/edts/pkg/events/payload"
)

type UnstructuredEvent struct {
	Name                string            `json:"event"`
	Timestamp           int64             `json:"timestamp"`
	Publisher           string            `json:"publisher"`
	UnstructuredPayload map[string]string `json:"payload"`
}

func NewUnstructuredEvent(name string, ts int64, publisher string, data ...payload.PayloadData) (*UnstructuredEvent, error) {
	ev := &UnstructuredEvent{}
	ev.Name = name
	ev.Timestamp = ts
	ev.Publisher = publisher
	err := ev.FillWith(data...)
	return ev, err
}

func ReadUnstructuredEvent(path string) (*UnstructuredEvent, error) {
	e := UnstructuredEvent{}
	bt, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read event file: %v", err)
	}
	if err := json.Unmarshal(bt, &e); err != nil {
		return nil, fmt.Errorf("failed to unmarshal event file: %v", err)
	}
	return &e, nil
}

func (ev *UnstructuredEvent) Type() string {
	return ev.Name
}

func (ev *UnstructuredEvent) TimeNano() int64 {
	return ev.Timestamp
}
func (ev *UnstructuredEvent) Signature() string {
	return ev.Publisher
}

func (ev *UnstructuredEvent) MarshalJSON() ([]byte, error) {
	return json.Marshal(*ev)
}

func (ev *UnstructuredEvent) FillWith(pl ...payload.PayloadData) error {
	data := payload.Container{}
	data.String = make(map[string]string)
	for _, addTo := range pl {
		addTo(&data)
	}
	if len(data.String) > 0 {
		ev.UnstructuredPayload = make(map[string]string)
		ev.UnstructuredPayload = data.String
	}
	return nil
}
