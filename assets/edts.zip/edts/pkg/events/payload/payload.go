package payload

import "encoding/json"

type PayloadData func(*Container)

type Container struct {
	AllKeys map[string]string
	Bool    map[string]bool
	Int     map[string]int
	Float   map[string]float64
	String  map[string]string
	Structs map[string]json.Unmarshaler
}

const (
	// FILENAME     = "filename"
	// OLD_FILENAME = "old filename"
	// NEW_FILENAME = "new filename"
	//SERVICE      = "service"
	PATH       = "path"
	FROM_VALUE = "value from"
	TO_VALUE   = "value to"
	DIRECTORY  = "directory"
	NAME       = "name"
	VALUE      = "value"
)

/*
spawn.Event(name, payload.String(payload.FILENAME, "file1"))

ev := events.New("file created")
		ev.FillWith(payload.String(payload.Filename, "name 1"))
events.Publish(ev, inbox)

*/

func Read(pay PayloadData) string {
	data := Container{}
	data.String = make(map[string]string)
	pay(&data)
	s := ""
	for k, v := range data.String {
		s += k + " : " + v
	}
	return s
}

func String(key, value string) PayloadData {
	return func(p *Container) {
		if p.String == nil {
			p.String = make(map[string]string)
		}
		switch key {
		case assertStringKey(key):
			p.String[key] = value
		}
	}
}

func assertStringKey(key string) string {
	for _, k := range []string{
		DIRECTORY,
		// FILENAME,
		// OLD_FILENAME,
		// NEW_FILENAME,
		//SERVICE,
	} {
		if key == k {
			return k
		}
	}
	//panic(fmt.Sprintf("key '%v' is not implemented"))
	return key
}
