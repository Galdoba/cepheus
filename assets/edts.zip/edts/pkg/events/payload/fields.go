package payload

// func Service(appName string) PayloadData {
// 	return func(p *Container) {
// 		if p.String == nil {
// 			p.String = make(map[string]string)
// 		}
// 		p.String[SERVICE] = appName
// 	}
// }

// func Directory(dir string) PayloadData {
// 	return func(p *Container) {
// 		if p.String == nil {
// 			p.String = make(map[string]string)
// 		}
// 		p.String[DIRECTORY] = dir
// 	}
// }

// func Filename(name string) PayloadData {
// 	return func(p *Container) {
// 		if p.String == nil {
// 			p.String = make(map[string]string)
// 		}
// 		p.String[FILENAME] = name
// 	}
// }

// func OldFilename(name string) PayloadData {
// 	return func(p *Container) {
// 		if p.String == nil {
// 			p.String = make(map[string]string)
// 		}
// 		p.String[OLD_FILENAME] = name
// 	}
// }

// func NewFilename(name string) PayloadData {
// 	return func(p *Container) {
// 		if p.String == nil {
// 			p.String = make(map[string]string)
// 		}
// 		p.String[NEW_FILENAME] = name
// 	}
// }
