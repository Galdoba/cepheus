package render

import (
	"fmt"
	"slices"
	"strings"

	"github.com/Galdoba/edts/pkg/events"
)

func Render(ev events.Event, options ...RenderOption) string {
	data := ev.Disassemble()
	date, time, nano := dateTimeNano(data["event_timestamp"])
	evType := fmt.Sprintf("%v", data["event_type"])
	publisher := fmt.Sprintf("%v", data["event_publisher"])
	otherKeys := []string{}
	for k := range data {
		switch k {
		case "event_timestamp", "event_type", "event_publisher":
			continue
		default:
			otherKeys = append(otherKeys, k)
		}
	}
	slices.Sort(otherKeys)

	ro := defaultRenderer()
	for _, enrich := range options {
		enrich(&ro)
	}

	text := ""
	switch ro.format {
	case "journal":
		text = fmt.Sprintf("[%v %v.%v] %v\n", date, time, nano, evType)
		if ro.sign {
			text += fmt.Sprintf("  %v\n", publisher)
		}
		switch len(ro.whiteListedKeys) {
		case 0:
			for _, key := range otherKeys {
				if !isListed(ro.blackListedKeys, key) {
					text += fmt.Sprintf("    %v	: %v\n", key, data[key])
				}
			}
		default:
			for _, key := range otherKeys {
				if isListed(ro.whiteListedKeys, key) {
					text += fmt.Sprintf("    %v	: %v\n", key, data[key])
				}
			}
		}

	}
	text = strings.TrimSuffix(text, "\n")
	return text
}

func isListed(slice []string, s string) bool {
	for _, have := range slice {
		if have == s {
			return true
		}
	}
	return false
}

type renderOptions struct {
	format          string
	color           bool
	indent          bool
	sign            bool
	blackListedKeys []string
	whiteListedKeys []string
}

func defaultRenderer() renderOptions {
	ro := renderOptions{}
	ro.format = "journal"
	ro.sign = true

	return ro
}

type RenderOption func(*renderOptions)

func Color(c bool) RenderOption {
	return func(ro *renderOptions) {
		ro.color = c
	}
}

func dateTimeNano(eventtimenano string) (string, string, string) {
	// tn := time.Unix(eventtimenano, eventtimenano)
	// ts := timestamp.FromTime(tn)
	//	tss := fmt.Sprintf("%v", eventtimenano)
	splited := strings.Split(eventtimenano, "")
	date, tm, nano := "", "", ""
	for i, s := range splited {
		switch i {
		case 0, 2, 4, 5:
			date += s
		case 1, 3:
			date += s + "/"
		case 6, 8, 10, 11:
			tm += s
		case 7, 9:
			tm += s + ":"
		default:
			nano += s
		}
	}
	return date, tm, nano
}

type renderer struct {
	byType map[string]renderOptions
}

func newRenderer() *renderer {
	r := renderer{}
	r.byType = make(map[string]renderOptions)
	r.byType["default"] = defaultRenderer()
	return &r
}

func (r *renderer) addRule(eventType string, ro renderOptions) *renderer {
	r.byType[eventType] = ro
	return r
}
