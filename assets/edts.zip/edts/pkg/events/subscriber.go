package events

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/pkg/directory"
)

type subscriber struct {
	sourceDirs []string
}

var subscribeAgent subscriber

func ReadSubscribtions(subscriber, inbox string) (map[string]Event, []error) {
	eventMap := make(map[string]Event)
	errors := []error{}
	fi, _ := os.ReadDir(inbox)
	for _, f := range fi {
		path := inbox + f.Name()
		ev, err := Read(path)
		if err != nil {
			errors = append(errors, err)
			continue
		}
		event, err := reassemble(ev)
		if err != nil {
			errors = append(errors, err)
			continue
		}
		for _, app := range subscribtions[subscriber] {
			if event.Signature() == app {
				eventMap[path] = event
			}
		}

	}
	return eventMap, errors
}

var subscribtions map[string][]string

func Subscribtions(name string) []string {

	subscribtions = make(map[string][]string)
	subscribtions[definitions.SERVICE_FILENAME_NORMALIZER] = append(subscribtions[definitions.SERVICE_FILENAME_NORMALIZER],
		definitions.SERVICE_DIRECTORY_TRACKER,
	)
	subscribtions[definitions.SERVICE_SPREADSHEET_TRACKER] = append(subscribtions[definitions.SERVICE_SPREADSHEET_TRACKER],
		definitions.CLIENT_PROJECT_MANAGER,
	)

	// subscribtions[definitions.SERVICE_EVENT_BROKER] = append(subscribtions[definitions.SERVICE_EVENT_BROKER],
	// 	definitions.SERVICE_DIRECTORY_TRACKER,
	// 	definitions.SERVICE_FILENAME_NORMALIZER,
	// 	definitions.SERVICE_DISPATCHER,
	// )

	return subscribtions[name]
}

func SetInbox(dests []string) error {
	for _, dest := range dests {
		if err := directory.Validate(dest); err != nil {
			return fmt.Errorf("failed to set inbox: %v", err)
		}
		subscribeAgent.sourceDirs = append(subscribeAgent.sourceDirs, dest)
	}
	return nil
}
