package events

import (
	"github.com/Galdoba/edts/internal/definitions"
)

const (
	FILE_CREATED             = "file_created"
	FILE_MODIFIED            = "file_modified"
	FILE_REMOVED             = "file_removed"
	FILENAME_NORMALIZED      = "filename_normalized"
	MODULE_STARTED           = "module_started"
	TRANSFERT_COMPLETE       = "transfert_complete"
	WORKSHEET_UPDATED        = "worksheet_updated"
	WORKSHEET_FETCH_REQUSTED = "worksheet_fetch_requsted"
	WORKSHEET_WRITE_REQUSTED = "worksheet_write_requsted"
	PROJECT_CREATED          = "project_created"
	PROJECT_DELETED          = "project_deleted"
	PROJECT_MODIFIED         = "project_modified"
)

func MapEventTypeToConsumers() map[string][]string {
	eventMap := make(map[string][]string)
	eventMap[FILE_CREATED] = []string{definitions.SERVICE_FILENAME_NORMALIZER}
	eventMap[WORKSHEET_FETCH_REQUSTED] = []string{definitions.SERVICE_SPREADSHEET_TRACKER}
	eventMap[WORKSHEET_WRITE_REQUSTED] = []string{definitions.SERVICE_SPREADSHEET_TRACKER}

	return eventMap
}
