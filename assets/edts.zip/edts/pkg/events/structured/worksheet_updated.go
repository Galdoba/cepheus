package structured

// type WorksheetUpdatedEvent struct {
// 	Name      string `json:"event"`
// 	Timestamp int64  `json:"timestamp"`
// 	Publisher string `json:"publisher"`
// }

// func NewWorksheetUpdatedEvent(name string, ts int64, publisher string, data ...payload.PayloadData) (*WorksheetUpdatedEvent, error) {
// 	ev := &WorksheetUpdatedEvent{}
// 	ev.Name = name
// 	ev.Timestamp = ts
// 	ev.Publisher = publisher
// 	err := ev.FillWith(data...)
// 	return ev, err
// }

// func ReadWorksheetUpdatedEvent(path string) (*WorksheetUpdatedEvent, error) {
// 	e := WorksheetUpdatedEvent{}
// 	bt, err := os.ReadFile(path)
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to read event file: %v", err)
// 	}
// 	if err := json.Unmarshal(bt, &e); err != nil {
// 		return nil, fmt.Errorf("failed to unmarshal event file: %v", err)
// 	}
// 	return &e, nil
// }

// func (ev *WorksheetUpdatedEvent) Type() string {
// 	return ev.Name
// }

// func (ev *WorksheetUpdatedEvent) TimeNano() int64 {
// 	return ev.Timestamp
// }

// func (ev *WorksheetUpdatedEvent) Signature() string {
// 	return ev.Publisher
// }

// func (ev *WorksheetUpdatedEvent) MarshalJSON() ([]byte, error) {
// 	return json.Marshal(*ev)
// }

// func (ev *WorksheetUpdatedEvent) FillWith(pl ...payload.PayloadData) error {
// 	data := payload.Container{}
// 	data.String = make(map[string]string)
// 	for _, addTo := range pl {
// 		addTo(&data)
// 	}
// 	return nil
// }
