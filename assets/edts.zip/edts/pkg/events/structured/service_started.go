package structured

// import (
// 	"encoding/json"
// 	"fmt"
// 	"os"

// 	"github.com/Galdoba/edts/pkg/events/payload"
// )

// type ServiceStartedEvent struct {
// 	Name      string `json:"event"`
// 	Timestamp int64  `json:"timestamp"`
// 	Publisher string `json:"publisher"`
// 	Sevice    string `json:"service"`
// }

// func NewServiceStartedEvent(name string, ts int64, publisher string, data ...payload.PayloadData) (*ServiceStartedEvent, error) {
// 	ev := &ServiceStartedEvent{}
// 	ev.Name = name
// 	ev.Timestamp = ts
// 	ev.Publisher = publisher
// 	err := ev.FillWith(data...)
// 	return ev, err
// }

// func ReadServiceStartedEvent(path string) (*ServiceStartedEvent, error) {
// 	e := ServiceStartedEvent{}
// 	bt, err := os.ReadFile(path)
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to read event file: %v", err)
// 	}
// 	if err := json.Unmarshal(bt, &e); err != nil {
// 		return nil, fmt.Errorf("failed to unmarshal event file: %v", err)
// 	}
// 	return &e, nil
// }

// func (ev *ServiceStartedEvent) Type() string {
// 	return ev.Name
// }

// func (ev *ServiceStartedEvent) TimeNano() int64 {
// 	return ev.Timestamp
// }

// func (ev *ServiceStartedEvent) Signature() string {
// 	return ev.Publisher
// }

// func (ev *ServiceStartedEvent) MarshalJSON() ([]byte, error) {
// 	return json.Marshal(*ev)
// }

// func (ev *ServiceStartedEvent) FillWith(pl ...payload.PayloadData) error {
// 	data := payload.Container{}
// 	data.String = make(map[string]string)
// 	for _, addTo := range pl {
// 		addTo(&data)
// 	}
// 	ev.Sevice = data.String[payload.SERVICE]
// 	if ev.Sevice == "" {
// 		return fmt.Errorf("%v_%v no %v data present", payload.SERVICE, ev.Timestamp, ev.Name)
// 	}
// 	return nil
// }
