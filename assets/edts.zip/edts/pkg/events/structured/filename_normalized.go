package structured

// import (
// 	"encoding/json"
// 	"fmt"
// 	"os"

// 	"github.com/Galdoba/edts/pkg/events/payload"
// )

// type FilenameNormalizedEvent struct {
// 	Name      string `json:"event"`
// 	Timestamp int64  `json:"timestamp"`
// 	Publisher string `json:"publisher"`
// 	Directory string `json:"directory"`
// 	OldName   string `json:"old filename"`
// 	NewName   string `json:"new filename"`
// }

// func NewFilenameNormalizedEvent(name string, ts int64, publisher string, data ...payload.PayloadData) (*FilenameNormalizedEvent, error) {
// 	ev := &FilenameNormalizedEvent{}
// 	ev.Name = name
// 	ev.Timestamp = ts
// 	ev.Publisher = publisher
// 	err := ev.FillWith(data...)
// 	return ev, err
// }

// func ReadFilenameNormalizedEvent(path string) (*FilenameNormalizedEvent, error) {
// 	e := FilenameNormalizedEvent{}
// 	bt, err := os.ReadFile(path)
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to read event file: %v", err)
// 	}
// 	if err := json.Unmarshal(bt, &e); err != nil {
// 		return nil, fmt.Errorf("failed to unmarshal event file: %v", err)
// 	}
// 	return &e, nil
// }

// func (ev *FilenameNormalizedEvent) Type() string {
// 	return ev.Name
// }

// func (ev *FilenameNormalizedEvent) TimeNano() int64 {
// 	return ev.Timestamp
// }
// func (ev *FilenameNormalizedEvent) Signature() string {
// 	return ev.Publisher
// }

// func (ev *FilenameNormalizedEvent) MarshalJSON() ([]byte, error) {
// 	return json.Marshal(*ev)
// }

// func (ev *FilenameNormalizedEvent) FillWith(pl ...payload.PayloadData) error {
// 	data := payload.Container{}
// 	data.String = make(map[string]string)
// 	for _, addTo := range pl {
// 		addTo(&data)
// 	}
// 	ev.Directory = data.String[payload.DIRECTORY]
// 	ev.OldName = data.String[payload.OLD_FILENAME]
// 	ev.NewName = data.String[payload.NEW_FILENAME]
// 	if ev.Directory == "" {
// 		return fmt.Errorf("%v_%v no %v data present", payload.DIRECTORY, ev.Timestamp, ev.Name)
// 	}
// 	if ev.OldName == "" {
// 		return fmt.Errorf("%v_%v no %v data present", payload.OLD_FILENAME, ev.Timestamp, ev.Name)
// 	}
// 	if ev.NewName == "" {
// 		return fmt.Errorf("%v_%v no %v data present", payload.NEW_FILENAME, ev.Timestamp, ev.Name)
// 	}
// 	return nil
// }
