package structured

// type FileEvent struct {
// 	Name      string `json:"event"`
// 	Timestamp int64  `json:"timestamp"`
// 	Publisher string `json:"publisher"`
// 	Directory string `json:"directory"`
// 	Filename  string `json:"filename"`
// }

// func NewFileEvent(name string, ts int64, publisher string, data ...payload.PayloadData) (*FileEvent, error) {
// 	ev := &FileEvent{}
// 	ev.Name = name
// 	ev.Timestamp = ts
// 	ev.Publisher = publisher
// 	err := ev.FillWith(data...)
// 	return ev, err
// }

// func ReadFileEvent(path string) (*FileEvent, error) {
// 	e := FileEvent{}
// 	bt, err := os.ReadFile(path)
// 	if err != nil {
// 		if errors.Is(err, os.ErrNotExist) {
// 			fmt.Printf("event file not found at: %v\n", path)
// 			return nil, nil
// 		}
// 		return nil, fmt.Errorf("failed to read event file: %v", err)
// 	}
// 	if err := json.Unmarshal(bt, &e); err != nil {
// 		return nil, fmt.Errorf("failed to unmarshal event file: %v", err)
// 	}
// 	return &e, nil
// }

// func (ev *FileEvent) Type() string {
// 	return ev.Name
// }

// func (ev *FileEvent) TimeNano() int64 {
// 	return ev.Timestamp
// }

// func (ev *FileEvent) Signature() string {
// 	return ev.Publisher
// }

// func (ev *FileEvent) MarshalJSON() ([]byte, error) {
// 	return json.Marshal(*ev)
// }

// func (ev *FileEvent) FillWith(pl ...payload.PayloadData) error {
// 	data := payload.Container{}
// 	data.String = make(map[string]string)
// 	for _, addTo := range pl {
// 		addTo(&data)
// 	}
// 	ev.Filename = data.String[payload.FILENAME]
// 	ev.Directory = data.String[payload.DIRECTORY]
// 	if ev.Directory == "" {
// 		return fmt.Errorf("%v_%v no %v data present", payload.DIRECTORY, ev.Timestamp, ev.Name)
// 	}
// 	if ev.Filename == "" {
// 		return fmt.Errorf("%v_%v no %v data present", payload.FILENAME, ev.Timestamp, ev.Name)
// 	}
// 	return nil
// }
