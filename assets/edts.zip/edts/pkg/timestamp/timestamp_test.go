package timestamp

import (
	"fmt"
	"testing"
)

func TestTimestamp(t *testing.T) {
	tss := Now()
	fmt.Println(tss)
	tt, ee := GetFrom(tss + "event_name")
	fmt.Println(tt)
	fmt.Println(ee)
}
