package textfile

import (
	"testing"
)

func TestEncodeFileToUTF8(t *testing.T) {
}
