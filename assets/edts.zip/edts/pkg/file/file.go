package file

import (
	"encoding/json"
	"errors"
	"os"
)

func Exists(path string) (bool, error) {
	if _, err := os.Stat(path); err == nil {
		return true, nil

	} else if errors.Is(err, os.ErrNotExist) {
		// path/to/whatever does *not* exist
		return false, nil
	} else {
		// Schrodinger: file may or may not exist. See err for details.

		// Therefore, do *NOT* use !os.IsNotExist(err) to test for file existence
		return false, err
	}
}

func SaveToFile(path string, structure json.Marshaler) error {
	bt, err := structure.MarshalJSON()
	if err != nil {
		return err
	}
	err = os.WriteFile(path, bt, 0660)
	if err != nil {
		return err
	}
	return nil
}
