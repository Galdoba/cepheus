package directory

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func EnsureDirSlash(dir string) string {
	return strings.TrimSuffix(dir, string(filepath.Separator)) + string(filepath.Separator)
}

func Validate(dir string) error {
	if dir == "" {
		return fmt.Errorf("no directory path for validation was provided")
	}
	f, err := os.Stat(dir)
	if err != nil {
		return err
	}
	if !f.IsDir() {
		return fmt.Errorf("%v is not directory", dir)
	}
	return nil
}
