package flags

import "github.com/urfave/cli/v3"

var TestFlag = &cli.BoolFlag{
	Name: "test_flag",
}
