package subtitles

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/Galdoba/edts/pkg/edur"
	"github.com/Galdoba/edts/pkg/textfile"
)

type Entry struct {
	Id    int      `json:"id"`
	Start float64  `json:"start"`
	End   float64  `json:"end"`
	Text  []string `json:"text"`
}

type Subtitles struct {
	Dir              string  `json:"directory,omitempty"`
	Name             string  `json:"filename,omitempty"`
	Content          []Entry `json:"content,omitempty"`
	evaluationErrors []error
	fixActions       map[string]int
}

func (s *Subtitles) evaluate() {
	errors := []error{}
	ctrl := edur.EditDuration{}
	for i, entry := range s.Content {
		if entry.Id != i+1 {
			errors = append(errors, fmt.Errorf("entry %v have id=%v", i+1, entry.Id))
			//s.fixActions[actionAddEmptyEntry]++
		}
		startTime := edur.FromFloat64(entry.Start)

		if startTime.MillisecondsTotal < ctrl.MillisecondsTotal {
			errors = append(errors, fmt.Errorf("entry %v starttime (%v) is less than control time: %v", entry.Id, entry.Start, ctrl))
		}
		if (startTime.MillisecondsTotal - ctrl.MillisecondsTotal) > edur.FromFloat64(60*35).MillisecondsTotal {
			errors = append(errors, fmt.Errorf("entry %v starttime (%v) stands more than 35 minutes from control time: %v", entry.Id, startTime.DurationSrt(), ctrl.DurationSrt()))
			s.fixActions[actionAddEmptyEntry]++
		}
		ctrl = startTime

		endTime := edur.FromFloat64(entry.End)

		if endTime.MillisecondsTotal < ctrl.MillisecondsTotal {
			errors = append(errors, fmt.Errorf("entry %v endTime (%v) is less than control time: %v", entry.Id, endTime.Duration(), ctrl.Duration()))
		}
		if (endTime.MillisecondsTotal - ctrl.MillisecondsTotal) > edur.FromFloat64(60*35).MillisecondsTotal {
			errors = append(errors, fmt.Errorf("entry %v endTime (%v) stands more than 35 minutes from control time: %v", entry.Id, entry.End, ctrl.SecondsTotal))
			s.fixActions[actionAddEmptyEntry]++
		}
		ctrl = endTime

		if len(entry.Text) < 1 {
			errors = append(errors, fmt.Errorf("entry %v have no text", entry.Id))
		}
		for l, line := range entry.Text {
			if line == "" {
				errors = append(errors, fmt.Errorf("entry %v have empty text in line %v", entry.Id, l+1))
				continue
			}
			colorized, bad := textfile.ColorizeLine(line)
			if bad > 0 {
				errors = append(errors, fmt.Errorf("entry %v have %v bad symbols in line %v:\n%v", entry.Id, bad, l+1, line))
				fmt.Println(s.Name)
				fmt.Println(colorized)
				s.fixActions[actionFixBadLetter]++
				continue
			}
		}
	}
	s.evaluationErrors = errors
}

func LoadFile(path string) (*Subtitles, error) {
	dir := filepath.Dir(path) + string(filepath.Separator)
	name := filepath.Base(path)
	st := Subtitles{}
	st.fixActions = make(map[string]int)
	st.Dir = dir
	st.Name = name
	lines, err := linesOfFile(path)
	if err != nil {
		return nil, err
	}
	if err := st.Parse(lines); err != nil {
		return nil, err
	}
	st.evaluate()
	return &st, nil
}

func linesOfFile(path string) ([]string, error) {
	bt, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	lines := strings.Split(string(bt), "\n")
	return lines, nil
}

func (st *Subtitles) Parse(lines []string) error {
	inEntry := false
	activeEntry := Entry{}
	for l, line := range lines {
		line = strings.TrimSpace(line)
		switch inEntry {
		case false:
			if strings.EqualFold(line, "\ufeff1") { //TODO: разобраться с чтением файлов если там есть BOM
				line = "1"
			}
			if n, err := strconv.Atoi(line); err == nil {
				activeEntry = Entry{}
				activeEntry.Id = int(n)
				inEntry = true
				continue
			}
		case true:
			if line == "" {
				st.Content = append(st.Content, activeEntry)
				inEntry = false
				continue
			}
			if activeEntry.Start+activeEntry.End == 0.0 {
				timecodes := strings.Split(line, " --> ")
				switch len(timecodes) {
				case 2:
					start, err := edur.FromString(timecodes[0])
					if err != nil {
						return fmt.Errorf("failed at line %v: %v", l, err)
					}
					activeEntry.Start = start.SecondsTotal
					end, err := edur.FromString(timecodes[1])
					if err != nil {
						return fmt.Errorf("failed at line %v: %v", l, err)
					}
					activeEntry.End = end.SecondsTotal
					continue
				}
			}
			activeEntry.Text = append(activeEntry.Text, line)
		}

	}

	return nil
}

func (s *Subtitles) Print() {
	for _, e := range s.Content {
		fmt.Println(e.Id)
		fmt.Printf("%v --> %v\n", edur.FromFloat64(e.Start).Duration(), edur.FromFloat64(e.End).Duration())
		for _, line := range e.Text {
			colored, _ := textfile.ColorizeLine(line)
			fmt.Println(colored)
		}
		fmt.Println("")
	}
	if len(s.evaluationErrors) > 0 {
		fmt.Println("")
		fmt.Println("==============")
		for _, err := range s.evaluationErrors {
			fmt.Println(err)
		}
	}
}
