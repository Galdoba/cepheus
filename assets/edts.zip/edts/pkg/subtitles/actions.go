package subtitles

const (
	actionAddEmptyEntry = "Add Empty Entry"
	actionFixID         = "Fix ID"
	actionFixBadLetter  = "Fix Bad Letter"
)

var emptyEntry = "<i> </i>"

func (s *Subtitles) FixID() error {
	newID := 1
	for i := range s.Content {
		s.Content[i].Id = newID
		newID++
	}
	return nil
}

func (s *Subtitles) AddBlankEntries() error {
	this := Entry{}
	fixed := []Entry{Entry{Id: 0, Start: 0, End: 0.001, Text: []string{emptyEntry}}}
	offset := 0
	for i := range s.Content {
		this = s.Content[i]
		for this.Start-fixed[len(fixed)-1].End > 30*60 {
			addStart := fixed[len(fixed)-1].End + (30 * 60)
			addEnd := addStart + 0.001

			fixed = append(fixed, Entry{Id: this.Id + offset, Start: addStart, End: addEnd, Text: []string{emptyEntry}})
			offset++
		}
		this.Id = this.Id + offset
		fixed = append(fixed, this)
	}
	s.Content = fixed[1:]
	//s.FixID()
	s.evaluate()
	return nil
}
