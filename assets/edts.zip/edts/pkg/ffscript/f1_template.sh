# Path declaration
BUFFER="/home/pemaltynov/IN"
NAS="mnt/pemaltynov/ROOT"
ARCHIVE="IN"
EDIT="EDIT"
IN_PROGRESS="${BUFFER}/_IN_PROGRESS"
DONE="${BUFFER}/_DONE"
# Input Declaration
FILE=""
AGENT=""
PUBLICATION_DATE=""
# Output Declaration
OUTBASE=""
# Path calculation
EDIT_PATH="${NAS}/${EDIT}/(kval-read EDIT_${AGENT})"
ARCHIVE_PATH="${NAS}/${ARCHIVE}/(kval-read ARCHIVE_${AGENT})"
FC_AUD="aresample=48000,atempo=25/(__)"
AUDIO_OUT1="AUDIORUS__"
REV="_HD"
mkdir -p ${ARCHIVE_PATH}/_DONE/${OUTBASE}
mkdir -p ${EDIT_PATH}
clear && mv /home/pemaltynov/IN/${FILE} /home/pemaltynov/IN/_IN_PROGRESS/  && fflite -r 25 -i /home/pemaltynov/IN/_IN_PROGRESS/${FILE} \
-filter_complex "[0:v:0]split=2[vidHD][inProxy]; [inProxy]scale=iw/2:ih, setsar=(1/1)*2[vidHD_pr]; [0:a:0]${FC_AUD}[arus_in];  [arus_in]asplit=2[arus][arus_pr]" \
  -map "[vidHD]" -c:v libx264 -preset medium -crf 16 -pix_fmt yuv420p -g 0 -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}.mp4  \
  -map "[vidHD_pr]" -c:v libx264 -x264opts interlaced=1 -preset superfast -pix_fmt yuv420p  -b:v 2000k -maxrate 2000k -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}_proxy.mp4  \
  -map "[arus]" -c:a alac -compression_level 0 -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}_${AUDIO_OUT1}.m4a \
  -map "[arus_pr]" -c:a ac3 -b:a 128k ${EDIT_PATH}/${OUTBASE}${REV}_${AUDIO_OUT1}_proxy.ac3 \
&& touch ${EDIT_PATH}/${OUTBASE}.ready \
&& echo "${EDIT}/${OUTBASE}.ready" > /home/pemaltynov/IN/notifications/${OUTBASE}.done \
&& mv /home/pemaltynov/IN/_IN_PROGRESS/${FILE} /home/pemaltynov/IN/_DONE/  && at now + 10 hours <<< "mv /home/pemaltynov/IN/_DONE/${FILE} ${ARCHIVE_PATH}/_DONE/${OUTBASE}" \
&& clear && mv "$0" /home/pemaltynov/IN/_DONE/bash/



(edts-get -edit-path project)