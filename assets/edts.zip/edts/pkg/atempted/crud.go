package atempted

import (
	"fmt"
	"io"
	"io/fs"
	"os"
	"time"
)

type atemptAgent struct {
	maxAtemptsAllowed int
	delayExpected     time.Duration
}

var agent = atemptAgent{
	maxAtemptsAllowed: 5,
	delayExpected:     time.Millisecond * 5,
}

func SetMaxAtempts(n int) {
	agent.maxAtemptsAllowed = n
}

func SetDelay(delay time.Duration) {
	agent.delayExpected = delay
}

func Create(path string) (*os.File, error) {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		f, err := os.Create(path)
		switch err {
		case nil:
			return f, nil
		default:
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
	}
	return nil, combineErrors(errs...)
}

func OpenFile(path string, flag int, perm fs.FileMode) (*os.File, error) {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		f, err := os.OpenFile(path, flag, perm)
		switch err {
		case nil:
			return f, nil
		default:
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
	}
	return nil, combineErrors(errs...)
}

func ReadFile(path string) ([]byte, error) {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		bt, err := os.ReadFile(path)
		switch err {
		case nil:
			return bt, nil
		default:
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
	}
	return nil, combineErrors(errs...)
}

func ReadDir(path string) ([]os.DirEntry, error) {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		bt, err := os.ReadDir(path)
		switch err {
		case nil:
			return bt, nil
		default:
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
	}
	return nil, combineErrors(errs...)
}

func WriteFile(path string, data []byte, perm fs.FileMode) error {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		err := os.WriteFile(path, data, perm)
		switch err {
		case nil:
			return nil
		default:
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
	}
	return combineErrors(errs...)
}

func Remove(path string) error {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		err := os.Remove(path)
		switch err {
		case nil:
			return nil
		default:
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
	}
	return combineErrors(errs...)
}

func Rename(oldpath, newpath string) error {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		err := os.Rename(oldpath, newpath)
		switch err {
		case nil:
			return nil
		default:
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
	}
	return combineErrors(errs...)
}

func Sync(oldpath, newpath string) error {
	errs := []error{}
mainLoop:
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {

		fi, err := os.Open(oldpath)
		if err != nil {
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
		// close fi on exit and check for its returned error
		defer func() {
			if err := fi.Close(); err != nil {
				errs = append(errs, err)

			}
		}()

		// open output file
		fo, err := os.Create(newpath)
		if err != nil {
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
		// close fo on exit and check for its returned error
		defer func() {
			if err := fo.Close(); err != nil {
				errs = append(errs, err)

			}
		}()

		// make a buffer to keep chunks that are read
		buf := make([]byte, 1024)
		for {
			// read a chunk
			n, err := fi.Read(buf)
			if err != nil && err != io.EOF {
				errs = append(errs, err)
				time.Sleep(agent.delayExpected)
				continue mainLoop
			}
			if n == 0 {
				break
			}

			// write a chunk
			if _, err := fo.Write(buf[:n]); err != nil {
				errs = append(errs, err)
				time.Sleep(agent.delayExpected)
				continue mainLoop
			}
		}
	}
	return combineErrors(errs...)

}

func Stat(name string) (os.FileInfo, error) {
	errs := []error{}
	for try := 1; try <= agent.maxAtemptsAllowed; try++ {
		f, err := os.Stat(name)
		if err != nil {
			errs = append(errs, err)
			time.Sleep(agent.delayExpected)
			continue
		}
		return f, nil
	}
	return nil, combineErrors(errs...)
}

///////////////////////////////////////////

func combineErrors(errs ...error) error {
	errMap := make(map[string]int)
	errNum := 0
	for _, err := range errs {
		if err == nil {
			continue
		}
		errMap[err.Error()]++
		errNum++
	}
	if len(errMap) == 0 {
		return nil
	}
	text := fmt.Sprintf("failed atempts: %v", errNum)
	for k, v := range errMap {
		text += fmt.Sprintf("\n  %v: %v", v, k)
	}
	return fmt.Errorf("%v", text)
}
