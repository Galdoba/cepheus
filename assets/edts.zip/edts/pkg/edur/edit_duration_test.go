package edur

import (
	"fmt"
	"testing"
)

func Test_secondsToFrame(t *testing.T) {

	fmt.Println("3")
	ed, err := FromString("00:00:20:23", FPS_float64(24))
	if err != nil {
		fmt.Println("error:", err)
	}
	fmt.Println(ed.Duration())
	fmt.Println(ed.Timestamp())
	fmt.Println(ed.DurationSrt())
	fmt.Println(ed.SecondsFl64())
	fmt.Println(ed.SecondsStr())
	fmt.Println(ed.FramesTotal)

}
