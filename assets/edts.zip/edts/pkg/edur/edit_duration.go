package edur

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

const (
	timecode = "timecode"
	seconds  = "seconds"
	duration = "duration"
)

type EditDuration struct {
	SecondsTotal      float64
	FramesTotal       int
	Seconds           int
	Minutes           int
	Milliseconds      int
	Hours             int
	Frame             int
	FPS               float64 //default 25.0
	FrameDuration     float64
	MillisecondsTotal int64
}

func newED(opts ...EdurOption) EditDuration {
	ed := EditDuration{}
	ed.FPS = 25.0
	for _, set := range opts {
		set(&ed)
	}
	ed.FrameDuration = (1000 / ed.FPS) / 1000.0
	return ed
}

type EdurOption func(*EditDuration)

func FPS_float64(f float64) EdurOption {
	return func(ed *EditDuration) {
		ed.FPS = f
	}
}

func FromString(str string, opts ...EdurOption) (EditDuration, error) {
	ed := newED(opts...)
	sType, blocks := stringBlocks(str)
	switch sType {
	case seconds:
		ed = fillFromBlocksSeconds(ed, blocks)
	case duration:
		ed = fillFromBlocksDuration(ed, blocks)
	case timecode:
		ed = fillFromBlocksTimestamp(ed, blocks)
		if ed.Frame >= int(ed.FPS) {
			return ed, fmt.Errorf("invalid time code %v for fps=%v", str, ed.FPS)
		}
	default:
		return ed, fmt.Errorf("'%v' is %v", blocks[0], sType)
	}

	return ed, nil
}

func FromFloat64(totalDiration float64, opts ...EdurOption) EditDuration {
	floatStr := fmt.Sprintf("%v", totalDiration)
	ed, _ := FromString(floatStr, opts...)
	return ed
}

/////////////GETTERS

func (ed EditDuration) Duration() string {
	hh := fmt.Sprintf("%v", ed.Hours)
	for len(hh) < 2 {
		hh = "0" + hh
	}
	mm := fmt.Sprintf("%v", ed.Minutes)
	for len(mm) < 2 {
		mm = "0" + mm
	}
	ss := fmt.Sprintf("%v", ed.Seconds)
	for len(ss) < 2 {
		ss = "0" + ss
	}
	ms := fmt.Sprintf("%v", ed.Milliseconds)
	for len(ms) < 3 {
		ms = "0" + ms
	}
	return fmt.Sprintf("%v:%v:%v.%v", hh, mm, ss, ms)

}

func (ed EditDuration) Timestamp() string {
	hh := fmt.Sprintf("%v", ed.Hours)
	for len(hh) < 2 {
		hh = "0" + hh
	}
	mm := fmt.Sprintf("%v", ed.Minutes)
	for len(mm) < 2 {
		mm = "0" + mm
	}
	ss := fmt.Sprintf("%v", ed.Seconds)
	for len(ss) < 2 {
		ss = "0" + ss
	}
	fr := fmt.Sprintf("%v", ed.Frame)
	framePower := len(fmt.Sprintf("%v", int(ed.FPS)))
	for len(fr) < framePower {
		fr = "0" + fr
	}

	return fmt.Sprintf("%v:%v:%v:%v", hh, mm, ss, fr)

}

func (ed EditDuration) DurationSrt() string {
	stamp := ed.Duration()
	return strings.ReplaceAll(stamp, ".", ",")

}

func (ed EditDuration) SecondsStr() string {

	return fmt.Sprintf("%v", ed.SecondsTotal)

}

func (ed EditDuration) SecondsFl64() float64 {
	return ed.SecondsTotal
}

//////////OTHER

func (ed EditDuration) IsAfter(ed2 EditDuration) bool {
	return ed2.SecondsTotal > ed.SecondsTotal
}

func print(ed EditDuration) string {
	s := ""
	s += fmt.Sprintf("hours %v\n", ed.Hours)
	s += fmt.Sprintf("minutes %v\n", ed.Minutes)
	s += fmt.Sprintf("seconds %v\n", ed.Seconds)
	s += fmt.Sprintf("miliseconds %v\n", ed.Milliseconds)
	s += fmt.Sprintf("time %v\n", ed.SecondsTotal)
	s += fmt.Sprintf("frames %v\n", ed.FramesTotal)
	s += fmt.Sprintf("miliseconds total %v\n", ed.MillisecondsTotal)
	s += fmt.Sprintf("FPS %v\n", ed.FPS)
	return s
}

func stringBlocks(str string) (string, []string) {
	sType := "unparseable"
	blocks := []string{}
	re1 := regexp.MustCompile(`(^\d+):(\d+):(\d+):(\d+$)`) //12:23:45:01
	subs1 := re1.FindStringSubmatch(str)
	switch len(subs1) {
	case 5:
		sType = timecode
		blocks = append(blocks, subs1[1:]...)
		return sType, blocks
	}
	re2 := regexp.MustCompile(`(^\d+):(\d+):(\d+)?\.?\,?(\d+$)?`) //12:23:45.01
	subs2 := re2.FindStringSubmatch(str)
	switch len(subs2) {
	case 5:
		sType = duration
		if subs2[4] == "" {
			subs2[4] = "0"
		}
		blocks = append(blocks, subs2[1:]...)
		return sType, blocks
	}
	re3 := regexp.MustCompile(`(^\d+$)`) //12:23:45.01
	subs3 := re3.FindStringSubmatch(str)
	switch len(subs3) {
	case 2:
		sType = seconds
		blocks = append(blocks, subs3[1:]...)
		blocks = append(blocks, "0")
		return sType, blocks
	}
	re4 := regexp.MustCompile(`(^\d+)\.(\d+$)`) //12:23:45.01
	subs4 := re4.FindStringSubmatch(str)
	switch len(subs4) {
	case 3:
		sType = seconds
		blocks = append(blocks, subs4[1:]...)
		return sType, blocks
	}
	blocks = append(blocks, str)
	return sType, blocks
}

const (
	secondsPerHour   = 3600
	secondsPerMinute = 60
)

func fillFromBlocksSeconds(ed EditDuration, blocks []string) EditDuration {
	secRaw, _ := strconv.Atoi(blocks[0])
	if secRaw < 0 {
		return ed
	}
	hours := secRaw / (secondsPerHour)
	for secRaw >= secondsPerHour {
		secRaw -= secondsPerHour
	}
	minutes := secRaw / secondsPerMinute
	for secRaw >= secondsPerMinute {
		secRaw -= secondsPerMinute
	}
	seconds := secRaw
	for len(blocks[1]) < 3 {
		blocks[1] += "0"
	}
	blocks[1] = blocks[1][:3]
	milRaw, _ := strconv.Atoi(blocks[1])
	ed.Hours = hours
	ed.Minutes = minutes
	ed.Seconds = seconds
	ed.Milliseconds = milRaw
	ed.MillisecondsTotal = int64(milRaw) + int64(seconds*1000) + int64(minutes*secondsPerMinute*1000) + int64(hours*secondsPerHour*1000)
	ed.SecondsTotal = float64(ed.MillisecondsTotal) / 1000
	ed.FramesTotal, ed.Frame = countFrames(ed)
	return ed
}

func fillFromBlocksDuration(ed EditDuration, blocks []string) EditDuration {
	secRaw, _ := strconv.Atoi(blocks[2])
	if secRaw < 0 {
		return ed
	}
	hours, _ := strconv.Atoi(blocks[0])
	minutes, _ := strconv.Atoi(blocks[1])
	seconds := secRaw
	for len(blocks[3]) < 3 {
		blocks[3] += "0"
	}
	blocks[3] = blocks[3][:3]
	milRaw, _ := strconv.Atoi(blocks[3])
	ed.Hours = hours
	ed.Minutes = minutes
	ed.Seconds = seconds
	ed.Milliseconds = milRaw
	ed.MillisecondsTotal = int64(milRaw) + int64(seconds*1000) + int64(minutes*secondsPerMinute*1000) + int64(hours*secondsPerHour*1000)
	ed.SecondsTotal = float64(ed.MillisecondsTotal) / 1000
	ed.FramesTotal, ed.Frame = countFrames(ed)
	return ed
}

func fillFromBlocksTimestamp(ed EditDuration, blocks []string) EditDuration {
	secRaw, _ := strconv.Atoi(blocks[2])
	if secRaw < 0 {
		return ed
	}
	hours, _ := strconv.Atoi(blocks[0])
	minutes, _ := strconv.Atoi(blocks[1])
	seconds := secRaw
	frameRaw, _ := strconv.Atoi(blocks[3])
	ed.Hours = hours
	ed.Minutes = minutes
	ed.Seconds = seconds
	ed.Frame = frameRaw
	frameDur := (1000.0 / ed.FPS) / 1000
	milRaw := int(float64(frameRaw) * frameDur * 1000)

	ed.Milliseconds = milRaw
	ed.MillisecondsTotal = int64(milRaw) + int64(seconds*1000) + int64(minutes*secondsPerMinute*1000) + int64(hours*secondsPerHour*1000)
	ed.SecondsTotal = float64(ed.MillisecondsTotal) / 1000
	ed.FramesTotal, _ = countFrames(ed)

	return ed
}

func countFrames(ed EditDuration) (int, int) {
	framesTotal := 0
	frame := 0
	milliseconds := ed.SecondsTotal - float64(int(ed.SecondsTotal))
	for t := 0.0; t < ed.SecondsTotal; t += ed.FrameDuration {
		framesTotal++
	}
	for t := 0.0; t < milliseconds; t += ed.FrameDuration {
		frame++
	}
	if frame >= int(ed.FPS) {
		frame--
	}

	return framesTotal, frame
}

/*
may get
STRING
 01:23:45.678   - Duration/Time
 01:23:45:12	- Timecode
 123456.789 	- Seconds
FLOAT64
 123456.789 	- Seconds
*/

// func ParseSeconds(sec string, options ...EdurOption) (*EditDuration, error) {
// 	ed := newED(options...)
// 	s, err := parseFloat(sec)
// 	if err != nil {
// 		return nil, err
// 	}
// 	ed.SecondsTotal = s
// 	return ed, nil
// }

// func parseFloat(s string) (float64, error) {
// 	f, err := strconv.ParseFloat(s, 64)
// 	if err != nil {
// 		return f, err
// 	}
// 	i := int(f * 1000)
// 	f = float64(i) / 1000
// 	return f, nil
// }

// func timeToSeconds(ts string) (float64, error) {
// 	byDot := strings.Split(ts, ".")
// 	if len(byDot) > 2 {
// 		return 0, fmt.Errorf("more than 1 dot met in %v", ts)
// 	}
// 	bySC := strings.Split(ts, ":")
// 	if len(bySC) > 3 {
// 		return 0, fmt.Errorf("more than 3 semicolons met in %v", ts)
// 	}
// 	floats := []float64{}
// 	for _, s := range bySC {
// 		fl, err := parseFloat(s)
// 		if err != nil {
// 			return 0, err
// 		}
// 		floats = append(floats, fl)
// 	}
// 	slices.Reverse(floats)
// 	sec := 0.0
// 	for i, f := range floats {
// 		switch i {
// 		case 0:
// 			sec = f
// 		case 1:
// 			sec += (f * 60)
// 		case 2:
// 			sec += (f * 60 * 60)
// 		case 3:
// 			sec += (f * 60 * 60 * 24)
// 		}
// 	}
// 	return sec, nil
// }

// func secondsToFrame(time float64, fps float64) int {
// 	step := 1 / fps
// 	frTime := 0.0
// 	frame := 0
// 	for frTime < time {
// 		frame++
// 		frTime += step
// 	}
// 	return frame
// }
