package action

import (
	"fmt"
	"slices"
	"strings"
	"time"

	"github.com/Galdoba/edts/pkg/events"
)

const (
	Cooldown_Argument = "cooldown_argument_"
	Trigger_Argument  = "trigger_argument_"
	Event             = "event_"
)

type Action struct {
	Name             string
	Function         func(...interface{}) error
	Args             map[string]interface{}
	Triggers         []string
	TriggerEvent     events.Event
	Cooldown_Seconds float64
}

func New(name string, fn func(...interface{}) error, options ...ActionOpts) *Action {
	a := Action{}
	a.Name = name
	if a.Name == "" {
		panic("new action must have name")
	}
	a.Function = fn
	if a.Function == nil {
		panic(fmt.Sprintf("action %v must have action func", a.Name))
	}

	return &a
}

func (act *Action) EnrichWith(options ...ActionOpts) {
	opts := defaultActionOpts()
	for _, set := range options {
		set(&opts)
	}
	act.Cooldown_Seconds = opts.cooldown_secs
	act.Triggers = opts.triggers
	act.Args = opts.arguments

}

func (a *Action) ExecByTrigger(e events.Event) (bool, error) {
	if len(a.Triggers) < 1 {
		return false, fmt.Errorf("no triggers to start '%v' action", a.Name)
	}
	eType := e.Type()
	for _, trigger := range a.Triggers {
		if eType == trigger {
			a.TriggerEvent = e
			switch filterArgs(a, Trigger_Argument) {
			case nil:
				return true, a.Function()
			default:
				return true, a.Function(filterArgs(a, Trigger_Argument)...)
			}

		}
	}
	return false, nil
}

func filterArgs(a *Action, argType string) []interface{} {
	var filteredArgs []interface{}
	keys := []string{}
	for k := range a.Args {
		if strings.Contains(k, a.Name+"_"+Trigger_Argument) {
			keys = append(keys, k)
		}
	}
	slices.Sort(keys)
	for _, key := range keys {
		filteredArgs = append(filteredArgs, a.Args[key])

	}
	return filteredArgs
}

func (a *Action) ExecByCooldown(d time.Duration, args ...interface{}) (bool, error) {
	if d.Seconds() >= a.Cooldown_Seconds {
		return true, a.Function(filterArgs(a, Cooldown_Argument)...)
	}
	time.Sleep(time.Millisecond * 100)
	return false, nil
}

/*
 */
type ActionOpts func(*actionopts)

type actionopts struct {
	arguments     map[string]interface{}
	triggers      []string
	cooldown_secs float64
}

func defaultActionOpts() actionopts {
	ao := actionopts{}
	ao.arguments = make(map[string]interface{})
	ao.cooldown_secs = -1
	return ao
}

func Cooldown(cd float64) ActionOpts {
	return func(a *actionopts) {
		a.cooldown_secs = cd
	}
}

func Triggers(triggers []string) ActionOpts {
	return func(a *actionopts) {
		a.triggers = triggers
	}
}

func WithArg(key string, val interface{}) ActionOpts {
	return func(a *actionopts) {
		a.arguments[key] = val
	}
}
