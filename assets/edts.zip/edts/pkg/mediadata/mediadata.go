package mediadata

type Mediadata struct {
	ID            int64
	CurrentName   string
	CurrentDir    string
	LinkedProject string
	FileFPS       string
}

type Stream struct {
	MapKey   string //:a:1
	Codec    string
	Type     string
	Duration float64
	Abitrate int
	Vbitrate int
	Width    int
	Height   int
	FPS      string
	SAR      string
	DAR      string
	Layout   string
	Language string
	Channels int
}


ffmpeg -i input.mp3 -filter_complex  "[0:a]pan=1c|c0=c0,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=channel1.csv[out1];  [0:a]pan=1c|c0=c1,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=channel2.csv[out2]" -f null -
