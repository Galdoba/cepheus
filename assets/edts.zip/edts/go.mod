module github.com/Galdoba/edts

go 1.23.1

require (
	github.com/Galdoba/devtools v0.0.0-20250409033950-2499c3f8c409
	github.com/charmbracelet/bubbles v0.20.0
	github.com/charmbracelet/bubbletea v1.3.0
	github.com/charmbracelet/lipgloss v1.0.0
	github.com/charmbracelet/x/ansi v0.8.0
	github.com/charmbracelet/x/term v0.2.1
	github.com/lucasb-eyer/go-colorful v1.2.0
	github.com/muesli/gamut v0.3.1
	github.com/urfave/cli/v2 v2.27.5
)

require (
	cloud.google.com/go/compute/metadata v0.6.0 // indirect
	github.com/atotto/clipboard v0.1.4 // indirect
	github.com/aymanbagabas/go-osc52/v2 v2.0.1 // indirect
	github.com/catppuccin/go v0.3.0 // indirect
	github.com/charmbracelet/harmonica v0.2.0 // indirect
	github.com/charmbracelet/x/exp/strings v0.0.0-20250207233001-40534c389c2d // indirect
	github.com/dustin/go-humanize v1.0.1 // indirect
	github.com/erikgeiser/coninput v0.0.0-20211004153227-1c3628e74d0f // indirect
	github.com/gookit/color v1.5.4 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mattn/go-localereader v0.0.1 // indirect
	github.com/mattn/go-runewidth v0.0.16 // indirect
	github.com/mitchellh/hashstructure/v2 v2.0.2 // indirect
	github.com/muesli/ansi v0.0.0-20230316100256-276c6243b2f6 // indirect
	github.com/muesli/cancelreader v0.2.2 // indirect
	github.com/muesli/clusters v0.0.0-20200529215643-2700303c1762 // indirect
	github.com/muesli/kmeans v0.3.1 // indirect
	github.com/muesli/termenv v0.15.3-0.20240618155329-98d742f6907a // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	github.com/sahilm/fuzzy v0.1.1 // indirect
	github.com/xo/terminfo v0.0.0-20210125001918-ca9a967f8778 // indirect
	golang.org/x/sync v0.11.0 // indirect
	golang.org/x/sys v0.30.0 // indirect
	golang.org/x/text v0.22.0 // indirect
)

require (
	github.com/Galdoba/gogacon v0.0.0-20250626101603-f2917be71ee3
	github.com/Galdoba/logman v0.0.0-20250723071232-309b0dd5a599
	github.com/charmbracelet/huh v0.6.0
	github.com/cpuguy83/go-md2man/v2 v2.0.6 // indirect
	github.com/fatih/color v1.18.0
	github.com/pelletier/go-toml/v2 v2.2.3
	github.com/russross/blackfriday/v2 v2.1.0 // indirect
	github.com/urfave/cli/v3 v3.3.8
	github.com/xrash/smetrics v0.0.0-20240521201337-686a1a2994c1 // indirect
	golang.org/x/oauth2 v0.26.0
	golang.org/x/term v0.29.0
	gopkg.in/Iwark/spreadsheet.v2 v2.0.0-20230915040305-7677e8164883
	gopkg.in/yaml.v3 v3.0.1
)
