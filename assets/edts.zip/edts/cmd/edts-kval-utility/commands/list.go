package commands

import (
	"fmt"
	"os"
	"strings"

	"github.com/Galdoba/edts/pkg/kval"
	"github.com/urfave/cli/v2"
)

func List() *cli.Command {
	return &cli.Command{
		Name:        "list",
		Usage:       "Get list of key-value pairs",
		UsageText:   "usage text HERE",
		Description: "get list of key-value pairs in the dictinary",
		Args:        true,
		ArgsUsage:   "expect no arguments",
		Action: func(c *cli.Context) error {

			args := kval.List()
			keysRaw := []string{}
			keysWidened := []string{}
			values := []string{}

			var errs []error
			for _, key := range args {
				val, err := kval.Get(key)
				if err != nil {
					errs = append(errs, err)
				}
				keysRaw = append(keysRaw, key)
				values = append(values, val)
			}
			maxLenKey := widestInSlice(keysRaw)
			for _, key := range keysRaw {
				for len(strings.Split(key, "")) < maxLenKey {
					key += " "
				}
				keysWidened = append(keysWidened, key)
			}

			for i := range keysWidened {
				fmt.Printf("%v : %v\n", keysWidened[i], values[i])
			}

			switch len(errs) {
			default:
				fmt.Fprintf(os.Stderr, "%v errors detected:\n", len(errs))
				for _, err := range errs {
					fmt.Fprintf(os.Stderr, "%v", err.Error())
				}
			case 1:
				fmt.Fprintf(os.Stderr, "error detected: %v\n", errs[0].Error())
			case 0:
			}
			return nil
		},
		Flags: []cli.Flag{},
	}
}

func widestInSlice(slice []string) int {
	widest := 0
	for _, val := range slice {
		text := fmt.Sprintf("%v", val)
		l := len(strings.Split(text, ""))
		widest = max(widest, l)
	}
	return widest
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
