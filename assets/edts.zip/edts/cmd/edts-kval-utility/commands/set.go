package commands

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/pkg/kval"
	"github.com/urfave/cli/v2"
)

func Set() *cli.Command {
	return &cli.Command{
		Name:        "set",
		Usage:       "Set new value",
		UsageText:   "usage text HERE",
		Description: "Set value to key in the dictinary",
		Args:        true,
		ArgsUsage:   "expect no arguments",
		Action: func(c *cli.Context) error {
			k := c.String("key")
			v := c.String("value")
			err := kval.Set(k, v)
			if err != nil {
				return err
			}
			_, err = fmt.Fprintf(os.Stderr, "key '%v' set as '%v'", k, v)
			if err != nil {
				return err
			}
			return nil
		},
		Flags: []cli.Flag{
			&cli.StringFlag{
				Name:     "key",
				Category: "mandatory",
				Required: true,
			},
			&cli.StringFlag{
				Name:     "value",
				Category: "mandatory",
				Required: true,
			},
		},
	}
}
