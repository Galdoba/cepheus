package commands

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/pkg/kval"
	"github.com/urfave/cli/v2"
)

func Get() *cli.Command {
	return &cli.Command{
		Name:        "get",
		Usage:       "Get value by key",
		UsageText:   "edts-kval-utility get [arguments]\n  -arguments are keys to search in dictionary",
		Description: "get value to key in the dictinary",
		Args:        true,
		ArgsUsage:   "expect no arguments",
		Action: func(c *cli.Context) error {
			args := c.Args().Slice()
			if len(args) == 0 {
				fmt.Fprintf(os.Stderr, "no args provided")
				return nil
			}
			var errs []error
			for _, arg := range args {
				val, err := kval.Get(arg)
				if err != nil {
					errs = append(errs, err)
				}
				_, err = fmt.Fprintf(os.Stdout, "%v", val)
				if err != nil {
					errs = append(errs, err)
				}
			}

			switch len(errs) {
			default:
				fmt.Fprintf(os.Stderr, "%v errors detected:\n", len(errs))
				for _, err := range errs {
					fmt.Fprintf(os.Stderr, "%v", err.Error())
				}
			case 1:
				fmt.Fprintf(os.Stderr, "error detected: %v\n", errs[0].Error())
			case 0:
			}
			return nil
		},
		Flags: []cli.Flag{},
	}
}
