package main

/*
edts-kval-utility set
edts-kval-utility get
edts-kval-utility list [-filter]
edts-kval-utility search (tea-app)
edts-kval-utility stats
*/

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/cmd/edts-kval-utility/commands"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/urfave/cli/v2"
)

func main() {
	appName := definitions.UTILITY_KVAL
	app := cli.NewApp()
	app.Name = appName
	app.Usage = "administering key-value dictionary"
	app.Version = definitions.Version(app.Name)

	//ДО НАЧАЛА ДЕЙСТВИЯ
	app.Before = func(c *cli.Context) error {
		fmt.Fprintf(os.Stderr, "%v version %v\n", c.App.Name, c.App.Version)
		return nil
	}
	//ПО ОКОНЧАНИЮ ДЕЙСТВИЯ
	app.After = func(c *cli.Context) error {
		return nil
	}
	app.Commands = []*cli.Command{
		commands.Set(),
		commands.Get(),
		commands.List(),
	}
	args := os.Args
	if err := app.Run(args); err != nil {
		errOut := fmt.Sprintf("error: %v: %v", app.Name, err.Error())
		println(errOut)
		os.Exit(1)
	}
}
