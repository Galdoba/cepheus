package commands

import (
	"fmt"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-renamer/model"
	"github.com/Galdoba/edts/internal/btblocks/querry"
	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/Galdoba/edts/pkg/translit"
	"github.com/urfave/cli/v2"
)

type renamer struct {
	TableDB         *db.Database
	SpreadsheetRows []transcode.SheetRow
	ProjectData     map[string]*transcode.Project
}

const (
// listFile = "list.dts"
)

func Rename() *cli.Command {
	return &cli.Command{
		Name:        "rename",
		Aliases:     []string{},
		Usage:       "check script writer's infrastructure",
		UsageText:   fmt.Sprintf("%v health", definitions.UTILITY_SCRIPT_WRITER),
		Description: "report status of script writer tool",
		Args:        false,
		ArgsUsage:   "Args Usage Text",
		Category:    "",
		Before: func(c *cli.Context) error {
			return nil
		},
		Action: func(c *cli.Context) error {
			renm := model.New()
			renm.AddQuery(TypeQuery)
			fmt.Println("films")
			films, err := model.ListProjects(renm.DB)
			if err != nil {
				return err
			}
			for i, name := range films {
				fmt.Printf("%v\t%v\n", i, name)
			}
			fmt.Println("trailers")
			trls, err := model.ListTrailers(renm.DB)
			if err != nil {
				return err
			}
			renm.AddQuery(NameQuery(films...))
			renm.AddQuery(NameQuery(trls...))
			q := QuerryFunc("a")
			renm.AddQuery(q("a"))
			for i, name := range trls {
				fmt.Printf("%v\t%v\n", i, name)
			}
			return nil
		},

		Flags: []cli.Flag{},
	}
}

var TypeQuery = querry.New(
	querry.WithTitle("Тип исходника:"),
	querry.WithItems(
		querry.NewItem(querry.WithKey("TRL"), querry.WithDescription("трейлер")),
		querry.NewItem(querry.WithKey("FILM"), querry.WithDescription("фильм")),
	),
	querry.WithDescriptionUsage(true),
)

func NameQuery(films ...string) querry.QuerryModel {
	items := []querry.Item{}
	for _, film := range films {
		items = append(items, querry.NewItem(querry.WithKey(film)))
	}
	return querry.New(
		querry.WithTitle("Название фильма в таблице:"),
		querry.WithItems(items...),
		querry.WithDescriptionUsage(false),
	)
}

func QuerryFunc(name string) func(string) querry.QuerryModel {
	return func(s string) querry.QuerryModel {
		translited := translit.String(s, translit.KeepRegister())
		words := strings.Split(translited, "_")

		items := []querry.Item{}
		for i := range words {
			candidate := strings.Join(words[:i], "_")
			items = append(items, querry.NewItem(querry.WithKey(candidate)))
		}
		return querry.New(
			querry.WithTitle("Префикс для файлов:"),
			querry.WithItems(items...),
			querry.WithDescriptionUsage(false),
		)
	}
}

//type Queryf func(string) querry.QuerryModel
