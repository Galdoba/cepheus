package main

/*
обновляем списки содержимого в заданных директориях
отсылаем брокеру эвенты с изменениями
все пути в конфигах
своих логов нет?
*/
import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/cmd/edts-renamer/commands"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/urfave/cli/v2"
)

func main() {
	appName := definitions.UTILITY_RENAMER
	app := cli.NewApp()
	app.Name = appName
	app.Usage = "add project prefixes"
	app.Version = "0.1.0 [build 6]" //#gvc: version control token

	app.Commands = []*cli.Command{
		commands.Rename(),
	}
	args := os.Args
	if err := app.Run(args); err != nil {
		errOut := fmt.Sprintf("error: %v: %v", app.Name, err.Error())
		println(errOut)
		os.Exit(1)
	}
}
