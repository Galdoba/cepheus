package model

import (
	"encoding/json"

	"github.com/Galdoba/edts/internal/btblocks/querry"
	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/Galdoba/gogacon"
)

type RenamerConfig struct {
	BufferDirectory string `json:"buffer directory"`
	DB_Path         string `json:"path to database"`
}

func (rc *RenamerConfig) Marshal() ([]byte, error) {
	return json.Marshal(rc)
}

func (rc *RenamerConfig) Unmarshal(data []byte) error {
	return json.Unmarshal(data, rc)
}

type RenamerModel struct {
	Config  RenamerConfig
	queries []querry.QuerryModel
	Stack   querry.Stack
	DB      *db.Database
}

func New() RenamerModel {
	rn := RenamerModel{}
	cm, err := gogacon.NewConfigManager(gogacon.Defaults{
		AppName: definitions.UTILITY_RENAMER,
		DefaultConfigValues: &RenamerConfig{
			BufferDirectory: `\\192.168.31.4\buffer\IN\`,
			DB_Path:         `c:\Users\pemaltynov\Programs\galdoba\edts\edts-spreadsheet-tracker-service\storage\spreadsheet_data.json`,
		},
	})
	if err != nil {
		panic(err)
	}
	if err := cm.LoadConfig("", &rn.Config); err != nil {
		panic(err)
	}

	rn.DB = db.Create(rn.Config.DB_Path, db.TYPE_SPREADSHEET)

	rn.Stack = querry.NewQueryStack(
		querry.New(
			querry.WithTitle("Тип исходника:"),
			querry.WithItems(
				querry.NewItem(querry.WithKey("TRL"), querry.WithDescription("трейлер")),
				querry.NewItem(querry.WithKey("FILM"), querry.WithDescription("фильм")),
			),
			querry.WithDescriptionUsage(true),
		),
	)

	return rn
}

func (m *RenamerModel) AddQuery(q querry.QuerryModel) {
	m.queries = append(m.queries, q)
}

type PrjectCandidate struct {
	TableName     string
	OutCandidates []string
	OutName       string
}

func ListProjects(prdb *db.Database) ([]string, error) {
	sprshtRows, err := transcode.SheetRows(prdb)
	if err != nil {
		return nil, err
	}
	list := []string{}
	for _, row := range sprshtRows {
		if !row.IsProject() {
			continue
		}
		switch row.Status() {
		case transcode.Status_CLOSED, transcode.Status_REJECTED:
			continue
		default:
			if isGreen(row.Cells[10].Text) {
				continue
			}
			if row.Cells[9].Text == "" {
				continue
			}
			if row.Cells[1].Text != "" {
				continue
			}
			list = append(list, row.Cells[8].Text)
		}
	}
	return list, nil
}

func ListTrailers(prdb *db.Database) ([]string, error) {
	sprshtRows, err := transcode.SheetRows(prdb)
	if err != nil {
		return nil, err
	}
	list := []string{}
	for _, row := range sprshtRows {
		if !row.IsProject() {
			continue
		}
		switch row.Status() {
		case transcode.Status_CLOSED, transcode.Status_REJECTED:
			continue
		default:
			if !isRed(row.Cells[2].Text) {
				continue
			}

			list = append(list, row.Cells[8].Text)
		}
	}
	return list, nil
}

func isGreen(text string) bool {
	switch text {
	case "G", "g", "П", "п":
		return true
	}
	return false
}

func isRed(text string) bool {
	switch text {
	case "R", "r", "К", "к":
		return true
	}
	return false
}
