package commands

import (
	"errors"
	"fmt"
	"os"
	"slices"
	"time"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/pkg/atempted"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/urfave/cli/v2"
)

var blackList = make(map[string]int)

func Run() *cli.Command {
	return &cli.Command{
		Name:        "run",
		Aliases:     []string{},
		Usage:       "normalize names for new names",
		UsageText:   fmt.Sprintf("%v run", definitions.SERVICE_FILENAME_NORMALIZER),
		Description: "Service will read other edts apps events and forward it to consumers.",
		Args:        false,
		ArgsUsage:   "Args Usage Text",
		Category:    "",
		Before: func(c *cli.Context) error {

			return nil
		},
		Action: func(c *cli.Context) error {
			//INIT
			//cfg, err := initConfig(c.String("config"), c.App.Version)

			cfg, err := masterconfig.Read()
			if err != nil {
				return fmt.Errorf("service initialisation failed: %v\n", err)
			}
			loadConfiguration(cfg, c.App.Name)
			if err != nil {
				return fmt.Errorf("service config initialisation failed: %v\n", err)
			}
			atempted.SetMaxAtempts(config.maxRetryAtempts)
			atempted.SetDelay(time.Millisecond * time.Duration(config.delay))
			// events.SetOutbox(config.outbox)
			events.SetupPublisher(c.App.Name, config.outbox)
			//START
			if err := events.PublishNewEvent(events.MODULE_STARTED); err != nil {
				fmt.Fprintf(os.Stderr, "%v\n", err)
			}
			fmt.Println(c.App.Name, "started")

		mainLoop:
			for {
				time.Sleep(time.Millisecond * 50)
				printBlackList()
				//collect events:
				if err := collectEvents(); err != nil {
					fmt.Fprintf(os.Stderr, "%v\n", err)
					continue mainLoop
				}
				//process events:
				if err := processEvents(); err != nil {
					fmt.Fprintf(os.Stderr, "%v\n", err)
					continue mainLoop
				}

			}
		},

		Flags: []cli.Flag{},
	}
}

func collectEvents() error {
	for producer, outbox := range config.outboxList {
		fi, err := atempted.ReadDir(outbox)
		if err != nil {
			return fmt.Errorf("failed to read %v outbox (%v):\n%v", producer, outbox, err)
		}

		for _, f := range fi {
			path := outbox + f.Name()
			fmt.Println(path)
			_, err := events.Read(path)
			if err != nil {
				blackList[path]++
				panic(2)
				return fmt.Errorf("add to black list: %v", path)
			}

			if err := atempted.Rename(path, config.inbox+f.Name()); err != nil {
				//panic(1)
				return fmt.Errorf("failed to collect %v:\n%v", f.Name(), err)
			}
		}
	}
	return nil
}

func processEvents() error {
	inbox := config.inbox
	outbox := config.outbox
	fi, err := atempted.ReadDir(inbox)
	if err != nil {
		return fmt.Errorf("failed to read inbox:\n%v", err)
	}
	fmt.Printf("events in queue: %v            \r", len(fi))
	for _, f := range fi {
		path := inbox + f.Name()
		target := outbox + f.Name()

		eventData, err := events.Read(path)
		if err != nil {
			return fmt.Errorf("add to black list: %v", path)
		}

		copies := []string{}
		for name, subscrbtions := range config.subscribtions {
			for _, eventType := range subscrbtions {
				if eventType != eventData[events.Key_EventType] {
					continue
				}
				copies = append(copies, config.inboxPathMap[name]+f.Name())
			}
		}
		for _, copyPath := range copies {
			fmt.Println("send copy:", copyPath)
			if err := copy(path, copyPath); err != nil {
				panic(err.Error())
			}
		}

		if atempted.Rename(path, target) != nil {
			return fmt.Errorf("failed to put event (%v_%v) to outbox:\n%v", eventData[events.Key_EventTimestamp], eventData[events.Key_EventType], err)
		}
	}
	return nil
}

func createEventFile(dir string, e events.Event) (*os.File, error) {
	evType := e.Type()
	evTime := e.TimeNano()
	errMap := make(map[string]int)
	for i := 0; i < 500; i++ {
		tm := evTime + int64(i)
		file, err := atempted.OpenFile(dir+fmt.Sprintf("%v_%v.event", tm, evType), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0666)
		if err == nil {
			return file, nil
		}
		errMap[err.Error()]++
		tm++
	}
	str := "combined error:"
	for k, v := range errMap {
		str += fmt.Sprintf("\n%v: %v", v, k)
	}
	return nil, errors.New(str)
}

func printBlackList() {
	if len(blackList) == 0 {
		return
	}
	keys := []string{}
	for k := range blackList {
		keys = append(keys, k)
	}
	slices.Sort(keys)
	for _, k := range keys {
		fmt.Println(k, blackList[k])
	}
}

type serviceConfiguration struct {
	collectFrom     []string
	outboxList      []string
	subscribtions   map[string][]string
	inboxPathMap    map[string]string
	maxRetryAtempts int
	delay           int
	inbox           string
	outbox          string
	cooldown        int
}

var config *serviceConfiguration

func loadConfiguration(mcfg *masterconfig.MasterConfig, app string) error {
	config = &serviceConfiguration{}
	config.maxRetryAtempts = mcfg.Service_RetryAttempts[app]
	config.delay = mcfg.Service_RetryDelay_Milliseconds[app]
	config.inbox = mcfg.Service_Paths[app][masterconfig.KEY_INBOX]
	config.outbox = mcfg.Service_Paths[app][masterconfig.KEY_OUTBOX]
	config.cooldown = mcfg.Service_Cooldown[app]
	config.subscribtions = mcfg.Service_EventSubscribtions

	config.inboxPathMap = make(map[string]string)
	for name, paths := range mcfg.Service_Paths {

		switch name {
		default:
			config.outboxList = append(config.outboxList, paths[masterconfig.KEY_OUTBOX])
			config.inboxPathMap[name] = paths[masterconfig.KEY_INBOX]
		case app:
		}
	}

	return nil
}

func copy(src string, dst string) error {
	data, err := os.ReadFile(src)
	if err != nil {
		return fmt.Errorf("failed to read event file content")
	}
	err = os.WriteFile(dst, data, 0644)
	if err != nil {
		return fmt.Errorf("failed to write event file copy")
	}
	return nil
}
