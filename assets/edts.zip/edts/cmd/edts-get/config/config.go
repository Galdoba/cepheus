package config

import "github.com/pelletier/go-toml/v2"

type Config struct {
	Log Logging     `toml:"logging"`
	Env Environment `toml:"environment"`
}

type Logging struct {
	Enabled bool   `toml:"enabled"`
	Console bool   `toml:"console"`
	File    string `toml:"file"`
	Level   string `toml:"level"`
}

type Environment struct {
	ProjectActiveDirectory  string `toml:"active projects"`
	SkipSearchActive        bool   `toml:"skip search in active projects"`
	ProjectArchiveDirectory string `toml:"archive projects"`
	SkipSearchArchive       bool   `toml:"skip search in archived projects"`
}

func (cfg *Config) Marshal() ([]byte, error) {
	return toml.Marshal(cfg)
}

func (cfg *Config) Unmarshal(data []byte) error {
	return toml.Unmarshal(data, cfg)
}
