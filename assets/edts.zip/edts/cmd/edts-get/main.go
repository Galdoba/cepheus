package main

/*
edts-kval-utility set
edts-kval-utility get
edts-kval-utility list [-filter]
edts-kval-utility search (tea-app)
edts-kval-utility stats
*/

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-get/config"
	"github.com/Galdoba/edts/internal/cli/actions"
	"github.com/Galdoba/edts/pkg/flags"
	"github.com/Galdoba/gogacon"
	"github.com/Galdoba/logman"
	"github.com/Galdoba/logman/colorizer"
	"github.com/urfave/cli/v3"
)

func main() {
	appName := "edts-get"
	cfg, err := initConfig(appName)
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to init config: %v", err)
		os.Exit(1)
	}
	if err := initLogger(cfg); err != nil {
		fmt.Fprintf(os.Stderr, "failed to init config: %v", err)
		os.Exit(1)
	}

	cmd := cli.Command{
		Name:     appName,
		Usage:    "get data from edts projects",
		Version:  "0.0.0",
		Commands: []*cli.Command{},
		Flags: []cli.Flag{
			flags.TestFlag,
		},
		Action: actions.EdtsGetProjectData,
		Metadata: map[string]interface{}{
			"config": cfg,
		},
	}
	if err := cmd.Run(context.Background(), os.Args); err != nil {
		fmt.Printf("err: %v", err)
	}

}

func initConfig(appName string) (*config.Config, error) {
	cfg := &config.Config{
		Log: config.Logging{
			Enabled: true,
			Console: true,
			File:    "",
			Level:   "",
		},
		Env: config.Environment{
			ProjectActiveDirectory:  "",
			SkipSearchActive:        true,
			ProjectArchiveDirectory: "",
			SkipSearchArchive:       true,
		},
	}
	cm, err := gogacon.NewConfigManager(gogacon.Defaults{
		AppName:             appName,
		DefaultConfigValues: cfg,
	})
	if err != nil {
		return nil, err
	}
	if err := cm.LoadConfig("", cfg); err != nil {
		return nil, err
	}
	return cfg, nil
}

func initLogger(cfg *config.Config) error {
	logOptions := []logman.LogmanOptions{}
	imp := logman.ImportanceINFO
	lv := strings.ToLower(cfg.Log.Level)
	switch lv {
	case "fatal":
		imp = logman.ImportanceFATAL
	case "error":
		imp = logman.ImportanceERROR
	case "warn":
		imp = logman.ImportanceWARN
	case "info":
		imp = logman.ImportanceINFO
	case "debug":
		imp = logman.ImportanceDEBUG
	}
	if !cfg.Log.Enabled {
		imp = logman.ImportanceNONE
	}
	logOptions = append(logOptions, logman.WithAppLogLevelImportance(imp))
	logOptions = append(logOptions, logman.WithGlobalColorizer(colorizer.DefaultScheme()))
	if cfg.Log.File != "" {
		logOptions = append(logOptions, logman.WithGlobalWriterFormatter(cfg.Log.File, logman.NewFormatter(logman.WithRequestedFields(logman.Request_ShortTime))))
	}
	return logman.Setup(logOptions...)
}
