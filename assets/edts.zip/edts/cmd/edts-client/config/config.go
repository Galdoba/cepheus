package config

import (
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
)

type ClientConfiguration struct {
	TableDBFile        string
	FilesDBFile        string
	ProjectStorageDir  string
	SourceDir          string
	BrokerEventStorage string
	Inbox              string
	Outbox             string
	EditPath           string
	ArchivePath        string
	FileAssoc          map[string]string
	// EDITOR             string
	// PLAYER             string
}

var config *ClientConfiguration

func LoadConfiguration(mcfg *masterconfig.MasterConfig, app string) error {
	config = &ClientConfiguration{}
	config.TableDBFile = mcfg.Service_Values[definitions.SERVICE_SPREADSHEET_TRACKER][masterconfig.KEY_DB_FILEPATH]
	config.FilesDBFile = mcfg.Service_Values[definitions.SERVICE_DIRECTORY_TRACKER][masterconfig.KEY_DB_FILEPATH]
	config.ProjectStorageDir = mcfg.Service_Paths[app][masterconfig.KEY_STORAGE]
	config.SourceDir = mcfg.Global_Paths[masterconfig.Path_EDTS_IN]
	config.Inbox = mcfg.Service_Paths[app][masterconfig.KEY_INBOX]
	config.Outbox = mcfg.Service_Paths[app][masterconfig.KEY_OUTBOX]
	config.BrokerEventStorage = mcfg.Service_Paths[definitions.SERVICE_EVENT_BROKER][masterconfig.KEY_OUTBOX]
	config.EditPath = mcfg.Global_Paths[masterconfig.Path_EDTS_OUT]
	config.ArchivePath = mcfg.Global_Paths[masterconfig.Path_EDTS_ARCHIVE]
	config.FileAssoc = mcfg.Client_File_Associations
	return nil
}

func Config() *ClientConfiguration {
	return config
}
