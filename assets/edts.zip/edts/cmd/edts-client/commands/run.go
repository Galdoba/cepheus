package commands

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
	"sync"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client"
	"github.com/Galdoba/edts/cmd/edts-client/config"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/pkg/events"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/urfave/cli/v2"
)

var commandsExecs []exec.Cmd

func Run() *cli.Command {
	return &cli.Command{
		Name:        "run",
		Aliases:     []string{},
		Usage:       "normalize names for new names",
		UsageText:   fmt.Sprintf("%v run", definitions.SERVICE_SPREADSHEET_TRACKER),
		Description: "Service will update file with data from work table by cooldown and by request",
		Args:        false,
		ArgsUsage:   "Args Usage Text",
		Category:    "",
		Before: func(c *cli.Context) error {

			return nil
		},
		Action: func(c *cli.Context) error {
			//INIT
			if c.Bool("services") {
				startApps()
			}

			cfg, err := masterconfig.Read()
			if err != nil {
				return err
			}

			if err := config.LoadConfiguration(cfg, c.App.Name); err != nil {
				return err
			}
			configLocal := config.Config()
			//events.SetOutbox(configLocal.Outbox)
			events.SetupPublisher(c.App.Name, configLocal.Outbox)

			client := client.NewClient(configLocal)
			if err := events.PublishNewEvent(events.MODULE_STARTED); err != nil {
				fmt.Fprintf(os.Stderr, "%v\n", err)
			}
			// //fmt.Println(config)
			p := tea.NewProgram(client)
			if _, err := p.Run(); err != nil {
				fmt.Printf("Alas, there's been an error: %v", err)
				os.Exit(1)
			}
			return nil //fmt.Errorf("actiom nt implemented")
		},

		Flags: []cli.Flag{
			&cli.BoolFlag{
				Name:    "services",
				Usage:   "edts-client run -services",
				Aliases: []string{"s"},
			},
		},
	}
}

// type ClientConfiguration struct {
// 	TableDBFile string
// 	FilesDBFile string
// 	Inbox       string
// 	Outbox      string
// }

// var config *ClientConfiguration

// func loadConfiguration(mcfg *masterconfig.MasterConfig, app string) error {
// 	config = &ClientConfiguration{}
// 	config.TableDBFile = mcfg.Service_Values[definitions.SERVICE_SPREADSHEET_TRACKER][masterconfig.KEY_DB_FILEPATH]
// 	config.FilesDBFile = mcfg.Service_Values[definitions.SERVICE_DIRECTORY_TRACKER][masterconfig.KEY_DB_FILEPATH]
// 	config.Inbox = mcfg.Service_Paths[app][masterconfig.KEY_INBOX]
// 	config.Outbox = mcfg.Service_Paths[app][masterconfig.KEY_OUTBOX]
// 	return nil
// }

func startApps() {
	gopath := os.Getenv("GOPATH")
	if gopath == "" {
		panic("GOPATH enviroment variable is not set (or empty)")
	}
	services := []string{
		definitions.SERVICE_EVENT_BROKER,
		definitions.SERVICE_SPREADSHEET_TRACKER,
		definitions.SERVICE_DIRECTORY_TRACKER,
		definitions.SERVICE_FILENAME_NORMALIZER,
	}
	gopath = strings.ReplaceAll(gopath, `\`, "/")
	var wg sync.WaitGroup
	//commandsExecs := []exec.Cmd{}
	for _, app := range services {

		nextCommW := exec.Cmd{}
		nextCommW.Path = fmt.Sprintf("%v/bin/%v.exe", gopath, app)
		nextCommW.Args = append(nextCommW.Args, "run")

		commandsExecs = append(commandsExecs, nextCommW)
	}

	for x := 0; x < len(commandsExecs); x++ {
		wg.Add(1)
		fmt.Println("starting up", commandsExecs[x].Path)
		go initialize(&wg, commandsExecs[x])
	}

}

func initialize(wg *sync.WaitGroup, ccmds exec.Cmd) {
	defer wg.Done()
	fmt.Println("initializing", ccmds.Path)
	if err := ccmds.Run(); err != nil {
		fmt.Println(err)
	}

	fmt.Println("started", ccmds.Path)
	// if err := ccmds.Wait(); err != nil {
	// 	fmt.Println(",,,", err)
	// }
}
