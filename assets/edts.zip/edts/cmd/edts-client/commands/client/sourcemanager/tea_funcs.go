package sourcemanager

import (
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	tea "github.com/charmbracelet/bubbletea"
)

func (sm *SourceManager) Init() tea.Cmd {

	return nil
}

func (sm *SourceManager) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	var cmd tea.Cmd
	switch msg := msg.(type) {
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "esc", "left":
			cmds = append(cmds, teacmd.ChangeView(currentView, clientcontext.ViewMain()))
		case "enter", "right":
			//cmds = append(cmds, open)
			cursor := sm.Table.Cursor()
			if cmd := sm.Open(cursor); cmd != nil {
				cmds = append(cmds, cmd)
			}
		default:
			sm.Table, cmd = sm.Table.Update(msg)
			cmds = append(cmds, cmd)
		}

	}
	return sm, tea.Batch(cmds...)
}

func (sm *SourceManager) View() string {
	return sm.Table.View()
}
