package sourcemanager

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/columns"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/styles"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/tiler"
	"github.com/Galdoba/edts/pkg/ump"
	"github.com/charmbracelet/bubbles/table"
	tea "github.com/charmbracelet/bubbletea"
)

type SourceManager struct {
	Sources          []SourceFileInfo
	FileAssosiations map[string]string
	Table            table.Model
}

var currentView int

func NewSourceManager(fassoc map[string]string) *SourceManager {
	sm := SourceManager{}
	sm.FileAssosiations = fassoc
	sm.Table = table.New(
		table.WithColumns(
			columns.SourcesTableColumns(tiler.BlocksHorisontal(1)),
		),
		table.WithHeight(tiler.BlocksVertical(1)-2),
		table.WithStyles(styles.SourceTableStyle()),
		table.WithFocused(true),
	)
	if err := sm.fill(); err != nil {
		panic("failed to fill order table")
	}
	currentView = clientcontext.ViewSources()

	return &sm
}

func (sm *SourceManager) fill() error {
	sourceDir := clientcontext.Get(clientcontext.CTX_SourceDir)
	fi, err := os.ReadDir(sourceDir)
	if err != nil {
		return nil
	}
	paths := []string{}
	for _, f := range fi {
		if f.IsDir() {
			continue
		}
		paths = append(paths, sourceDir+`/`+f.Name())
	}
	for _, path := range paths {
		src := Evaluate(path)
		ext := filepath.Ext(path)
		if opener, ok := sm.FileAssosiations[ext]; ok {
			src.Opener = opener
		} else {
			src.Opener = sm.FileAssosiations["default"]
		}
		sm.Sources = append(sm.Sources, src)
	}
	rows := []table.Row{}
	for _, src := range sm.Sources {
		rows = append(rows, table.Row{src.Name, src.Profile, src.Opener})
	}
	if len(rows) == 0 {
		rows = append(rows, table.Row{"НЕТ ВХОДЯШИХ ФАЙЛОВ", "", "Вернуться"})
	}

	sm.Table.SetRows(rows)
	return nil
}

func (sm *SourceManager) Open(i int) tea.Cmd {
	if len(sm.Sources) == 0 {
		return teacmd.ChangeView(clientcontext.ViewSources(), clientcontext.ViewMain())
	}
	src := sm.Sources[i]
	srcPath := src.Dir + src.Name
	srcPath = strings.ReplaceAll(srcPath, `/`, `\`)
	args := []string{}
	//args = append(args, "/C", "start")
	switch src.Opener {
	case "explorer":
		args = append(args, srcPath)
	case "ffplay":
		args = append(args, "-i")
		args = append(args, srcPath)
	}
	cmd := exec.Command(src.Opener, args...)
	cmd.Run()

	return nil

}

func (sm *SourceManager) OpenByIndex(i int) error {
	src := sm.Sources[i]
	cmd := exec.Cmd{}
	cmd.Path = src.Opener
	cmd.Args = append(cmd.Args, src.Dir+src.Name)
	return cmd.Run()
}

type SourceFileInfo struct {
	Dir     string
	Name    string
	Profile string
	Opener  string
}

func Evaluate(path string) SourceFileInfo {
	dir := filepath.Dir(path) + "/"
	name := filepath.Base(path)
	profile, _ := profile(path)

	si := SourceFileInfo{}
	si.Dir = dir
	si.Name = name
	si.Profile = profile
	//si.Opener = `C:\Windows\Explorer.exe`
	si.Opener = `explorer`
	ext := filepath.Ext(path)
	switch ext {
	// case ".srt", ".txt":
	// 	si.Opener = `C:\Program Files\Notepad++\notepad++.exe`
	// case ".mov", ".mp4":
	// 	//si.Opener = `C:\Program Files\DAUM\PotPlayer\PotPlayerMini64.exe`
	case ".jpeg", ".jpg":
		//si.Opener = "ffplay"
	default:
		//		si.Opener = "explorer"
		//panic(fmt.Sprintf("extention %v is unknown to open", ext))
	}
	return si
}

func profile(path string) (string, error) {
	mp := ump.NewProfile()
	if err := mp.ConsumeFile(path); err != nil {
		return "???", err
	}
	return mp.Short(), nil
}

/*
c:\totalcmd\TOTALCMD64.EXE
*/
