package teamsg

import (
	"os"
	"time"

	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
)

type NavigationMsg struct {
	InitialView int
	TargetView  int
}

type TickMsg time.Time

type SpreadsheetUpdatedMsg bool

type SpreadsheetUpdateRequestedMsg string

type PathToSpreadsheetRequestedMsg string

func SpreadsheetUpdated(inbox string) SpreadsheetUpdatedMsg {
	update := false

	fi, _ := os.ReadDir(inbox)
	for _, f := range fi {
		if f.IsDir() {
			continue
		}
		path := inbox + f.Name()
		eventData, err := events.Read(path)
		if err != nil {
			continue
		}
		if eventData[events.Key_EventType] == events.WORKSHEET_UPDATED {
			update = true
		}
		os.Remove(path)
	}
	return SpreadsheetUpdatedMsg(update)
}

type SpawnEventMsg string

func SpawnEvent(msgType string, paydata map[string]string) SpawnEventMsg {
	load := []payload.PayloadData{}
	for k, v := range paydata {
		load = append(load, payload.String(k, v))
	}
	events.PublishNewEvent(msgType, load...)
	return SpawnEventMsg(msgType)
}
