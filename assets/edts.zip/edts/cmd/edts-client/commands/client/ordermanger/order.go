package ordermanger

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/columns"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/helpers"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/styles"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/tiler"
	"github.com/Galdoba/edts/internal/transcode"

	//	"github.com/Galdoba/edts/internal/transcode/product"
	"github.com/charmbracelet/bubbles/table"
	tea "github.com/charmbracelet/bubbletea"
)

const (
	Action_Add_Key           = "Выбрать ключ"
	Action_Edit_Key          = "Редактировать ключ"
	Action_Add_TargetRequest = "Добавить задачу"
	Action_Set_Sources       = "Выбрать источники"
	Action_Delete            = "Удалить"
	Action_Confirm           = "Подтвердить"
	Action_Set_Path          = "(p) Поставить в таблицу"

	Block_Project_Info             = "ПРОЕКТ"
	Block_Project_Common           = "ДЛЯ ПРОСЧЕТА"
	Block_Project_Product_Requests = "ЗАДАЧИ"

	Block_Key_RequestType    = "тип задачи:"
	Block_Key_RequestSources = "источники:"
	Block_Key_RequestSchemma = "тип просчета:"

	Field_Edit_Prefix  = "Префикс имён файлов"
	Field_Edit_Path    = "Путь для просчета"
	Field_Archive_Path = "Путь в архив"
	Field_Title        = "Наименование"
	Field_Date         = "Дата публикации"
	Field_Agent        = "Контрагент"
	Field_Comment      = "Комментарий"
)

var editPathKey string
var archivePathKey string
var currentView int

type OrderTable struct {
	Table  table.Model
	Source *transcode.Project
}

func NewOrderTable(src *transcode.Project) OrderTable {
	if src == nil {
		panic("no source provided")
	}
	ot := OrderTable{}
	//panic(src)
	ot.Source = src
	ot.Table = table.New(
		table.WithColumns(
			columns.OrderTableColumns(tiler.BlocksHorisontal(1)),
		),
		table.WithHeight(tiler.BlocksVertical(1)-2),
		table.WithStyles(styles.OrderTableStyle()),
		table.WithFocused(true),
	)
	if err := ot.fill(); err != nil {
		panic("failed to fill order table")
	}
	editPathKey = clientcontext.Get(clientcontext.CTX_EditPath)
	archivePathKey = clientcontext.Get(clientcontext.CTX_Archive)
	currentView = clientcontext.ViewProject()
	return ot
}

func (ot *OrderTable) fill() error {
	data := [][]string{}
	data = append(data, ot.blockProjectInfo()...)
	data = append(data, ot.blockProjectCommon()...)
	//data = append(data, ot.blockProjectTargets()...)

	for i, key := range helpers.SortedKeys(ot.Source.SourceMap) {
		data = append(data, []string{fmt.Sprintf("  %v", i+1), key, "", ""})
	}
	rows := []table.Row{}
	for _, pseudo := range data {
		rows = append(rows, pseudo)
	}
	ot.Table.SetRows(rows)
	ot.setCursor()
	return nil
}

func (ot *OrderTable) blockProjectInfo() [][]string {
	data := [][]string{}
	data = append(data, []string{Block_Project_Info, "", "", ""})
	data = append(data, []string{"", Field_Title, ot.Source.Title, ""})
	data = append(data, []string{"", Field_Date, ot.Source.DateBlock, ""})
	data = append(data, []string{"", Field_Agent, ot.Source.Agent, ""})
	data = append(data, []string{"", Field_Comment, ot.Source.Comment, ""})
	data = append(data, []string{"", "", "", ""})

	return data
}

func (ot *OrderTable) blockProjectCommon() [][]string {

	data := [][]string{}
	data = append(data, []string{Block_Project_Common, "", "", ""})
	data = append(data, []string{"", Field_Edit_Prefix, ot.Source.ConfirmedBase, keyAction(ot.Source.ConfirmedBase)})
	if ot.Source.ConfirmedBase != "" {
		editPath, archivePath := helpers.OutPaths(ot.Source)
		//////
		action := ""
		if editPath != "" {
			action = Action_Set_Path
		}
		data = append(data, []string{"", Field_Edit_Path, editPath, action})
		data = append(data, []string{"", Field_Archive_Path, archivePath, ""})
		data = append(data, []string{"", "", "", ""})
		//data = append(data, ot.blockProjectTargets()...)
	}
	data = append(data, ot.blockProjectTargets()...)
	data = append(data, []string{"", "", "", ""})
	return data
}

func (ot *OrderTable) blockProjectTargets() [][]string {
	return append([][]string{}, []string{"#", "FIELD", "VALUE", "ACTION"})
}

// func (ot *OrderTable) blockProjectTargets() [][]string {
// 	data := [][]string{}
// 	data = append(data, []string{Block_Project_Product_Requests, "", "", Action_Add_TargetRequest})
// 	switch len(ot.Source.TargetProducts) {
// 	case 0:
// 	default:
// 		for i, tgt := range ot.Source.TargetProducts {
// 			data = append(data, []string{fmt.Sprintf("t%v", i+1), Block_Key_RequestType, tgt.Type, ""})
// 			switch len(tgt.SourceFiles) {
// 			case 0:
// 				data = append(data, []string{"", "нет задач", "", Action_Set_Sources})
// 			default:
// 				//data = append(data, blockRequestSources(tgt)...)
// 				data = append(data, []string{"", "", "", ""})
// 			}

// 		}
// 	}

// switch len(ot.Source.TargetProducts) {
// case 0:
// 	data = append(data, []string{"", "", "", Action_Add_TargetRequest})
// }

// 	return data
// }

// func blockRequestSources(tgt *product.ProductRequest) [][]string {
// 	data := [][]string{}
// 	data = append(data, []string{"", Block_Key_RequestSources, "", Action_Set_Sources})
// 	for i, src := range tgt.SourceFiles {
// 		met := 0
// 		for _, srcInfcollection := range tgt.TargetFileTypeToSources {
// 			for _, srcInfo := range srcInfcollection {
// 				if src == srcInfo.FileName {
// 					met++
// 				}
// 			}
// 		}
// 		data = append(data, []string{fmt.Sprintf("  s%v", i+1), inUseString(met), src, ""})
// 	}
// 	data = append(data, blockRequestSchemma(tgt)...)
// 	return data
// }

// func blockRequestSchemma(tgt *product.ProductRequest) [][]string {
// 	data := [][]string{}
// 	action := ""
// 	switch tgt.Schema.String() {
// 	case "":
// 		action = "Выбрать схему"
// 	default:
// 		action = "Изменить схему"
// 	}
// 	data = append(data, []string{"", Block_Key_RequestSchemma, "", ""})
// 	data = append(data, []string{"", tgt.Schema.String(), "", action})

// 	return data
// }

func (ot *OrderTable) setCursor() {
	ot.Table.SetCursor(len(ot.Table.Rows()) - 1)
	for i, row := range ot.Table.Rows() {
		switch row[1] {
		case Field_Edit_Prefix:
			if row[3] == Action_Add_Key {
				ot.Table.SetCursor(i)
			}
		}
	}
}

func keyAction(key string) string {
	switch key {
	case "", "[???]":
		return Action_Add_Key
	default:
		return Action_Edit_Key
	}
}

func (ot OrderTable) Init() tea.Cmd {
	return nil
}

func (ot OrderTable) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	var cmd tea.Cmd
	switch msg := msg.(type) {
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "esc", "left":
			//cmds = append(cmds, updateNavigation(VS_ProjectTable))
			cmds = append(cmds, teacmd.ChangeView(currentView, clientcontext.ViewMain()))
		case "enter", "right":
			row := ot.Table.SelectedRow()
			// switch row[1] {
			// case Field_Edit_Prefix:
			// 	cmds = append(cmds, teacmd.ChangeView(currentView, clientcontext. VS_Project_SetProjectKey))
			// }
			if len(row) < 4 {
				fmt.Println(row)
				panic(9)
			}
			switch row[3] {
			case Action_Add_Key, Action_Edit_Key:
				cmds = append(cmds, teacmd.ChangeView(currentView, clientcontext.ViewQuerryProjectKey()))
			case Action_Add_TargetRequest:
				cmds = append(cmds, teacmd.ChangeView(currentView, clientcontext.ViewQuerrySelectTarget()))
			case Action_Set_Sources:
				ot.SetSourceContext()
				cmds = append(cmds, teacmd.ChangeView(currentView, clientcontext.ViewQuerrySelectSources()))

			}
		case "p":
			row := ot.Table.SelectedRow()
			if len(row) < 4 {
				fmt.Println(row)
				panic("selected row is short")
			}
			switch row[3] {
			case Action_Set_Path:
				projectPath := clientcontext.Get(clientcontext.CTX_Projects) + ot.Source.FileKey + ".json"
				cmds = append(cmds, teacmd.RequestPathToTable(projectPath))
			}

		default:
			ot.Table, cmd = ot.Table.Update(msg)
			cmds = append(cmds, cmd)
		}

	}
	return ot, tea.Batch(cmds...)
}

func (ot OrderTable) View() string {
	return ot.Table.View()
}

func (ot OrderTable) SetSourceContext() {
	curs := ot.Table.Cursor()
	rows := ot.Table.Rows()
	for i := curs; i >= 0; i-- {
		if len(rows)-1 < curs {
			continue
		}
		row := rows[i]
		n, err := strconv.Atoi(strings.TrimPrefix(row[0], "t"))
		if err != nil {
			continue
		}
		clientcontext.Set(clientcontext.CTX_SelectedRequest, fmt.Sprintf("%v", n-1))
		return
	}

}

func inUseString(useTimes int) string {
	switch useTimes {
	case 0:
		return "  не используется"
	case 1, 5, 6:
		return fmt.Sprintf("  используется %v раз", useTimes)
	case 2, 3, 4:
		return fmt.Sprintf("  используется %v раза", useTimes)
	default:
		return fmt.Sprintf("  слишком много: %v", useTimes)

	}
}
