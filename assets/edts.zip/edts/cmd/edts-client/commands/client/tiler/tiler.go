package tiler

import (
	"log"
	"os"

	"github.com/charmbracelet/x/term"
)

type layout struct {
	Width            int
	Height           int
	blocksVertical   [3]int
	blocksHorisontal [3]int
}

var tiler = layout{}

func Size() (int, int) {
	maxWidth, maxHeight, err := term.GetSize(uintptr(os.Stdout.Fd()))
	if err != nil {
		log.Fatalf("failed to define screen size")
	}

	return maxWidth, maxHeight
}

func Percent(total, part, minimum int) int {
	get := int(float64(total) * (float64(part) / 100.0))
	if minimum > get {
		get = minimum
	}
	return get
}

func UpdateTiler() {
	tiler.Width, tiler.Height = Size()
	tiler.blocksVertical = [3]int{Percent(tiler.Height, 2, 2), 20, Percent(tiler.Height, 3, 5)}
	tiler.blocksVertical[1] = tiler.Height - tiler.blocksVertical[0] - tiler.blocksVertical[2]

	tiler.blocksHorisontal = [3]int{Percent(tiler.Width, 5, 16), 20, Percent(tiler.Width, 27, 30)}
	tiler.blocksHorisontal[1] = tiler.Width - tiler.blocksHorisontal[0] - tiler.blocksHorisontal[2]
}

func Width() int {
	return tiler.Width
}

func Height() int {
	return tiler.Height
}

func BlocksVertical(i int) int {
	return tiler.blocksVertical[i]
}

func BlocksHorisontal(i int) int {
	return tiler.blocksHorisontal[i]
}
