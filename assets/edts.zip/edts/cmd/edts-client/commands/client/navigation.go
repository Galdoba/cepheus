package client

import (
	"fmt"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/helpers"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/ordermanger"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/sourcemanager"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teamsg"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
	tea "github.com/charmbracelet/bubbletea"
)

// func (cl *client) updateNavigation() tea.Msg {
// 	switch cl.screen.ViewScreen {
// 	case VS_ProjectTable:
// 		return teamsg.NavigationMsg(VS_ProjectTable)
// 	}

// 	return nil
// }

type Navigation struct {
	Text string
}

func NewNavigation() *Navigation {
	n := Navigation{}
	text := []string{}
	text = append(text, "╭──────────────")
	text = append(text, "│ MAIN         ")
	text = append(text, "╰───┬──────────")
	text = append(text, "    │  PROJECT ")
	text = append(text, "    ├──────────")
	text = append(text, "    │    FIELD ")
	text = append(text, "    ├──────────")
	text = append(text, "    │   SOURCE ")
	text = append(text, "    ╰──────────")
	n.Text = strings.Join(text, "\n")
	return &n
}

func (n *Navigation) Init() tea.Cmd {
	return teacmd.ChangeView(0, clientcontext.ViewMain())
}

func (n *Navigation) Update(msg tea.Msg) (tea.Model, tea.Cmd) {

	switch msg := msg.(type) {
	case teamsg.NavigationMsg:
		switch msg.TargetView {
		case VS_ProjectTable:
			n.Text = Tab_MAIN
		case VS_ProjectActionSelection:
			n.Text = Tab_PROJECT
		case VS_Project_SetProjectKey:
			n.Text = Tab_FIELD
		case 6:
			n.Text = Tab_SOURCE
		default:

			n.Text = fmt.Sprintf("unk: %v", msg)
		}
		n.Text += fmt.Sprintf("\nmsg: %v", msg)

		return n, nil
	}
	return n, nil
}

func (n *Navigation) View() string {

	return n.Text
}

var Tab_MAIN = strings.Join([]string{
	"╭──────────────",
	"│ MAIN         ",
	"╰───┬──────────",
	"    │  PROJECT ",
	"    ├──────────",
	"    │    FIELD ",
	"    ├──────────",
	"    │   SOURCE ",
	"    ╰──────────",
}, "\n")

var Tab_PROJECT = strings.Join([]string{
	"    ╭──────────",
	"    │     MAIN ",
	"╭───┴──────────",
	"│ PROJECT      ",
	"╰───┬──────────",
	"    │    FIELD ",
	"    ├──────────",
	"    │   SOURCE ",
	"    ╰──────────",
}, "\n")

var Tab_FIELD = strings.Join([]string{
	"    ╭──────────",
	"    │     MAIN ",
	"    ├──────────",
	"    │  PROJECT ",
	"╭───┴──────────",
	"│ FIELD        ",
	"╰───┬──────────",
	"    │   SOURCE ",
	"    ╰──────────",
}, "\n")

var Tab_SOURCE = strings.Join([]string{
	"    ╭──────────",
	"    │     MAIN ",
	"    ├──────────",
	"    │  PROJECT ",
	"    ├──────────",
	"    │ FIELD    ",
	"╭───┴──────────",
	"│ SOURCE       ",
	"╰──────────────",
}, "\n")

/*
Top:          "─",
		Bottom:       "─",
		Left:         "│",
		Right:        "│",
		TopLeft:      "╭",
		TopRight:     "╮",
		BottomLeft:   "╰",
		BottomRight:  "╯",
		MiddleLeft:   "├"Cmd
		MiddleRight:  "┤",
		Middle:       "┼",
		MiddleTop:    "┬",
		MiddleBottom: "┴",


*/

// func nilErr() error {
// 	return nil
// }

func (cl *clientModel) onViewSwitchChanges(nav teamsg.NavigationMsg) error {
	if cl.data.SelectedProject != nil {
		clientcontext.Set(clientcontext.CTX_SelectedProject, cl.data.SelectedProject.FileKey)
	}
	switch nav {
	default:
		return fmt.Errorf("nav event %v %v is not implemented", nav.InitialView, nav.TargetView)
	case teamsg.NavigationMsg{VS_NO_VIEW, VS_ProjectActionSelection},
		teamsg.NavigationMsg{VS_ProjectTable, VS_ProjectActionSelection}:
		if err := cl.generateOrderTable(); err != nil {
			return fmt.Errorf("cl.generateOrderTable() returned: %v", err)
		}
	case teamsg.NavigationMsg{VS_ProjectActionSelection, VS_Project_SetProjectKey}:
		if err := cl.generateQuerry_ProjectKey(); err != nil {
			return fmt.Errorf("cl.generateQuerry_ProjectKey() returned: %v", err)
		}
	case teamsg.NavigationMsg{VS_ProjectActionSelection, VS_ProjectTable}:
		if err := cl.modifyProjectTable(); err != nil {
			return fmt.Errorf("cl.modifyProjectTable() returned: %v", err)
		}
	case teamsg.NavigationMsg{VS_Project_SetProjectKey, VS_ProjectActionSelection}:
		if err := cl.changeConfirmedbase(); err != nil {
			return fmt.Errorf("cl.changeConfirmedbase() returned: %v", err)
		}
	// case teamsg.NavigationMsg{VS_ProjectActionSelection, VS_Project_NewTarget}:
	// 	if err := cl.generateQuerry_NewRequest(); err != nil {
	// 		return fmt.Errorf("cl.generateQuerry_NewRequest() returned: %v", err)
	// 	}
	// case teamsg.NavigationMsg{VS_Project_NewTarget, VS_ProjectActionSelection}:
	// 	if err := cl.changeAddNewTarget(); err != nil {
	// 		return fmt.Errorf("cl.changeAddNewTarget() returned: %v", err)
	// 	}
	case teamsg.NavigationMsg{2, 5}:
		if err := cl.generateQuerry_NewSources(); err != nil {
			return fmt.Errorf("cl.changeAddNewTarget() returned: %v", err)
		}
	// case teamsg.NavigationMsg{5, 2}:
	// 	if err := cl.changeSetSources(); err != nil {
	// 		return fmt.Errorf("cl.changeAddNewTarget() returned: %v", err)
	// 	}
	case teamsg.NavigationMsg{VS_ProjectTable, clientcontext.ViewSources()}:
		if err := cl.changeSourceView(); err != nil {
			return fmt.Errorf("cl.changeAddNewTarget() returned: %v", err)
		}
	case teamsg.NavigationMsg{clientcontext.ViewSources(), clientcontext.ViewMain()}:
		if err := cl.returnToMain(); err != nil {
			return fmt.Errorf("cl.changeAddNewTarget() returned: %v", err)
		}

	}
	return nil
}

func (cl *clientModel) changeConfirmedbase() error {
	cl.data.SelectedProject.ConfirmedBase = cl.screen.Query.Single.Key
	editPath, archivePath := helpers.OutPaths(cl.data.SelectedProject)
	cl.data.SelectedProject.EditPath = editPath
	cl.data.SelectedProject.ArchivePath = archivePath
	events.PublishNewEvent(events.PROJECT_MODIFIED,
		payload.String("project", cl.data.SelectedProject.FileKey),
		payload.String("confirmed_base", cl.data.SelectedProject.ConfirmedBase),
		payload.String("edit_path", cl.data.SelectedProject.EditPath),
		payload.String("archive_path", cl.data.SelectedProject.ArchivePath),
	)
	if err := cl.SaveProject(cl.data.SelectedProject); err != nil {
		return err
	}
	return cl.generateOrderTable()
}

// func (cl *clientModel) changeAddNewTarget() error {
// 	tgt := cl.screen.Query.Single.Key
// 	cl.data.SelectedProject.AddRequest(tgt)
// 	//cl.data.SelectedProject.TargetProducts = append(cl.data.SelectedProject.TargetProducts, pr)
// 	if err := cl.SaveProject(cl.data.SelectedProject); err != nil {
// 		return err
// 	}

// 	return cl.generateOrderTable()
// }

// func (cl *clientModel) changeSetSources() error {
// 	//определяем заказ
// 	n, err := strconv.Atoi(clientcontext.Get(clientcontext.CTX_SelectedRequest))
// 	if err != nil {
// 		fmt.Println(err)
// 		panic(n)
// 	}
// 	// //создаем запрос
// 	// fmt.Println(cl.data.SelectedProject.TargetProducts)
// 	// fmt.Println(cl.data.SelectedProject.TargetProducts[n].SourceFiles)
// 	// fmt.Println(cl.screen.Query.Multiple.Keys)

// 	cl.data.SelectedProject.TargetProducts[n].SetProdictSources(cl.data.Config.SourceDir, cl.screen.Query.Multiple.Keys...)

// 	// target := cl.data.SelectedProject.TargetProducts[n]
// 	// if target.Schema.String() == "" {
// 	// 	target.PredictSourceCombination()
// 	// }

// 	//panic("пытаемся предсказать связь выходных файлов с выбранными источниками")
// 	if err := cl.SaveProject(cl.data.SelectedProject); err != nil {
// 		return err
// 	}
// 	//меняем окно
// 	return cl.generateOrderTable()
// }

func (cl *clientModel) modifyProjectTable() error {
	selectedRow[4] = cl.data.SelectedProject.ConfirmedBase
	cl.screen.Projects.updateRow(selectedRow)
	cl.screen.Projects.fill(cl.data.ProjectData)

	cl.screen.Projects.restoreCursor(selectedRow)
	if err := cl.screen.Layout.Swap(cl.screen.Projects, mainBlock); err != nil {
		return err
	}
	cl.screen.HelpText.text = projectTableHelp()
	return nil
}

func (cl *clientModel) returnToMain() error {
	cl.screen.Projects.updateRow(selectedRow)
	cl.screen.Projects.fill(cl.data.ProjectData)
	cl.screen.Projects.restoreCursor(selectedRow)
	if err := cl.screen.Layout.Swap(cl.screen.Projects, mainBlock); err != nil {
		return err
	}
	cl.screen.HelpText.text = projectTableHelp()
	return nil
}

func (cl *clientModel) generateOrderTable() error {
	cl.selectProject(selectedRow)
	if err := cl.screen.Layout.Swap(ordermanger.NewOrderTable(cl.data.SelectedProject), mainBlock); err != nil {
		return err
	}
	cl.screen.HelpText.text = orderTableHelp()
	return nil
}

func (cl *clientModel) generateQuerry_ProjectKey() error {
	cq := ClientQuerry{simple: true, Single: NewProjectKeySelection(cl.data.SelectedProject)}
	cl.screen.Query = &cq
	if err := cl.screen.Layout.Swap(cl.screen.Query, mainBlock); err != nil {
		return err
	}
	return nil
}

// func (cl *clientModel) generateQuerry_NewRequest() error {
// 	cq := ClientQuerry{simple: true, Single: NewProject_AddTarget(cl.data.SelectedProject)}
// 	cl.screen.Query = &cq
// 	if err := cl.screen.Layout.Swap(cl.screen.Query, mainBlock); err != nil {
// 		return err
// 	}
// 	return nil
// }

func (cl *clientModel) generateQuerry_NewSources() error {
	cq := ClientQuerry{simple: false, Multiple: NewProject_SetSources(cl)}
	cl.screen.Query = &cq
	if err := cl.screen.Layout.Swap(cl.screen.Query, mainBlock); err != nil {
		return err
	}
	return nil
}

func (cl *clientModel) changeSourceView() error {
	cl.screen.Sources = sourcemanager.NewSourceManager(cl.data.FileAssoc)
	if err := cl.screen.Layout.Swap(cl.screen.Sources, mainBlock); err != nil {
		return err
	}
	return nil
}
