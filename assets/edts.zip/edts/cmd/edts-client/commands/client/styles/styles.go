package styles

import (
	"github.com/charmbracelet/bubbles/table"
	"github.com/charmbracelet/lipgloss"
)

// PROJECTS TABLE
var projectHeaderStyle = lipgloss.NewStyle().
	BorderStyle(lipgloss.NormalBorder()).
	BorderForeground(lipgloss.Color("136")).
	Bold(false)

var projectCellStyle = lipgloss.NewStyle().
	BorderLeft(true).
	BorderRight(true).
	Padding(0, 1)

var projectSelectedStyle = lipgloss.NewStyle().
	Foreground(lipgloss.Color("136")).
	Bold(true). //Padding(0, 1).
	Background(lipgloss.Color("235"))

func ProjectTableStyle() table.Styles {
	styles := table.DefaultStyles()
	styles.Header = projectHeaderStyle
	styles.Cell = projectCellStyle
	styles.Selected = projectSelectedStyle
	return styles
}

// ORDER TABLE

var orderHeaderStyle = lipgloss.NewStyle().
	BorderStyle(lipgloss.NormalBorder()).
	BorderForeground(lipgloss.Color("25")).
	Bold(false)

var orderCellStyle = lipgloss.NewStyle().
	BorderLeft(true).
	BorderRight(true).
	Padding(0, 1)

var orderSelectedStyle = lipgloss.NewStyle().
	Foreground(lipgloss.Color("25")).
	Bold(true). //Padding(0, 1).
	Background(lipgloss.Color("235"))

func OrderTableStyle() table.Styles {
	styles := table.DefaultStyles()
	styles.Header = orderHeaderStyle
	styles.Cell = orderCellStyle
	styles.Selected = orderSelectedStyle

	return styles
}

//SOURCE Table

var sourceHeaderStyle = lipgloss.NewStyle().
	BorderStyle(lipgloss.NormalBorder()).
	BorderForeground(lipgloss.Color("86")).
	Bold(false)

var sourceCellStyle = lipgloss.NewStyle().
	BorderLeft(true).
	BorderRight(true).
	Padding(0, 1)

var sourceSelectedStyle = lipgloss.NewStyle().
	Foreground(lipgloss.Color("86")).
	Bold(true). //Padding(0, 1).
	Background(lipgloss.Color("235"))

func SourceTableStyle() table.Styles {
	styles := table.DefaultStyles()
	styles.Header = sourceHeaderStyle
	styles.Cell = sourceCellStyle
	styles.Selected = sourceSelectedStyle

	return styles
}
