package columns

import (
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/tiler"
	"github.com/charmbracelet/bubbles/table"
)

func ProjectsTableColumns() []table.Column {
	max := tiler.BlocksHorisontal(1)
	width := splitForProjects(max)
	cols := []table.Column{
		{Title: "Название", Width: width[0]},
		{Title: "Агент", Width: width[1]},
		{Title: "Дата Публикации", Width: width[2]},
		{Title: "Статус", Width: width[3]},
		{Title: "Комментарий", Width: width[4]},
	}
	return cols
}

func splitForProjects(max int) [5]int {
	max = max - 10
	c1 := (max * 45) / 100
	c2 := min((max*25)/100, 16)
	c3 := min((max*25)/100, 15)
	c4 := (max * 15) / 100
	c5 := min((max*20)/100, 20)
	for c1+c2+c3+c4+c5 < max {
		c5++
	}
	for c1+c2+c3+c4+c5 > max {
		c5--
	}
	return [5]int{c1, c2, c3, c4, c5}
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func OrderTableColumns(maxWidth int) []table.Column {
	width := splitForOrder(maxWidth)
	cols := []table.Column{
		{Title: "Блок", Width: width[0]},
		{Title: "Поле", Width: width[1]},
		{Title: "Значение", Width: width[2]},
		{Title: "Действие", Width: width[3]},
	}
	return cols
}

func splitForOrder(max int) [4]int {
	max = max - 8
	c1 := min((max*10)/100, 12)
	c2 := min((max*30)/100, 26)
	c3 := min((max*40)/100, 20)
	c4 := min((max*20)/100, 30)
	for c1+c2+c3+c4 < max {
		c3++
	}
	for c1+c2+c3+c4 > max {
		c3--
	}
	return [4]int{c1, c2, c3, c4}
}

func SourcesTableColumns(maxWidth int) []table.Column {
	width := splitForSources(maxWidth)
	cols := []table.Column{
		{Title: "Файл", Width: width[0]},
		{Title: "Стримы", Width: width[1]},
		{Title: "Открыть", Width: width[2]},
	}
	return cols
}

func splitForSources(max int) [3]int {
	max = max - 6
	c1 := min((max*40)/100, 30)
	c2 := min((max*10)/100, 10)
	c3 := min((max*30)/100, 40)
	for c1+c2+c3 < max {
		c1++
	}
	for c1+c2+c3 > max {
		c1--
	}
	return [3]int{c1, c2, c3}
}
