package client

import (
	"fmt"
	"os"
	"time"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/ordermanger"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/sourcemanager"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/tiler"
	"github.com/Galdoba/edts/cmd/edts-client/config"
	"github.com/Galdoba/edts/internal/btblocks/teablock"
	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/charmbracelet/bubbles/textinput"
	"github.com/charmbracelet/bubbles/timer"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type clientModel struct {
	data   data
	screen screen
}

func NewClient(cfg *config.ClientConfiguration) *clientModel {

	tiler.UpdateTiler()
	clientcontext.InitContext()
	clientcontext.Set("inbox", cfg.Inbox)
	clientcontext.Set(clientcontext.CTX_SourceDir, cfg.SourceDir)
	clientcontext.Set(clientcontext.CTX_EditPath, cfg.EditPath)
	clientcontext.Set(clientcontext.CTX_Archive, cfg.ArchivePath)
	clientcontext.Set(clientcontext.CTX_Projects, cfg.ProjectStorageDir)
	// ctx.Data = make(map[string]string)
	// ctx.Data["inbox"] = cfg.Inbox
	// ctx.Data[CTX_Edit_Path] = cfg.EditPath
	// ctx.Data[CTX_Archive] = cfg.ArchivePath
	// ctx.Data[CTX_Projects] = cfg.ProjectStorageDir
	cl := clientModel{}
	cl.data = data{
		StartTime:   time.Now(),
		ProjectData: make(map[string]*transcode.Project),
		Config:      cfg,
		FilesDB:     db.Create(cfg.FilesDBFile, db.TYPE_FILEDATA),
		TableDB:     db.Create(cfg.TableDBFile, db.TYPE_SPREADSHEET),
		FileAssoc:   cfg.FileAssoc,
	}
	if err := cl.UpdateProjectFiles(); err != nil {
		fmt.Printf("%v", err)
		os.Exit(1)
	}
	if err := cl.UpdateProjectCollection(); err != nil {
		fmt.Printf("%v", err)
		os.Exit(1)
	}

	cl.screen = screen{
		HeaderText: defaultTextInput(),
		Header:     &Header{startTime: time.Now()},
		Navigation: NewNavigation(),
		HelpText:   &HelpWidget{text: projectTableHelp()},
		Projects:   NewProjectsTable(cl.data.ProjectData),
		Order:      &ordermanger.OrderTable{},
		EventLog:   NewEventWidget(cl.data.Config.BrokerEventStorage, cl.data.Config.Inbox),
		MainBox:    defaultTextInput(),
	}

	cl.composeLayout()

	return &cl
}

func (cl *clientModel) composeLayout() error {
	cl.screen.Layout = teablock.NewLayout()
	cl.screen.Layout.AddHorisontal(teablock.Confine(cl.screen.Header,
		tiler.Width(), tiler.BlocksVertical(0),
		teablock.WithStyle(teablock.DefaultStyle.Border(lipgloss.NormalBorder(), false, false, true, false))))

	cl.screen.Layout.AddVertical(teablock.Confine(cl.screen.Navigation,
		tiler.BlocksHorisontal(0), tiler.BlocksVertical(1),
		teablock.WithStyle(teablock.DefaultStyle.Border(lipgloss.NormalBorder(), false, true, false, false))))

	cl.screen.Layout.AddHorisontal(teablock.Confine(cl.screen.Projects,
		tiler.BlocksHorisontal(1), tiler.BlocksVertical(1),
		teablock.WithTrimmers(teablock.NoTrimmer, teablock.DefaultVerticalTrimmer),
		teablock.WithStyle(teablock.DefaultStyle.Border(lipgloss.NormalBorder(), false))))

	cl.screen.Layout.AddHorisontal(teablock.Confine(cl.screen.EventLog,
		tiler.BlocksHorisontal(2), tiler.BlocksVertical(1),
		teablock.WithStyle(teablock.DefaultStyle.Border(lipgloss.NormalBorder(), false, false, false, true))))

	cl.screen.Layout.AddVertical(teablock.Confine(cl.screen.HelpText,
		tiler.Width(), tiler.BlocksVertical(2),
		teablock.WithStyle(teablock.DefaultStyle.Border(lipgloss.NormalBorder(), true, false, false, false))))

	return nil
}

type screen struct {
	ViewScreen int
	Layout     *teablock.Layout
	Header     *Header
	Navigation *Navigation
	Projects   *ProjectsTable
	Order      *ordermanger.OrderTable      //5
	EventLog   *EventWidget                 //3
	HeaderText textinput.Model              //1
	HelpText   *HelpWidget                  //2
	Query      *ClientQuerry                //5
	Sources    *sourcemanager.SourceManager //6
	//Nav        *NavWidget          //4

	MainBox textinput.Model //6
}

type data struct {
	StartTime       time.Time
	FilesDB         *db.Database
	TableDB         *db.Database
	SpreadsheetRows []transcode.SheetRow
	ProjectData     map[string]*transcode.Project
	SelectedProject *transcode.Project
	Config          *config.ClientConfiguration
	Timer           timer.Model
	FileAssoc       map[string]string
}

func (cl clientModel) Init() tea.Cmd {
	return tea.Batch(cl.data.Timer.Init(), tea.ClearScreen, teacmd.TickEvery()) //, teacmd.RequestSpreadsheetUpdate())
}

func mapToList(data map[string]*transcode.Project) []*transcode.Project {
	projectList := []*transcode.Project{}
	for _, v := range data {
		projectList = append(projectList, v)
	}
	return projectList
}

func defaultTextInput() textinput.Model {
	ti := textinput.New()
	ti.Prompt = ""
	return ti
}
