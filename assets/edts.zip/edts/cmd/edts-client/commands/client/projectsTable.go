package client

import (
	"strconv"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/columns"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/styles"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/tiler"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/charmbracelet/bubbles/table"
	tea "github.com/charmbracelet/bubbletea"
)

type ProjectsTable struct {
	Table        table.Model
	SortedBy     int
	SelectionMem table.Row
	//Help         string
}

func (pt *ProjectsTable) Init() tea.Cmd {
	return nil
}

type selectionMsg table.Row

func selected(row table.Row) tea.Cmd {
	return func() tea.Msg {
		return selectionMsg(row)
	}
}

func (pt *ProjectsTable) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	var cmd tea.Cmd
	switch msg := msg.(type) {
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "1", "2", "3", "4", "5":
			i, _ := strconv.Atoi(keypress)
			selectedRow = pt.Table.SelectedRow()
			sorted := sortByColumn(pt.Table.Rows(), i-1)
			pt.Table.SetRows(sorted)
			pt.restoreCursor(selectedRow)
			pt.SortedBy = i - 1

		case "enter", "right":
			pt.Table, cmd = pt.Table.Update(msg)
			cmds = append(cmds, cmd)
			selectedRow = pt.Table.SelectedRow()
			cmds = append(cmds, selected(pt.SelectionMem))
			cmds = append(cmds, teacmd.ChangeView(clientcontext.ViewMain(), clientcontext.ViewProject()))
		case "u", "U", "г", "Г":
			cmds = append(cmds, teacmd.RequestSpreadsheetUpdate())
		case "S", "s", "Ы", "ы":
			selectedRow = pt.Table.SelectedRow()
			cmds = append(cmds, selected(pt.SelectionMem))
			cmds = append(cmds, teacmd.ChangeView(clientcontext.ViewMain(), clientcontext.ViewSources()))
		default:
			pt.Table, cmd = pt.Table.Update(msg)
			cmds = append(cmds, cmd)
		}

	}
	return pt, tea.Batch(cmds...)
}

func (pt *ProjectsTable) View() string {

	s := pt.Table.View()
	return s
}

func NewProjectsTable(data map[string]*transcode.Project) *ProjectsTable {
	pt := ProjectsTable{}
	pt.Table = table.New(
		table.WithColumns(
			columns.ProjectsTableColumns(),
		),

		table.WithHeight(tiler.BlocksVertical(1)-3),
		table.WithStyles(styles.ProjectTableStyle()),
		table.WithFocused(true),
	)
	pt.SortedBy = 2
	pt.fill(data)
	return &pt
}

func (pt *ProjectsTable) fill(data map[string]*transcode.Project) {
	//panic(len(data))
	projectList := mapToList(data)
	rows := rowsFromProjects(projectList)
	selectedRow = pt.Table.SelectedRow()
	rows = sortByColumn(rows, pt.SortedBy)
	pt.Table.SetRows(rows)
	pt.selectFromMemory()

}

var selectedRow table.Row

func (pt *ProjectsTable) restoreCursor(row table.Row) {
	for i, inRow := range pt.Table.Rows() {
		if row[0]+row[2] == inRow[0]+inRow[2] {
			pt.Table.SetCursor(i)
			return
		}
	}

}

func (pt *ProjectsTable) updateRow(newRow table.Row) {
	if len(newRow) != 5 {
		return
	}
	updatedRows := []table.Row{}
	for _, oldRow := range pt.Table.Rows() {
		switch oldRow[0]+oldRow[2] == newRow[0]+newRow[2] {
		case true:
			updatedRows = append(updatedRows, newRow)
		case false:
			updatedRows = append(updatedRows, oldRow)
		}
	}
	pt.Table.SetRows(updatedRows)
}
