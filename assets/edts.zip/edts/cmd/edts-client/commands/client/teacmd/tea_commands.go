package teacmd

import (
	"time"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teamsg"
	"github.com/Galdoba/edts/pkg/events"
	tea "github.com/charmbracelet/bubbletea"
)

func ChangeView(current, new int) tea.Cmd {
	return func() tea.Msg {
		return teamsg.NavigationMsg{InitialView: current, TargetView: new}
	}
}

// Send a message every second.
func TickEvery() tea.Cmd {
	return tea.Every(time.Second, func(t time.Time) tea.Msg {
		return teamsg.TickMsg(t)
	})
}

func UpdateRowsCmd() tea.Cmd {
	return func() tea.Msg {
		return teamsg.SpreadsheetUpdated(clientcontext.Get("inbox"))
	}
}

func RequestSpreadsheetUpdate() tea.Cmd {
	return func() tea.Msg {
		return teamsg.SpreadsheetUpdateRequestedMsg(events.WORKSHEET_FETCH_REQUSTED)
	}
}

func RequestPathToTable(prjPath string) tea.Cmd {
	return func() tea.Msg {
		return teamsg.PathToSpreadsheetRequestedMsg(prjPath)
	}
}

// func SpawnMessage(msgType string, payload map[string]string) tea.Cmd {
// 	return func() tea.Msg {
// 		return teamsg.SpawnEvent(msgType, payload)
// 	}
// }
