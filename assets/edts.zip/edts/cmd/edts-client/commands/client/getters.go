package client

import (
	"github.com/Galdoba/edts/internal/transcode"
)

func (cl *clientModel) projectFilePath(prj *transcode.Project) string {
	if cl.data.Config.ProjectStorageDir == "" {
		return ""
	}
	return cl.data.Config.ProjectStorageDir + prj.FileKey + ".json"
}
