package client

// func (cl client) View() string {
// 	header := headerStyle.Render(cl.screen.HeaderText.View())
// 	helpText := helpStyle.Render(cl.screen.HelpText.View())
// 	mainBodyHeight := tiler.blocksVertical[1]
// 	cl.screen.Nav.Table.SetWidth(tiler.blocksHorisontal[0])
// 	cl.screen.EventLog.Table.SetHeight(tiler.blocksVertical[1])
// 	cl.screen.EventLog.Table.SetWidth(tiler.blocksHorisontal[2])
// 	tabs := cl.screen.Nav.Table.View()
// 	eventLog := cl.screen.EventLog.Table.View()
// 	main := "Nothing here"
// 	switch cl.screen.ViewScreen {
// 	case VS_ProjectTable:
// 		cl.screen.Projects.Table.SetHeight(tiler.blocksVertical[1])
// 		cl.screen.Projects.Table.SetColumns(projectsTableColumns(tiler.blocksHorisontal[1]))
// 		main = cl.screen.Projects.Table.View()
// 	case VS_ProjectActionSelection:
// 		cl.screen.Order.Table.SetHeight(tiler.blocksVertical[1])
// 		cl.screen.Order.Table.SetColumns(orderTableColumns(tiler.blocksHorisontal[1]))
// 		main = cl.screen.Order.Table.View()
// 	case VS_ProjectFieldBase:
// 		main = cl.screen.Query.View()
// 		//main = helpStyle.Render(cl.screen.Query.singleSelect.View())
// 	}

// 	mainStyle = mainStyle.Height(mainBodyHeight)
// 	middle := mainStyle.Render(lipgloss.JoinHorizontal(lipgloss.Left, tabs, main, eventLog))
// 	top := header
// 	bottom := helpText
// 	out := lipgloss.JoinVertical(lipgloss.Bottom, top, middle, bottom)
// 	return out
// }

func (cl clientModel) View() string {
	if cl.screen.Layout == nil {
		return "No LAyouT"
	}
	return cl.screen.Layout.View()
}

// func (cl *client) updateSizes() {
// 	// tiler.Width, tiler.Height = size()
// 	// tiler.blocksHorisontal[2] = (tiler.Width * 37) / 100
// 	// tiler.blocksHorisontal[1] = tiler.Width - tiler.blocksHorisontal[2] - tiler.blocksHorisontal[0] - 2
// 	updateTiler()
// 	topOffset := len(strings.Split(cl.screen.HeaderText.Prompt, "\n")) + 2
// 	bottomOffset := len(strings.Split(cl.screen.HelpText.Prompt, "\n")) + 1
// 	mid := tiler.Height - topOffset - bottomOffset
// 	tiler.blocksVertical = [3]int{topOffset, mid, bottomOffset}

// }
