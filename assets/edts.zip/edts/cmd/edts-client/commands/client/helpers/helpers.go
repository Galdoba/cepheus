package helpers

import (
	"fmt"
	"regexp"
	"slices"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/Galdoba/edts/pkg/translit"
)

func SortedKeys(m map[string]string) []string {
	keys := []string{}
	if m == nil {
		return keys
	}
	for k := range m {
		keys = append(keys, k)
	}
	slices.Sort(keys)
	return keys
}

func OutPaths(prj *transcode.Project) (string, string) {
	editSuffix := ""
	archiveSuffix := ""
	if prj.ConfirmedBase == "" {
		return "", ""
	}
	base, season, _ := disassemble(prj.ConfirmedBase)
	if season != "" {
		editSuffix += base + season + "/"

	}
	archiveSuffix += base + season + "/"

	edit := fmt.Sprintf("%v%v/%v", clientcontext.Get(clientcontext.CTX_EditPath), prj.EditingTargetDirectory, editSuffix)
	archive := fmt.Sprintf("%v_%v/_DONE/%v", clientcontext.Get(clientcontext.CTX_Archive), translit.String(prj.Agent, translit.RegisterHigh()), archiveSuffix)
	return edit, archive
}

// func editPathSuffix(prj *transcode.Project) string {
// 	suffix := ""
// 	if prj.ConfirmedBase == "" {
// 		return "[НЕТ ПРЕФИКСА]"
// 	}
// 	base, season, _ := disassemble(prj.ConfirmedBase)
// 	if season != "" {
// 		suffix += base + season + "/"
// 	}
// 	return suffix
// }

func disassemble(base string) (string, string, string) {
	eps := regexp.MustCompile(`(e[0-9]+)$`)
	episode := eps.FindString(base)
	ssn := regexp.MustCompile(`(_s[0-9]+)`)
	season := ssn.FindString(base)
	name := strings.TrimSuffix(base, episode)
	name = strings.TrimSuffix(name, season)
	return name, season, episode
}
