package journal

import (
	"fmt"
	"os"
	"regexp"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/tiler"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type Journal struct {
	eventDirectoryBroker string
	inbox                string
	width                int
	height               int
	header               []string
	messages             []string
}

var eventHeaderStyle = lipgloss.NewStyle().Border(lipgloss.Border{}).Foreground(lipgloss.Color("37"))

func NewJournal(broker, internal string) *Journal {

	el := Journal{}
	el.eventDirectoryBroker = broker
	el.inbox = internal
	el.width = tiler.BlocksHorisontal(2)
	el.height = tiler.BlocksVertical(1)
	el.header = eventHeader()
	el.messages = eventList(el.eventDirectoryBroker, el.height)
	return &el
}

type updateBrokerEventMsg bool

func updateEventLog() tea.Cmd {
	return func() tea.Msg {
		return updateBrokerEventMsg(true)
	}
}

type triggerEvents []string

func checkTriggerEvents() tea.Cmd {
	return func() tea.Msg {
		return triggerEvents([]string{})
	}
}

func (el *Journal) Init() tea.Cmd {

	return nil
}

func (el *Journal) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	// var cmds []tea.Cmd
	//var cmd tea.Cmd
	switch msg := msg.(type) {
	case updateBrokerEventMsg:
		if msg {
			el.messages = eventList(el.eventDirectoryBroker, el.height)
		}
	case triggerEvents:
		// for _, event := range msg {
		// ev, err := events.Read(el.inbox + event)
		// if err != nil {
		// 	cmds = append(cmds, reportError)
		// }
		// switch ev.Name {
		// case events.WORKSHEET_UPDATED:
		// 	cmds = append(cmds, cl_command.UpdateTables())
		// }
		// }
	default:
	}
	return el, nil //tea.Batch(cmds...)
}

func (el *Journal) View() string {
	s := ""
	s += strings.Join(el.header, "\n") + "\n"
	s += strings.Join(el.messages, "\n") + "\n"
	return s
}

func eventHeader() []string {
	sl := []string{}
	headerWidth := tiler.BlocksHorisontal(2) - 2
	for i := 0; i <= 2; i++ {
		line := []string{}
		switch i {
		case 0:
			line = append(line, eventHeaderStyle.Render("┌"))
			for len(line) < headerWidth {
				line = append(line, eventHeaderStyle.Render("─"))
			}
			line = append(line, eventHeaderStyle.Render("┐"))
		case 1:
			line = append(line, eventHeaderStyle.Render("│"))
			line = append(line, strings.Split(" Журнал событий", "")...)
			for len(line) < headerWidth {
				line = append(line, " ")
			}
			line = append(line, eventHeaderStyle.Render("│"))
		case 2:
			line = append(line, eventHeaderStyle.Render("└"))
			for len(line) < headerWidth {
				line = append(line, eventHeaderStyle.Render("─"))
			}
			line = append(line, eventHeaderStyle.Render("┘"))

		}
		row := strings.Join(line, "")
		sl = append(sl, row)
	}
	return sl
}

func eventList(path string, height int) []string {
	sl := []string{}
	fi, err := os.ReadDir(path)
	if err != nil {
		sl = append(sl, " << ERROR >>")
		sl = append(sl, "  failed to collect events")
		sl = append(sl, err.Error())
		return sl
	}
	total := len(fi)
	start := total - height + 5
	if start < 0 {
		start = 0
	}
	fi = fi[start:]
	for _, f := range fi {
		sl = append(sl, spellEvent(f.Name()))
	}
	if len(sl) == 0 {
		sl = append(sl, " << NO EVENTS >>")
	}
	return sl
}

func spellEvent(filename string) string {
	s := " "
	re := regexp.MustCompile(`([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]{2})([0-9]*)_(.*).event`)
	sl := re.FindStringSubmatch(filename)

	switch len(sl) {
	case 9:
		s += fmt.Sprintf("%v/%v/%v %v:%v:%v  %v", sl[1], sl[2], sl[3], sl[4], sl[5], sl[6], sl[8])
	default:
		s += filename
	}
	return s
}
