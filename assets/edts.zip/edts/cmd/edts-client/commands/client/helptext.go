package client

import (
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type HelpWidget struct {
	text string
	// style lipgloss.Style
}

func (hw HelpWidget) Init() tea.Cmd {
	return nil
}

func (hw HelpWidget) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	return hw, nil
}

func (hw HelpWidget) View() string {
	return hw.text
}

func (hw *HelpWidget) SetText(s string) {
	hw.text = s
}

var noStyle = lipgloss.NewStyle()
var bright = lipgloss.NewStyle().Foreground(lipgloss.Color("255"))
var dim = lipgloss.NewStyle().Foreground(lipgloss.Color("247"))
var dark = lipgloss.NewStyle().Foreground(lipgloss.Color("241"))
var white = lipgloss.NewStyle().Foreground(lipgloss.Color("255"))

var separator = "  •  "

func projectTableHelp() string {
	s := ""
	s += "    " + bright.Render("↑") + dim.Render("/") + bright.Render("k") + " : " + dark.Render("вверх") + white.Render(separator) +
		bright.Render("↓") + dim.Render("/") + bright.Render("j") + " : " + dark.Render("вниз") + "\n    " +
		bright.Render("enter") + dim.Render("/") + bright.Render("→") + " : " + dark.Render("перейти к проекту") + white.Render(separator) +
		bright.Render("s") + " : " + dark.Render("перейти к источникам") +
		"\n"
	s += "    " + bright.Render("1") + dim.Render("/") + bright.Render("2") + dim.Render("/") + bright.Render("3") + dim.Render("/") + bright.Render("4") + dim.Render("/") + bright.Render("5") +
		" : " + dark.Render("сортировка таблицы по столбцу") +
		white.Render(separator) + bright.Render("u") + " : " + dark.Render("запросить обновление таблицы")

	return s
}

func orderTableHelp() string {
	s := ""
	s += "    " + bright.Render("↑") + dim.Render("/") + bright.Render("k") + " : " + dark.Render("вверх") + white.Render(separator) +
		bright.Render("↓") + dim.Render("/") + bright.Render("j") + " : " + dark.Render("вниз") + white.Render(separator) + "\n" +
		bright.Render("enter") + dim.Render("/") + bright.Render("→") + " : " + dark.Render("выполнить действие") + white.Render(separator) +
		bright.Render("esc") + dim.Render("/") + bright.Render("←") + " : " + dark.Render("вернуться в таблицу проектов") +
		"\n"

	return s
}

func sourceTableHelp() string {
	s := ""
	s += "    " + bright.Render("↑") + dim.Render("/") + bright.Render("k") + " : " + dark.Render("вверх") + white.Render(separator) +
		bright.Render("↓") + dim.Render("/") + bright.Render("j") + " : " + dark.Render("вниз") + white.Render(separator) +
		bright.Render("enter") + dim.Render("/") + bright.Render("→") + " : " + dark.Render("открыть файл") + white.Render(separator) +
		"\n"
	s += "    " + bright.Render("1") + dim.Render("/") + bright.Render("2") + dim.Render("/") + bright.Render("3") + dim.Render("/") + bright.Render("4") + dim.Render("/") + bright.Render("5") +
		" : " + dark.Render("сортировка таблицы по столбцу") +
		white.Render(separator) + bright.Render("u") + " : " + dark.Render("запросить обновление таблицы")

	return s
}

type textLayout struct {
	lines [5]textLine
}

type textLine struct {
	block []textBlock
}

type textBlock struct {
	keys      []string
	value     string
	separator bool
}

func block(keys []string, value string, sep bool) textBlock {
	return textBlock{keys: keys, value: value, separator: sep}
}

var rendSeparator = white.Render(separator)
var rendSlash = dim.Render("/")
var rendSmCol = " : "

// func line(blocks ...textBlock) textLine {
// 	maxWidth := 0
// 	for _, b := range blocks {
// 		text := strings.Join(renderEach(b.keys, bright), rendSlash) + rendSmCol + dark.Render(b.value)

// 	}

// }

func renderEach(sl []string, style lipgloss.Style) []string {
	rendered := []string{}
	for _, s := range sl {
		rendered = append(rendered, style.Render(s))
	}
	return rendered
}

/*
↑/k up • ↓/j down
*/
