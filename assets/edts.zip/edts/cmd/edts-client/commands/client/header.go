package client

import (
	"fmt"
	"strconv"
	"time"

	tea "github.com/charmbracelet/bubbletea"
)

//var headerStyle = lipgloss.NewStyle()

type Header struct {
	startTime time.Time
	Text      string
}

func (h *Header) Init() tea.Cmd {
	return nil
}

func (h *Header) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	h.Text = fmt.Sprintf("  EDTS Project manager v 0.0.x (started: %v; operating time: %v)", start(h.startTime), running(h.startTime)) + "last msg: " + fmt.Sprintf("%v", msg)
	return h, nil
}

func (h *Header) View() string {
	return h.Text
}

func start(tm time.Time) string {
	return tm.Format(time.DateTime)
}

func running(tm time.Time) string {
	run := time.Since(tm)
	return formatDuration(run)
}

func formatDuration(dur time.Duration) string {
	seconds := int(dur.Seconds()) % 60
	minutes := int(dur.Minutes()) % 60
	hours := int(dur.Hours()) % 24
	days := int(dur.Hours()) / 24
	return fmt.Sprintf("%v:%v:%v:%v", formatNum(days), formatNum(hours), formatNum(minutes), formatNum(seconds))
}

func formatNum(i int) string {
	s := strconv.Itoa(i)
	for len(s) < 2 {
		s = "0" + s
	}
	return s
}
