package client

import (
	"encoding/json"
	"fmt"
	"log"
	"os"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/ordermanger"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
)

/*
+ 1 обновляем спрежшит
+ 2 синхронизируем файлы с таблицей


*/

func (cl *clientModel) UpdateData() error {
	if err := cl.UpdateProjectFiles(); err != nil {
		log.Fatalf("UpdateProjectFiles: %v", err)
		return err
	}
	if err := cl.UpdateProjectCollection(); err != nil {
		log.Fatalf("UpdateProjectCollection: %v", err)
		return err
	}
	cl.screen.Projects.fill(cl.data.ProjectData)
	switch cl.screen.ViewScreen {
	case VS_ProjectTable:
		if err := cl.screen.Layout.Swap(cl.screen.Projects, mainBlock); err != nil {
			log.Fatalf("Swap: %v", err)
			return err
		}
	case VS_ProjectActionSelection:
		//changeView(VS_ProjectTable, VS_ProjectActionSelection)
		switch cl.data.SelectedProject {
		case nil:
			if err := cl.screen.Layout.Swap(cl.screen.Projects, mainBlock); err != nil {
				log.Fatalf("Swap: %v", err)
				return err
			}
		default:
			if err := cl.screen.Layout.Swap(ordermanger.NewOrderTable(cl.data.SelectedProject), mainBlock); err != nil {
				log.Fatalf("Swap: %v", err)
				return err
			}
		}

	}

	return nil
}

func (cl *clientModel) UpdateProjectFiles() error {
	if err := cl.updateSheetRows(); err != nil {
		return fmt.Errorf("failed to update spreadsheet data")
	}
	errors := []error{}
	for _, row := range cl.data.SpreadsheetRows {
		err := cl.syncProjectFileWithSpreadsheet(row)
		if err != nil {
			errors = append(errors, fmt.Errorf("row update failed:\n%v\n%v", row, err))
		}
	}
	err := combinedError(errors...)
	if err != nil {
		return fmt.Errorf("failed to sync project files: \n%v", err)
	}
	return nil
}

func combinedError(errors ...error) error {
	if len(errors) < 1 {
		return nil
	}
	text := "combined error:"
	for _, err := range errors {
		text += "  \n" + err.Error()
	}
	return fmt.Errorf("%v", text)
}

// 1
// updateSheetRows - создает локальную копию таблицы из базы edts-spreadsheet-tracker-service
func (cl *clientModel) updateSheetRows() error {
	sprshtRows, err := transcode.SheetRows(cl.data.TableDB)
	if err != nil {
		return err
	}
	cl.data.SpreadsheetRows = sprshtRows
	assertNoDuplicates(cl.data.SpreadsheetRows)
	return nil
}

func assertNoDuplicates(rows []transcode.SheetRow) {
	dups := make(map[string]int)
	for _, v := range rows {
		if v.IsProject() {
			dups[transcode.ProjectFileKey(v)]++
		}
	}
	pan := false
	msg := "\nВНИМАНИЕ!!\nВ таблице найдены дубликаты проектов:\n"
	for k, v := range dups {
		if v > 1 {
			msg += fmt.Sprintf("  %v : %v раза\n", k, v)
			pan = true
		}
	}
	if pan {
		msg += "\nДля продолжения работы устрани дубликаты и перезапусти edts-spreadsheet-tracker-service"
		fmt.Println(msg)
		os.Exit(1)
	}
}

// 2
// syncProjectFileWithSpreadsheet - синхронизируем файл проекта и данные из таблицы
func (cl *clientModel) syncProjectFileWithSpreadsheet(row transcode.SheetRow) error {
	loaded := false
	if !row.IsProject() {
		return nil
	}
	prj := &transcode.Project{}
	path := cl.data.Config.ProjectStorageDir + transcode.ProjectFileKey(row) + ".json"
	_, err := os.Stat(path)
	switch err {
	case nil:
		prj, err = loadProjectFile(path)
		if err != nil {
			return err
		}
		loaded = true
	default:
		prj = transcode.NewProject(row)
	}
	actualStatus := row.Status()
	switch loaded {
	case true:
		oldStatus := prj.Status
		saveNeeded := false
		if oldStatus != actualStatus {
			prj.Status = actualStatus
			prj.StatusStr = transcode.StatusString(prj.Status)
			events.PublishNewEvent("project_modified", payload.String("field", "status"),
				payload.String("old_value", transcode.StatusString(oldStatus)), payload.String("new_value", transcode.StatusString(prj.Status)),
			)
			saveNeeded = true
		}
		if row.Cells[0].Text != prj.Comment {
			oldComment := prj.Comment
			prj.Comment = row.Cells[0].Text
			events.PublishNewEvent("project_modified", payload.String("field", "comment"),
				payload.String("old_value", oldComment), payload.String("new_value", prj.Comment),
			)
			saveNeeded = true
		}
		if saveNeeded {
			cl.SaveProject(prj)
		}

		remove := false
		switch prj.Status {
		case transcode.Status_CLOSED, transcode.Status_REJECTED:
			remove = true
		default:
			if !matchWithTable(prj, cl.data.SpreadsheetRows) {
				remove = true
			}
		}
		if remove {
			f, _ := os.Open(path)
			f.Close()
			if err := os.Remove(path); err != nil {
				panic(path + "\n" + err.Error())

			}
			events.PublishNewEvent("project_closed", payload.String("key", prj.FileKey))
		}

	case false:
		switch prj.Status {
		case transcode.Status_UPLOADING, transcode.Status_EDIT_COMPLETE, transcode.Status_IN_EDIT, transcode.Status_READY_TO_EDIT, transcode.Status_WAIT_FOR_SCRIPT, transcode.Status_DOWNLOADING, transcode.Status_PENDING:
			cl.SaveProject(prj)
			events.PublishNewEvent("project_created", payload.String("key", prj.FileKey))
		}

	}

	return nil
}

func loadProjectFile(path string) (*transcode.Project, error) {
	bt, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read file: %v", err)
	}
	prj := transcode.Project{}
	err = json.Unmarshal(bt, &prj)
	if err != nil {
		return nil, fmt.Errorf("failed to unmarshal project: %v", err)
	}
	return &prj, nil
}
