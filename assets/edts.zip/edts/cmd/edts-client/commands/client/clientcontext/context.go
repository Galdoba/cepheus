package clientcontext

type Context struct {
	stringData  map[string]string
	viewScreens map[string]int
}

var ctx Context

const (
	CTX_SelectedProject       = "selected_project"
	CTX_SelectedRequest       = "selected_request"
	CTX_EditPath              = "edit_path"
	CTX_SourceDir             = "source_directory"
	CTX_Archive               = "archive_path"
	CTX_Projects              = "projects_path"
	CTX_Editor                = "editor"
	CTX_Player                = "player"
	VS_NO_VIEW                = "VS_NO_VIEW"
	VS_ProjectTable           = "VS_ProjectTable"
	VS_ProjectActionSelection = "VS_ProjectActionSelection"
	VS_ProjectSetProjectKey   = "VS_Project_SetProjectKey"
	VS_ProjectNewTarget       = "VS_Project_NewTarget"
	VS_ProjectNewSources      = "VS_Project_NewSources"
	VS_Sources                = "VS_NewSources"
)

func InitContext() {
	ctx = Context{}
	ctx.stringData = make(map[string]string)
	ctx.viewScreens = make(map[string]int)
	ctx.viewScreens[VS_NO_VIEW] = 0
	ctx.viewScreens[VS_ProjectTable] = 1
	ctx.viewScreens[VS_ProjectActionSelection] = 2
	ctx.viewScreens[VS_ProjectSetProjectKey] = 3
	ctx.viewScreens[VS_ProjectNewTarget] = 4
	ctx.viewScreens[VS_ProjectNewSources] = 5
	ctx.viewScreens[VS_Sources] = 6
}

func Set(key, val string) {
	ctx.stringData[key] = val
}

func Get(key string) string {
	return ctx.stringData[key]
}

func ViewByKey(key string) int {
	return ctx.viewScreens[key]
}

func ViewMain() int {
	return ctx.viewScreens[VS_ProjectTable]
}

func ViewProject() int {
	return ctx.viewScreens[VS_ProjectActionSelection]
}

func ViewSources() int {
	return ctx.viewScreens[VS_Sources]
}

func ViewQuerryProjectKey() int {
	return ctx.viewScreens[VS_ProjectSetProjectKey]
}

func ViewQuerrySelectTarget() int {
	return ctx.viewScreens[VS_ProjectNewTarget]
}

func ViewQuerrySelectSources() int {
	return ctx.viewScreens[VS_ProjectNewSources]
}
