package client

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/internal/transcode"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
)

/*
- 1 обнуляем коллекцию
- 2 считываем файлы и пишем в колекцию


*/

func (cl *clientModel) UpdateProjectCollection() error {
	activeProjectKey := ""
	if cl.data.SelectedProject != nil {
		activeProjectKey = cl.data.SelectedProject.FileKey
	}

	cl.resetProjectData()
	//collect paths
	pfp := cl.projectFilePaths()
	if pfp.err != nil {
		return fmt.Errorf("project collection update failed: %v", pfp.err)
	}
	errors := []error{}
	//update collection
	for _, projectFP := range pfp.paths {
		prj, err := loadProjectFile(projectFP)
		if err != nil {
			errors = append(errors, fmt.Errorf("load project from file %v failed: %v", projectFP, err))
			continue
		}
		if present, ok := cl.data.ProjectData[prj.FileKey]; ok {
			errors = append(errors, fmt.Errorf("loaded project %v present in collection:\n  loaded: %v\n present: %v", projectFP, prj, present))
			continue
		}
		switch matchWithTable(prj, cl.data.SpreadsheetRows) {
		case true:
			cl.data.ProjectData[prj.FileKey] = prj
		case false:
			os.Remove(projectFP)
			events.PublishNewEvent("project_closed", payload.String("key", prj.FileKey))
		}

	}
	//restore project selection if available
	if _, ok := cl.data.ProjectData[activeProjectKey]; ok {
		cl.data.SelectedProject = cl.data.ProjectData[activeProjectKey]
	}

	return combinedError(errors...)
}

func (cl *clientModel) resetProjectData() {
	cl.data.SelectedProject = nil
	cl.data.ProjectData = nil
	cl.data.ProjectData = make(map[string]*transcode.Project)

}

type projectFilePaths struct {
	paths []string
	err   error
}

func (cl *clientModel) projectFilePaths() projectFilePaths {
	pfp := projectFilePaths{}
	dir := cl.data.Config.ProjectStorageDir
	fi, err := os.ReadDir(dir)
	if err != nil {
		pfp.err = fmt.Errorf("failed to read project directory: %v", err)
		return pfp
	}
	for _, f := range fi {
		if f.IsDir() {
			continue
		}
		pfp.paths = append(pfp.paths, dir+f.Name())
	}
	return pfp

}

func matchWithTable(prj *transcode.Project, rows []transcode.SheetRow) bool {
	for _, row := range rows {
		match := 0
		if prj.Title == row.Cells[8].Text {
			match++
		}
		if prj.Agent == row.Cells[13].Text {
			match++
		}
		if prj.DateBlock == row.Cells[14].Text {
			match++
		}
		if match == 3 {
			return true
		}
	}
	return false
}
