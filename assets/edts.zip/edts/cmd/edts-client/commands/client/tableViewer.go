package client

import (
	"slices"
	"strings"

	"github.com/Galdoba/edts/internal/transcode"
	"github.com/charmbracelet/bubbles/table"
)

// var ColumnsNames = []string{
// 	"Name",
// 	"Publication Date",
// 	"Status",
// 	"Project Key",
// }

// func sizes(rows []table.Row) []int {
// 	sizes := []int{}
// 	for i, col := range ColumnsNames {
// 		max := len(col)
// 		for _, row := range rows {
// 			l := len(row[i])
// 			if l > max {
// 				max = l
// 			}
// 		}
// 		sizes = append(sizes, max)
// 	}
// 	return sizes
// }

// func columns(names []string, sizes []int) []table.Column {
// 	cols := []table.Column{}
// 	for i, name := range ColumnsNames {
// 		cols = append(cols, table.Column{name, sizes[i]})
// 	}
// 	return cols
// }

func (pt *ProjectsTable) selectFromMemory() error {
	if selectedRow == nil {
		return nil
	}
	pick := -1
	for k, row := range pt.Table.Rows() {
		if equalRows(selectedRow, row) {
			pick = k
		}
	}
	pt.Table.SetCursor(pick)
	return nil
}

func equalRows(row1, row2 table.Row) bool {
	if len(row1) != len(row2) {
		return false
	}
	for i, field := range row1 {
		if row2[i] != field {
			return false
		}
	}
	return true
}

// func dateToNum(date string) int {
// 	pt := strings.Split(date, ".")
// 	res := 0
// 	for i, p := range pt {
// 		n, _ := strconv.Atoi(p)
// 		switch i {
// 		case 0:
// 			res += n
// 		case 1:
// 			res += n * 100
// 		case 2:
// 			res += n * 10000
// 		}
// 	}
// 	return res
// }

func rowsFromProjects(data []*transcode.Project) []table.Row {
	rows := []table.Row{}
	for _, prj := range data {
		row := table.Row{}
		row = append(row, prj.Title, prj.Agent, prj.DateBlock, prj.StatusStr, prj.Comment)
		// switch prj.ConfirmedBase {
		// case "":
		// 	row = append(row, "[???]")
		// default:
		// 	row = append(row, prj.Comment)
		// }
		rows = append(rows, row)
	}
	return rows
}

func sortByColumn(rows []table.Row, colNum int) []table.Row {
	if len(rows) < 1 {
		return rows
	}
	keyRowMap := make(map[string]table.Row)
	keys := []string{}
	switch colNum {
	// case 0:
	// 	return rows
	default:
		if len(rows[0]) < colNum {
			return rows
		}
		for _, row := range rows {
			key := constructKey(row, colNum)
			keys = append(keys, key)
			keyRowMap[key] = row
		}
	}

	slices.Sort(keys) //TODO: подумать над сортировкой по дате

	sortedRows := []table.Row{}
	for _, k := range keys {
		sortedRows = append(sortedRows, keyRowMap[k])
	}
	return sortedRows
}

func constructKey(row table.Row, firstCol int) string {
	if len(row) < 1 {
		return ""
	}
	if len(row) < firstCol || firstCol < 0 {
		firstCol = 0
	}
	key := row[firstCol]
	for i := 0; i < len(row); i++ {
		switch i {
		case firstCol:
			continue
		default:
			key += row[i] // + "."
		}
	}
	key = strings.ReplaceAll(key, row[2], dateAsPrefix(row[2]))
	return key
}

func dateAsPrefix(date string) string {
	pts := strings.Split(date, ".")
	out := ""
	for i := len(pts) - 1; i >= 0; i-- {
		out += pts[i] + "."
	}
	return strings.TrimSuffix(out, ".")
}
