package client

import (
	"encoding/json"
	"fmt"
	"log"
	"os"

	"github.com/Galdoba/edts/internal/transcode"
)

func (cl *clientModel) LoadExistingProjects() error {
	dir := cl.data.Config.ProjectStorageDir
	fi, err := os.ReadDir(dir)
	if err != nil {
		return fmt.Errorf("failed to read project storage directory: %v", err)
	}
	localErrs := []error{}
	for _, file := range fi {
		prj := transcode.Project{}
		bt, err := os.ReadFile(dir + file.Name())
		if err != nil {
			localErrs = append(localErrs, fmt.Errorf("failed to read project file: %v", err))
			continue
		}
		if err = json.Unmarshal(bt, &prj); err != nil {
			localErrs = append(localErrs, fmt.Errorf("failed to unmarshal project file: %v", err))
			continue
		}
		projectKey := prj.FileKey
		cl.data.ProjectData[projectKey] = &prj
	}
	for _, lErr := range localErrs {
		fmt.Println(lErr)
	}
	log.Printf("%v projects loaded", len(cl.data.ProjectData))

	return nil
}

func (cl *clientModel) SaveProject(prj *transcode.Project) error {

	filepath := cl.projectFilePath(prj)
	cl.data.ProjectData[prj.FileKey] = prj
	bt, err := json.Marshal(prj)
	if err != nil {
		return fmt.Errorf("project marshaling failed: %v", err)
	}
	f, err := os.Create(filepath)
	if err != nil {
		return fmt.Errorf("project file creation failed: %v", err)
	}
	_, err = f.Write(bt)
	if err != nil {
		return fmt.Errorf("project file writing failed: %v", err)
	}

	return f.Close()
}

func (cl *clientModel) UpdateFromSpreadsheetDB() error {
	return nil
}
