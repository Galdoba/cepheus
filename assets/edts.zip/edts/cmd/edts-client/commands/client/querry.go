package client

import (
	"slices"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/clientcontext"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/tiler"
	"github.com/Galdoba/edts/internal/btblocks/querry"
	"github.com/Galdoba/edts/internal/transcode"

	//	"github.com/Galdoba/edts/internal/transcode/product"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

const (
	Querry_Key        = "Выбери Ключ-Основу для проекта:"
	Querry_TargetType = "Выбери тип задачи:"
	Querry_Sources    = "Выбери исходные файлы для задачи:"
)

// var querryTitleOffset = ""

func newQuerryHeader() (string, lipgloss.Style) {
	text := "Запрос пользователю"
	style := lipgloss.NewStyle().Border(lipgloss.NormalBorder(), true).BorderForeground(lipgloss.Color("56")).Align(lipgloss.Center).Width(tiler.BlocksHorisontal(1) - 2)
	return text, style
}

type ClientQuerry struct {
	simple   bool
	Single   *SingleQuerry
	Multiple *MultipleQuerry
}

func (cq *ClientQuerry) Init() tea.Cmd {
	return nil
}

func (cq *ClientQuerry) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	switch cq.simple {
	case true:
		qr, cmd := cq.Single.Update(msg)
		cmds = append(cmds, cmd)
		cq.Single = qr.(*SingleQuerry)
	case false:
		qr, cmd := cq.Multiple.Update(msg)
		cmds = append(cmds, cmd)
		cq.Multiple = qr.(*MultipleQuerry)
	}
	return cq, tea.Batch(cmds...)
}

func (cq *ClientQuerry) View() string {
	s := ""
	switch cq.simple {
	case true:
		s = cq.Single.View()
	case false:
		s = cq.Multiple.View()
	}
	return s
}

type SingleQuerry struct {
	Querry       *querry.QuerryModel
	InitialState string
	Key          string
}

type MultipleQuerry struct {
	Querry *querry.QuerryModel
	Keys   []string
}

func NewProjectKeySelection(prj *transcode.Project) *SingleQuerry {
	sq := SingleQuerry{}
	curs := querry.DefaultCursor
	curs.Active = ">>"
	curs.Passive = "  "
	qm := querry.New(
		querry.WithTitle(curs.Passive+curs.Passive+Querry_Key),
		querry.WithItems(querry.KeysToItems(prj.PossibleBase...)...),
		querry.WithHeader(newQuerryHeader()),
		querry.WithGaps(1, 1, 0, 0),
		querry.WithCursor(curs),
		querry.WithResponseMethod(querry.Single),
	)
	qm.Height = tiler.BlocksVertical(1)
	sq.Querry = &qm
	sq.InitialState = prj.ConfirmedBase
	//querryTitleOffset = curs.Passive + curs.Passive
	return &sq
}

// func NewProject_AddTarget(prj *transcode.Project) *SingleQuerry {
// 	sq := SingleQuerry{}
// 	curs := querry.DefaultCursor
// 	curs.Active = ">>"
// 	curs.Passive = "  "
// 	qm := querry.New(
// 		querry.WithTitle(curs.Passive+curs.Passive+Querry_TargetType),
// 		querry.WithItems(querry.KeysToItems(product.REQUEST_TYPE_FILM, product.REQUEST_TYPE_TRL)...),
// 		querry.WithHeader(newQuerryHeader()),
// 		querry.WithGaps(1, 1, 0, 0),
// 		querry.WithCursor(curs),
// 		querry.WithResponseMethod(querry.Single),
// 	)
// 	sq.Querry = &qm
// 	sq.InitialState = prj.ConfirmedBase
// 	return &sq
// }

func NewProject_SetSources(cl *clientModel) *MultipleQuerry {

	mq := MultipleQuerry{}
	curs := querry.DefaultCursor
	curs.Active = ">>"
	curs.Passive = "  "
	files := cl.ListInFiles()
	qm := querry.New(
		querry.WithTitle(curs.Passive+curs.Passive+Querry_Sources+"\n"+curs.Passive+curs.Passive+cl.data.Config.SourceDir),
		querry.WithItems(querry.KeysToItems(files...)...),
		querry.WithHeader(newQuerryHeader()),
		querry.WithGaps(1, 1, 0, 0),
		querry.WithCursor(curs),
		querry.WithResponseMethod(querry.Multiple),
	)

	qm.Height = tiler.BlocksVertical(1)
	mq.Querry = &qm

	//mq.InitialState = prj.ConfirmedBase
	return &mq
}

func (sq *SingleQuerry) Init() tea.Cmd {
	return nil
}

func (sq *SingleQuerry) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	switch msgTyped := msg.(type) {
	case tea.KeyMsg:
		switch keypress := msgTyped.String(); keypress {
		case "enter":
			qr, cmd := sq.Querry.Update(msg)
			cmds = append(cmds, cmd)
			sq.Querry = qr.(*querry.QuerryModel)
			sq.Key = sq.InitialState
			if answer := sq.Querry.Single(); answer != nil {
				sq.Key = sq.Querry.Single().Key()
			}
			switch {
			default:
				panic("unknown querry: '" + sq.Querry.Title + "'")
			case strings.Contains(sq.Querry.Title, Querry_Key):
				cmds = append(cmds, teacmd.ChangeView(clientcontext.ViewQuerryProjectKey(), clientcontext.ViewProject()))
			case strings.Contains(sq.Querry.Title, Querry_TargetType):
				cmds = append(cmds, teacmd.ChangeView(VS_Project_NewTarget, clientcontext.ViewProject()))
			}
			//cmds = append(cmds, teacmd.ChangeView(clientcontext.ViewQuerryProjectKey(), clientcontext.ViewProject()))
		case "esc":
			cmds = append(cmds, teacmd.ChangeView(clientcontext.ViewQuerryProjectKey(), clientcontext.ViewProject()))
		default:
			qr, cmd := sq.Querry.Update(msg)
			cmds = append(cmds, cmd)
			sq.Querry = qr.(*querry.QuerryModel)
		}
	default:
	}
	return sq, tea.Batch(cmds...)
}

func (sq *SingleQuerry) View() string {
	return sq.Querry.View()
}

func (sq *MultipleQuerry) Init() tea.Cmd {
	return nil
}

func (sq *MultipleQuerry) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmds []tea.Cmd
	switch msgTyped := msg.(type) {
	case tea.KeyMsg:
		switch keypress := msgTyped.String(); keypress {
		case "enter":
			qr, cmd := sq.Querry.Update(msg)
			cmds = append(cmds, cmd)
			sq.Querry = qr.(*querry.QuerryModel)
			//sq.Key = sq.InitialState
			if answer := sq.Querry.Multiple(); answer != nil {
				for _, key := range answer {
					sq.Keys = append(sq.Keys, key.Key())
				}
				slices.Sort(sq.Keys)
			}
			switch {
			default:
				panic("unknown querry: '" + sq.Querry.Title + "'")
			case strings.Contains(sq.Querry.Title, Querry_Sources):
				cmds = append(cmds, teacmd.ChangeView(VS_Project_NewSources, clientcontext.ViewProject()))
			}
			//cmds = append(cmds, teacmd.ChangeView(clientcontext.ViewQuerryProjectKey(), clientcontext.ViewProject()))
		case "esc":
			cmds = append(cmds, teacmd.ChangeView(VS_NO_VIEW, clientcontext.ViewProject()))
		default:
			qr, cmd := sq.Querry.Update(msg)
			cmds = append(cmds, cmd)
			sq.Querry = qr.(*querry.QuerryModel)
		}
	default:
	}
	return sq, tea.Batch(cmds...)
}

func (sq *MultipleQuerry) View() string {
	return sq.Querry.View()
}
