package client

import (
	"encoding/json"
	"slices"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teamsg"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
	"github.com/charmbracelet/bubbles/table"
)

func (cl *clientModel) selectProject(row table.Row) {
	for k, pr := range cl.data.ProjectData {
		if pr.Title+pr.DateBlock == row[0]+row[2] {
			cl.data.SelectedProject = cl.data.ProjectData[k]
			break
		}
	}
}

func (cl *clientModel) ListInFiles() []string {
	list := []string{}
	fileDB_Copy, err := cl.data.FilesDB.LoadCopyFromFile()
	if err != nil {
		return []string{"ERROR"}
	}
	entries := fileDB_Copy.Payload
	for _, entry := range entries {
		bt, err := entry.MarshalJSON()
		if err != nil {
			return []string{"ERROR MARSHALING"}
		}
		source := sourceFile{}
		if err := json.Unmarshal(bt, &source); err != nil {
			continue
		}
		if source.Dir != cl.data.Config.SourceDir {
			continue
		}
		list = append(list, source.Name)

	}
	slices.Sort(list)
	return list
}

type sourceFile struct {
	Dir  string `json:"Directory"`
	Name string `json:"Name"`
}

func (cl *clientModel) Request_TableDB_Update() {
	events.PublishNewEvent(events.WORKSHEET_FETCH_REQUSTED)
}

func (cl *clientModel) Request_Path_To_Table(msg teamsg.PathToSpreadsheetRequestedMsg) {
	projectPath := string(msg)
	events.PublishNewEvent(events.WORKSHEET_WRITE_REQUSTED, payload.String(payload.PATH, projectPath))
}
