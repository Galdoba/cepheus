package client

import (
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teacmd"
	"github.com/Galdoba/edts/cmd/edts-client/commands/client/teamsg"
	"github.com/Galdoba/edts/internal/btblocks/teablock"
	tea "github.com/charmbracelet/bubbletea"
)

const (
	VS_NO_VIEW                = 0
	VS_ProjectTable           = 1
	VS_ProjectActionSelection = 2
	VS_Project_SetProjectKey  = 3
	VS_Project_NewTarget      = 4
	VS_Project_NewSources     = 5
)

var header = teablock.Coordinates(0, 0)
var navigation = teablock.Coordinates(1, 0)
var mainBlock = teablock.Coordinates(1, 1)
var eventLog = teablock.Coordinates(1, 2)
var help = teablock.Coordinates(2, 0)

var tck = 0

func (cl clientModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	var cmds []tea.Cmd
	switch msgTyped := msg.(type) {
	case selectionMsg:
		//cl.selectProject(cl.screen.Projects.SelectionMem)
	case teamsg.NavigationMsg:
		if err := cl.swapView(msgTyped); err != nil {
			panic(err.Error())
		}
	case teamsg.SpreadsheetUpdatedMsg:
		if msgTyped {
			cl.UpdateData()
		}
	case teamsg.SpreadsheetUpdateRequestedMsg:
		cl.Request_TableDB_Update()
	case teamsg.PathToSpreadsheetRequestedMsg:
		cl.Request_Path_To_Table(msgTyped)

	case teamsg.TickMsg:
		//	        // Return your Every command again to loop.
		cmd = teacmd.TickEvery()
		cmds = append(cmds, cmd)
		cmds = append(cmds, updateEventLog())
		cmds = append(cmds, teacmd.UpdateRowsCmd())

		//cmds = append(cmds, updateNavigation(cl))
	case tea.KeyMsg:
		//		cl.data.Events = append(cl.data.Events, msgTyped.String()+" pressed")
		switch keypress := msgTyped.String(); keypress {
		case "q", "Q", "й", "Й":
			return cl, tea.Quit
		case "ctrl+c":
			return cl, tea.Quit
		default:

		}
	default:
	}

	m, cmdm := cl.screen.Layout.Update(msg)
	cl.screen.Layout = m.(*teablock.Layout)

	cmds = append(cmds, cmdm)
	cmds = append(cmds, cmd)
	//cl.updateNav()

	return cl, tea.Batch(cmds...)
}

func (cl *clientModel) swapView(navMsg teamsg.NavigationMsg) error {
	cl.screen.ViewScreen = navMsg.TargetView
	if err := cl.onViewSwitchChanges(navMsg); err != nil {
		return err
	}

	switch cl.screen.ViewScreen {
	case VS_ProjectTable:

	// case VS_ProjectActionSelection:
	// 	cl.selectProject(selectedRow)
	// 	cl.screen.Layout.Swap(NewOrderTable(cl.data.SelectedProject), mainBlock)
	// 	cl.screen.HelpText.text = orderTableHelp()
	case VS_Project_SetProjectKey:
		// cq := ClientQuerry{simple: true, Single: NewProjectKeySelection(cl.data.SelectedProject)}
		// cl.screen.Query = &cq
		// cl.screen.Layout.Swap(cl.screen.Query, mainBlock)
	case VS_Project_NewTarget:
		// cq := ClientQuerry{simple: true, Single: NewProject_AddTarget(cl.data.SelectedProject)}
		// cl.screen.Query = &cq
		// cl.screen.Layout.Swap(cl.screen.Query, mainBlock)

	}
	cl.screen.Layout.Swap(cl.screen.HelpText, help)
	return nil
}
