package table

import (
	"context"
	"encoding/json"
	"fmt"
	"os"

	"github.com/Galdoba/edts/internal/db/worksheet"
	"github.com/Galdoba/edts/pkg/atempted"
	"golang.org/x/oauth2/google"
	"gopkg.in/Iwark/spreadsheet.v2"
)

type WorksheetDB struct {
	//buffer   []byte
	//filepath string
	service *spreadsheet.Service
	sheet   *spreadsheet.Sheet
}

func WDBcreate(credentialsPath string) (*WorksheetDB, error) {
	wdb := WorksheetDB{}
	service, err := initService(credentialsPath)
	if err != nil {
		return nil, err
	}
	wdb.service = service
	return &wdb, nil
}

func initService(credentials string) (*spreadsheet.Service, error) {
	credData, err := os.ReadFile(credentials)
	if err != nil {
		return nil, fmt.Errorf("failed to read credetinals: %v", err)
	}
	conf, err := google.JWTConfigFromJSON(credData, spreadsheet.Scope)
	if err != nil {
		return nil, fmt.Errorf("failed to create service configuration: %v", err)
	}
	client := conf.Client(context.TODO())
	service := spreadsheet.NewServiceWithClient(client)

	return service, nil
}

func (wdb *WorksheetDB) FetchFromSpreadsheet(tableID, tableName string) (map[string]*worksheet.DB_Cell, error) {
	spreadsheet, err := wdb.service.FetchSpreadsheet(tableID)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch spreadsheet: %v", err)
	}
	sheet, err := spreadsheet.SheetByTitle(tableName) //sheetTitle
	if err != nil {
		return nil, fmt.Errorf("failed to get sheet by title: %v", err)
	}
	sheetInfo := map[string]*worksheet.DB_Cell{}
	for _, row := range sheet.Rows {
		for _, cell := range row {
			sheetInfo[cell.Pos()] = &worksheet.DB_Cell{cell.Value, cell.Note}
		}
	}
	return sheetInfo, nil
}

func cellName(r, c int) string {
	n := ""
	switch c {
	default:
		panic("unnamed region: " + fmt.Sprintf("%v", c))
	case 0:
		n = "A"
	case 1:
		n = "B"
	case 2:
		n = "C"
	case 3:
		n = "D"
	case 4:
		n = "E"
	case 5:
		n = "F"
	case 6:
		n = "G"
	case 7:
		n = "H"
	case 8:
		n = "I"
	case 9:
		n = "J"
	case 10:
		n = "K"
	case 11:
		n = "L"
	case 12:
		n = "M"
	case 13:
		n = "N"
	case 14:
		n = "O"
	}
	return fmt.Sprintf("%v%v", n, r)
}

func (wdb *WorksheetDB) WriteToFile(path string) error {
	if err := atempted.Rename(path, path+".tmp"); err != nil {
		return fmt.Errorf("failed to save back up file: %v", err)
	}
	f, err := atempted.Create(path)
	if err != nil {
		return fmt.Errorf("failed to create new db file: %v", err)
	}
	bt, err := json.MarshalIndent(&wdb, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal db: %v", err)
	}
	_, err = f.Write(bt)
	if err != nil {
		return fmt.Errorf("failed to write db to file: %v", err)
	}
	os.Remove(path + ".tmp")
	return nil
}
