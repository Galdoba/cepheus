package table

// type CellContent struct {
// 	Text string `json:"Value"`
// 	Note string `json:"Note,omitempty"`
// }

// type RowData struct {
// 	Cell []*CellContent `json:"Row"`
// }

// type SheetModel struct {
// 	Rows []*RowData `json:"Spreadsheet"`
// }

// func NewSpreadsheetModel() *SheetModel {
// 	return &SheetModel{}
// }

// func (sm *SheetModel) Append(row *RowData) {

// 	sm.Rows = append(sm.Rows, row)
// }

// func NewCell(text, note string) *CellContent {
// 	return &CellContent{text, note}
// }

// func (row *RowData) Append(cell *CellContent) {
// 	row.Cell = append(row.Cell, cell)
// }

// func (sm *SheetModel) MarshalJSON() ([]byte, error) {
// 	bt, err := json.Marshal(&sm)
// 	if err != nil {
// 		panic(err.Error())
// 	}
// 	return bt, nil
// }

// func (sm *SheetModel) UnmarshalJSON(bt []byte) error {

// 	return json.Unmarshal(bt, sm)
// }

// func (sm *SheetModel) SetText(r, c int, text string) error {
// 	if err := sm.ErrCoordinates(r, c); err != nil {
// 		return err
// 	}
// 	sm.Rows[r].Cell[c].Text = text
// 	return nil
// }

// func (sm *SheetModel) TextFrom(r, c int) (string, error) {
// 	if err := sm.ErrCoordinates(r, c); err != nil {
// 		return "", err
// 	}
// 	return sm.Rows[r].Cell[c].Text, nil
// }

// func (sm *SheetModel) NoteFrom(r, c int) (string, error) {
// 	if err := sm.ErrCoordinates(r, c); err != nil {
// 		return "", err
// 	}
// 	return sm.Rows[r].Cell[c].Note, nil
// }

// func (sm *SheetModel) SetNote(r, c int, note string) error {
// 	if err := sm.ErrCoordinates(r, c); err != nil {
// 		return err
// 	}
// 	sm.Rows[r].Cell[c].Note = note
// 	return nil
// }

// func (sm *SheetModel) RowByID(id int) (*RowData, error) {
// 	if err := sm.ErrNoRow(id); err != nil {
// 		return nil, err
// 	}
// 	return sm.Rows[id], nil
// }

// func (sm *SheetModel) RowByName(name string) (*RowData, error) {
// 	found := []*RowData{}
// 	for _, row := range sm.Rows {
// 		if row.Cell[Col_Наименование].Text == name {
// 			found = append(found, row)
// 		}
// 	}
// 	if len(found)-1 < 1 {
// 		return nil, fmt.Errorf("row '%v' does not exist", name)
// 	}
// 	if len(found) > 1 {
// 		return nil, fmt.Errorf("multiple rows with name '%v' detected", name)
// 	}
// 	return found[0], nil
// }

// func (sm *SheetModel) ErrCoordinates(r, c int) error {
// 	if err := sm.ErrNoRow(r); err != nil {
// 		return err
// 	}
// 	row := sm.Rows[r]
// 	if err := row.ErrNoCell(c); err != nil {
// 		return err
// 	}
// 	return nil
// }

// func (sm *SheetModel) ErrNoRow(r int) error {
// 	if len(sm.Rows)-1 < r {
// 		return fmt.Errorf("row %v does not exist", r)
// 	}
// 	return nil
// }

// func (row *RowData) ErrNoCell(c int) error {
// 	if c < 0 {
// 		return fmt.Errorf("negative column number requested: %v", row)
// 	}
// 	if len(row.Cell)-1 < c {
// 		return fmt.Errorf("column %v does not exist: %v", c, row)
// 	}
// 	return nil
// }

/*

 */

/*
wdb.Row[20].Col[8].Text

*/
