package commands

import (
	"fmt"
	"os"
	"time"

	"github.com/Galdoba/edts/cmd/edts-spreadsheet-tracker-service/worksheet"
	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/internal/service"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/Galdoba/edts/pkg/action"
	"github.com/Galdoba/edts/pkg/atempted"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
	"github.com/urfave/cli/v2"
)

const (
	action_name_update       = "update_spreadsheet"
	action_name_publish_path = "publish_project_path_to_spreadsheet"
)

// var database *db.Database
var wsManager *worksheet.Worksheet
var srv *service.Service

func Run() *cli.Command {
	return &cli.Command{
		Name:        "run",
		Aliases:     []string{},
		Usage:       "normalize names for new names",
		UsageText:   fmt.Sprintf("%v run", definitions.SERVICE_SPREADSHEET_TRACKER),
		Description: "Service will update file with data from work table by cooldown and by request",
		Args:        false,
		ArgsUsage:   "Args Usage Text",
		Category:    "",
		Before: func(c *cli.Context) error {

			return nil
		},
		Action: func(c *cli.Context) error {
			//INIT
			cfg, err := masterconfig.Read()
			if err != nil {
				return err
			}
			if err := loadConfiguration(cfg, c.App.Name); err != nil {
				return err
			}
			atempted.SetMaxAtempts(config.maxRetryAtempts)
			atempted.SetDelay(time.Millisecond * time.Duration(config.delay))
			events.Subscribtions(c.App.Name)
			events.SetupPublisher(c.App.Name, config.outbox)

			spreadsheetInfo := worksheet.SpreadsheetInfo{}
			spreadsheetInfo.Title = config.tableName
			spreadsheetInfo.ID = config.tableID
			spreadsheetInfo.Credentials = config.tableCredentialsFilePath

			wsManager, err = worksheet.New(spreadsheetInfo, db.Create(config.tableDBFile, db.TYPE_SPREADSHEET))
			if err != nil {
				return err
			}

			updateAction := action.New(action_name_update, update_spreadsheet_file)
			updateAction.EnrichWith(
				action.Cooldown(float64(config.cooldown)),
				action.Triggers([]string{events.WORKSHEET_FETCH_REQUSTED}),
			)
			publishAction := action.New(action_name_publish_path, publish_project_path_to_spreadsheet)
			publishAction.EnrichWith(
				action.Triggers([]string{events.WORKSHEET_WRITE_REQUSTED}),
			)
			//MAIN ACTION
			srv = service.New(c.App.Name,
				updateAction,
				//service.WithReactiveAction(events.FILENAME_NORMALIZED, updateAction),
				service.WithConfig(cfg),
			)
			//REACTIONS
			if err := srv.AddReaction(events.WORKSHEET_FETCH_REQUSTED, updateAction); err != nil {
				return err
			}
			if err := srv.AddReaction(action_name_publish_path, publishAction); err != nil {
				return err
			}
			if err := events.PublishNewEvent(events.MODULE_STARTED); err != nil {
				fmt.Fprintf(os.Stderr, "%v\n", err)
			}
			return srv.Run()
		},

		Flags: []cli.Flag{},
	}
}

type serviceConfiguration struct {
	tableCredentialsFilePath string
	tableDBFile              string
	tableID                  string
	tableName                string
	maxRetryAtempts          int
	delay                    int
	inbox                    string
	outbox                   string
	cooldown                 int
}

var config *serviceConfiguration

func loadConfiguration(mcfg *masterconfig.MasterConfig, app string) error {
	config = &serviceConfiguration{}
	config.tableCredentialsFilePath = mcfg.Service_Values[app][masterconfig.Key_Credentials_file]
	config.tableDBFile = mcfg.Service_Values[app][masterconfig.KEY_DB_FILEPATH]
	config.tableID = mcfg.Service_Values[app][masterconfig.Key_Spreadsheet_ID]
	config.tableName = mcfg.Service_Values[app][masterconfig.Key_Spreadsheet_Name]
	config.maxRetryAtempts = mcfg.Service_RetryAttempts[app]
	config.delay = mcfg.Service_RetryDelay_Milliseconds[app]
	config.inbox = mcfg.Service_Paths[app][masterconfig.KEY_INBOX]
	config.outbox = mcfg.Service_Paths[app][masterconfig.KEY_OUTBOX]
	config.cooldown = mcfg.Service_Cooldown[app]
	return nil
}

func update_spreadsheet_file(args ...interface{}) error {
	if len(args) != 0 {
		return fmt.Errorf("action '%v' expect no arguments", action_name_update)
	}
	errCount := 0
	for {
		_, err := wsManager.ReadRemote()
		switch err {
		case nil:
			return nil
		default:
			errCount++
			if errCount > 10 {
				return err
			}
		}
	}
}

func publish_project_path_to_spreadsheet(args ...interface{}) error {
	action := srv.ReactionActions[action_name_publish_path]
	ev := action.TriggerEvent
	data := ev.Disassemble()
	path := data[payload.PATH]
	// switch v := args[0].(type) {
	// default:
	// 	return fmt.Errorf("action '%v' expect string as an argument: received %T", action_name_publish_path, v)
	// case string:
	// 	path = v
	// }
	prj, err := transcode.Load(path)
	if err != nil {
		return fmt.Errorf("failed to load project: %v", err)
	}
	if err = wsManager.PublishPath(prj); err != nil {
		return err
	}
	return nil
}

// func updateSpreadsheetFile() error {
// 	fmt.Printf("updating...                                        \r")
// 	wdb, err := table.WDBcreate(config.tableCredentialsFilePath)
// 	if err != nil {
// 		return fmt.Errorf("failed to create worksheet request: %v", err)
// 	}
// 	sheetInfo, err := wdb.FetchFromSpreadsheet(config.tableID, config.tableName)
// 	if err != nil {
// 		return fmt.Errorf("failed to fetch data from spreadsheet: %v", err)
// 	}
// 	database = db.Create(config.tableDBFile, db.TYPE_SPREADSHEET)
// 	for k, val := range sheetInfo {
// 		if err := database.Update(k, val); err != nil {
// 			fmt.Println(err)
// 		}
// 	}
// 	if err = database.Save(); err != nil {
// 		fmt.Println(err)
// 	}

// 	fmt.Printf("last updated: %v\r", time.Now().Format(time.DateTime))
// 	return nil
// }
