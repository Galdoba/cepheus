package commands

// import (
// 	"fmt"
// 	"os"
// 	"time"

// 	"github.com/Galdoba/edts/cmd/edts-spreadsheet-tracker-service/commands/table"
// 	"github.com/Galdoba/edts/internal/db"
// 	"github.com/Galdoba/edts/internal/definitions"
// 	"github.com/Galdoba/edts/internal/masterconfig"
// 	"github.com/Galdoba/edts/internal/service"
// 	"github.com/Galdoba/edts/pkg/action"
// 	"github.com/Galdoba/edts/pkg/atempted"
// 	"github.com/Galdoba/edts/pkg/events"
// 	"github.com/urfave/cli/v2"
// )

// const (
// 	action_name = "update_spreadsheet"
// )

// var database *db.Database

// func Run() *cli.Command {
// 	return &cli.Command{
// 		Name:        "run",
// 		Aliases:     []string{},
// 		Usage:       "normalize names for new names",
// 		UsageText:   fmt.Sprintf("%v run", definitions.SERVICE_SPREADSHEET_TRACKER),
// 		Description: "Service will update file with data from work table by cooldown and by request",
// 		Args:        false,
// 		ArgsUsage:   "Args Usage Text",
// 		Category:    "",
// 		Before: func(c *cli.Context) error {

// 			return nil
// 		},
// 		Action: func(c *cli.Context) error {
// 			//INIT
// 			cfg, err := masterconfig.Read()
// 			if err != nil {
// 				return err
// 			}
// 			if err := loadConfiguration(cfg, c.App.Name); err != nil {
// 				return err
// 			}
// 			atempted.SetMaxAtempts(config.maxRetryAtempts)
// 			atempted.SetDelay(time.Millisecond * time.Duration(config.delay))
// 			events.Subscribtions(c.App.Name)
// 			events.SetupPublisher(c.App.Name, config.outbox)
// 			if err := events.PublishNewEvent(events.SERVICE_STARTED); err != nil {
// 				fmt.Fprintf(os.Stderr, "%v\n", err)
// 			}
// 			database = db.Create(config.tableDBFile, db.TYPE_SPREADSHEET)
// 			// database, err = database.LoadCopyFromFile()
// 			// if err != nil {
// 			// 	panic(err.Error())
// 			// }
// 			// bt, err := database.Read("N738")
// 			// if err != nil {
// 			// 	panic(err.Error())
// 			// }
// 			// cell := &worksheet.DB_Cell{}
// 			// if err := json.Unmarshal(bt, cell); err != nil {
// 			// 	panic(err.Error())
// 			// }
// 			// fmt.Println(cell)

// 			updateAction := action.New(action_name, update_spreadsheet_file)
// 			updateAction.EnrichWith(
// 				action.Cooldown(float64(config.cooldown)),
// 				action.Triggers([]string{events.WORKSHEET_UPDATE_REQUSTED}),
// 				//action.WithArg("update_directory"+"_"+action.Cooldown_Argument+"0", cfg),
// 				//action.WithArg("update_directory"+"_"+action.Trigger_Argument+"0", cfg),
// 			)
// 			srv := service.New(c.App.Name,
// 				updateAction,
// 				//service.WithReactiveAction(events.FILENAME_NORMALIZED, updateAction),
// 				service.WithConfig(cfg),
// 			)
// 			if err := srv.AddReaction(events.WORKSHEET_UPDATE_REQUSTED, updateAction); err != nil {
// 				return err
// 			}
// 			fmt.Println("service started")
// 			return srv.Run()
// 		},

// 		Flags: []cli.Flag{},
// 	}
// }

// type serviceConfiguration struct {
// 	tableCredentialsFilePath string
// 	tableDBFile              string
// 	tableID                  string
// 	tableName                string
// 	maxRetryAtempts          int
// 	delay                    int
// 	inbox                    string
// 	outbox                   string
// 	cooldown                 int
// }

// var config *serviceConfiguration

// func loadConfiguration(mcfg *masterconfig.MasterConfig, app string) error {
// 	config = &serviceConfiguration{}
// 	config.tableCredentialsFilePath = mcfg.Service_Values[app][masterconfig.Key_Credentials_file]
// 	config.tableDBFile = mcfg.Service_Values[app][masterconfig.KEY_DB_FILEPATH]
// 	config.tableID = mcfg.Service_Values[app][masterconfig.Key_Spreadsheet_ID]
// 	config.tableName = mcfg.Service_Values[app][masterconfig.Key_Spreadsheet_Name]
// 	config.maxRetryAtempts = mcfg.Service_RetryAttempts[app]
// 	config.delay = mcfg.Service_RetryDelay_Milliseconds[app]
// 	config.inbox = mcfg.Service_Paths[app][masterconfig.KEY_INBOX]
// 	config.outbox = mcfg.Service_Paths[app][masterconfig.KEY_OUTBOX]
// 	config.cooldown = mcfg.Service_Cooldown[app]
// 	return nil
// }

// func update_spreadsheet_file(args ...interface{}) error {
// 	if len(args) != 0 {
// 		return fmt.Errorf("action '%v' expect no arguments", action_name)
// 	}
// 	errCount := 0
// 	for {
// 		err := updateSpreadsheetFile()
// 		switch err {
// 		case nil:
// 			err = events.PublishNewEvent(events.WORKSHEET_UPDATED)
// 			if err != nil {
// 				fmt.Println(err)
// 			}
// 			return nil
// 		default:
// 			fmt.Printf("update atempt %v: %v\n", errCount+1, err)
// 			errCount++
// 			if errCount > 10 {
// 				return err
// 			}
// 		}
// 	}
// }

// func updateSpreadsheetFile() error {
// 	fmt.Printf("updating...                                        \r")
// 	wdb, err := table.WDBcreate(config.tableCredentialsFilePath)
// 	if err != nil {
// 		return fmt.Errorf("failed to create worksheet request: %v", err)
// 	}
// 	sheetInfo, err := wdb.FetchFromSpreadsheet(config.tableID, config.tableName)
// 	if err != nil {
// 		return fmt.Errorf("failed to fetch data from spreadsheet: %v", err)
// 	}
// 	database = db.Create(config.tableDBFile, db.TYPE_SPREADSHEET)
// 	for k, val := range sheetInfo {
// 		if err := database.Update(k, val); err != nil {
// 			fmt.Println(err)
// 		}
// 	}
// 	if err = database.Save(); err != nil {
// 		fmt.Println(err)
// 	}

// 	fmt.Printf("last updated: %v\r", time.Now().Format(time.DateTime))
// 	return nil
// }
