package worksheet

import (
	"encoding/json"
	"fmt"

	"github.com/Galdoba/edts/internal/spreadsheet/position"
)

// ProjectRow - это то что записано в таблице о проекте
type ProjectRow struct {
	RowNum    int
	RowValues []string
	RowNotes  []string
}

type Cell struct {
	CellPosition position.CellPositioning `json:"-"`
	Value        string                   `json:"Value"`
	Note         string                   `json:"Note,omitempty"`
}

// func (t1 *T1E) MarshalJSON() ([]byte, error) {
// 	type U *T1E
// 	tNew := U(t1)
// 	tNew.Stats = t1.Stats
// 	tNew.Stats2 = t1.Stats2
// 	tNew.Stats3 = t1.Stats3
// 	bt, err := json.MarshalIndent(*tNew, "", "  ")
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to marshal *T1E struct: %v", err)
// 	}
// 	return bt, err
// }

// func (t1 *T1E) UnmarshalJSON(data []byte) error {
// 	type Ent *T1E
// 	tNew := Ent(t1)
// 	tNew.Stats = t1.Stats
// 	tNew.Stats2 = t1.Stats2
// 	tNew.Stats3 = t1.Stats3
// 	if err := json.Unmarshal(data, tNew); err != nil {
// 		return fmt.Errorf("failed to unmarshal *T1E struct: %v", err)
// 	}
// 	return nil
// }

// type Alias struct {
// 	Value string `json:"Value"`
// 	Note  string `json:"Note,omitempty"`
// }

func (c *Cell) MarshalJSON() ([]byte, error) {
	type Alias *Cell
	alias := Alias(c)
	alias.Value = c.Value
	alias.Note = c.Note
	bt, err := json.Marshal(*alias)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal *Cell: %v", err)
	}
	return bt, err
}

func (c *Cell) UnmarshalJSON(bt []byte) error {
	type Alias *Cell
	alias := Alias(c)
	alias.Value = c.Value
	alias.Note = c.Note
	err := json.Unmarshal(bt, alias)
	return err
}
