package worksheet

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/spreadsheet/gsagent"
	"github.com/Galdoba/edts/internal/spreadsheet/position"
	"github.com/Galdoba/edts/internal/spreadsheet/schema"
	"github.com/Galdoba/edts/internal/transcode"
	"github.com/Galdoba/edts/pkg/events"
)

type Worksheet struct {
	TableDB     *db.Database
	TableSchema schema.SpreadsheetSchema
	SheetAgent  *gsagent.SpreadsheetAgent
}

type SpreadsheetInfo struct {
	ID          string `json:"id"`
	Title       string `json:"title"`
	Credentials string `json:"credentials path"`
}

func New(rdb SpreadsheetInfo, ldb *db.Database) (*Worksheet, error) {
	ws := Worksheet{}
	ws.TableDB = ldb
	ws.TableSchema = schema.ContentcomSchema
	agent, err := gsagent.NewAgent(
		gsagent.WithTableID(rdb.ID),
		gsagent.WithTitle(rdb.Title),
		gsagent.WithCredentials(rdb.Credentials),
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create gsagent: %v", err)
	}
	ws.SheetAgent = agent
	return &ws, nil
}

func (ws *Worksheet) ReadRemote() (map[string]Cell, error) {
	if err := ws.SheetAgent.Fetch(); err != nil {
		return nil, fmt.Errorf("failed to fetch remote data: %v", err)
	}
	data := make(map[string]Cell)
	for r, row := range ws.SheetAgent.Sheet().Rows {
		for c, cellRemote := range row {
			cell := Cell{}
			cell.CellPosition = position.Coordinates(r, c)
			cell.Value = cellRemote.Value
			cell.Note = cellRemote.Note
			if err := cell.CellPosition.Validate(); err != nil {
				return nil, fmt.Errorf("failed to validate extracted data with position '%v': %v", cell.CellPosition, err)
			}
			data[cell.CellPosition.Position] = cell
		}
	}
	if err := ws.writeLocal(data); err != nil {
		return data, err
	}
	return data, nil
}

func (ws *Worksheet) ReadLocal() (map[string]Cell, error) {
	rawData, err := ws.TableDB.LoadCopyFromFile()
	if err != nil {
		return nil, fmt.Errorf("failed to load local copy of data: %v", err)
	}
	data := make(map[string]Cell)
	for k := range rawData.Payload {
		cell := Cell{}
		bt, err := rawData.Read(k)
		if err != nil {
			return nil, fmt.Errorf("failed to read entry with key '%v'", k)
		}
		if err = json.Unmarshal(bt, &cell); err != nil {
			return nil, fmt.Errorf("failed to unmarshal cell data from entry with key '%v': %v", k, err)
		}
		cell.CellPosition = position.Position(k)
		if err = cell.CellPosition.Validate(); err != nil {
			return nil, fmt.Errorf("failed to validate cell data from entry with key '%v': %v", k, err)
		}
		data[k] = cell
	}

	return data, nil
}

func (ws *Worksheet) WriteRemote(cells ...Cell) error {
	remote, err := ws.ReadRemote()
	if err != nil {
		return fmt.Errorf("can't wrrite remote: %v", err)
	}
	for _, cell := range cells {
		crd := cell.CellPosition
		if remote[crd.Position].Value != cell.Value {
			ws.SheetAgent.Sheet().Update(crd.Row, crd.Column, cell.Value)
			remCell := remote[crd.Position]
			remCell.Value = cell.Value
			remote[crd.Position] = remCell
		}
		if remote[crd.Position].Note != cell.Note {
			ws.SheetAgent.Sheet().Update(crd.Row, crd.Column, cell.Note)
			remCell := remote[crd.Position]
			remCell.Note = cell.Note
			remote[crd.Position] = remCell
		}
	}
	if err := ws.SheetAgent.Sheet().Synchronize(); err != nil {
		return fmt.Errorf("failed to write remote: %v")
	}
	if err = ws.writeLocal(remote); err != nil {
		return fmt.Errorf("failed to write local: %v")
	}
	return nil
}

func (ws *Worksheet) writeLocal(cells map[string]Cell) error {
	for pos, cell := range cells {
		switch pos {
		case "01063":
			if cell.Value == "" && cell.Note == "" {
				fmt.Println(cells)
				panic(0)
			}
		}
		if err := ws.TableDB.Update(pos, &cell); err != nil {
			return fmt.Errorf("failed to update cell %v: %v", cell, err)
		}

	}
	for pos := range ws.TableDB.Payload {
		if _, ok := cells[pos]; !ok {
			ws.TableDB.Delete(pos)
		}
	}
	if err := ws.TableDB.Save(); err != nil {
		return err
	}
	if events.PublishNewEvent(events.WORKSHEET_UPDATED) == nil {
		fmt.Printf("spreadsheet updated at %v            \r", time.Now().Format(time.RFC3339))
	}

	return nil
}

func (ws *Worksheet) PublishPath(prj *transcode.Project) error {
	err := ws.SheetAgent.FillPathColumn(prj)
	if err != nil {
		return err
	}
	_, err = ws.SheetAgent.Sync()
	if err != nil {
		return err
	}
	if _, err = ws.ReadRemote(); err != nil {
		return err
	}
	// remote := make(map[string]Cell)
	// for _, v := range remoteRaw {
	// 	cell := Cell{}
	// 	cell.CellPosition = position.Position(v.Position)
	// 	cell.Value = v.Value
	// 	cell.Note = v.Note
	// 	remote[cell.CellPosition.Position] = cell
	// }
	// if err := ws.writeLocal(remote); err != nil {
	// 	return fmt.Errorf("failed to write local: %v", err)
	// }
	return nil
}
