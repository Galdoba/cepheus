package main

/*
обновляем списки содержимого в заданных директориях
отсылаем брокеру эвенты с изменениями
все пути в конфигах
своих логов нет?
*/
import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/cmd/edts/commands"
	"github.com/urfave/cli/v2"
)

func main() {
	app := cli.NewApp()
	app.Name = "edts"
	app.Version = "0.0.0"
	app.Usage = "edts service managment"
	app.Flags = []cli.Flag{}

	app.Commands = []*cli.Command{
		commands.Config(),
		commands.Install(),
		commands.Run(),
		commands.Stats(),
	}

	//ПО ОКОНЧАНИЮ ДЕЙСТВИЯ
	app.After = func(c *cli.Context) error {
		return nil
	}
	args := os.Args
	if err := app.Run(args); err != nil {
		errOut := fmt.Sprintf("error: %v: %v", app.Name, err.Error())
		println(errOut)

		os.Exit(1)
	}

}
