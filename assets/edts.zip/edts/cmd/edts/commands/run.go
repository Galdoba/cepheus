package commands

import (
	"fmt"
	"os/exec"
	"sync"
	"time"

	"github.com/urfave/cli/v2"
)

var commandsExecs []exec.Cmd

func Run() *cli.Command {
	return &cli.Command{
		Name:   "run",                               //
		Usage:  "run edts modules for current user", //
		Action: RunModules,                          //
		//Subcommands: []*cli.Command{{Name: "health", Usage: "edts config health", Action: ReadConfig}}, //

	}

}

func RunModules(c *cli.Context) error {
	setPaths()
	// mcfg, err := masterconfig.Load(configPath)
	// if err != nil {
	// 	return err
	// }

	start, err := promptMultipleSelection()
	if err != nil {
		return err
	}
	fmt.Println(start)

	startApps(start...)
	i := 0
	for {
		time.Sleep(time.Second)
		i++
		for _, exe := range commandsExecs {
			fmt.Println(exe.Stdout)
		}
		fmt.Println("---")
	}
	fmt.Println("DONE")
	return nil
}

func startApps(apps ...string) {

	var wg sync.WaitGroup
	//commandsExecs := []exec.Cmd{}
	for _, app := range apps {

		nextCommW := exec.Cmd{}
		nextCommW.Path = fmt.Sprintf("%v/bin/%v.exe", gopath, app)
		nextCommW.Args = append(nextCommW.Args, "run")

		commandsExecs = append(commandsExecs, nextCommW)
	}

	for x := 0; x < len(commandsExecs); x++ {
		wg.Add(1)
		fmt.Println("starting up", commandsExecs[x])
		go initialize(&wg, commandsExecs[x])
	}
	time.Sleep(time.Second)

}

func initialize(wg *sync.WaitGroup, ccmds exec.Cmd) {
	defer wg.Done()
	fmt.Println("initializing", ccmds.Path)
	if err := ccmds.Run(); err != nil {
		fmt.Println(err)
	}

	fmt.Println("started", ccmds.Path)
	// if err := ccmds.Wait(); err != nil {
	// 	fmt.Println(",,,", err)
	// }
}
