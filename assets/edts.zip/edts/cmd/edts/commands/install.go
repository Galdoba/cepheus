package commands

import (
	"fmt"
	"strings"
	"time"

	"os"

	"github.com/Galdoba/devtools/cli/command"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/pkg/kval"
	"github.com/charmbracelet/huh"
	"github.com/fatih/color"
	"github.com/urfave/cli/v2"
)

var gopath string
var configPath string

func Install() *cli.Command {
	return &cli.Command{
		Name:   "install",                               //
		Usage:  "install edts modules for current user", //
		Action: InstallModule,                           //
		//Subcommands: []*cli.Command{{Name: "health", Usage: "edts config health", Action: ReadConfig}}, //

	}

}

func InstallModule(c *cli.Context) error {
	setPaths()
	installKval()
	if err := checkEdtsPaths(); err != nil {
		return err
	}
	fmt.Println("Installation step 1: Create Master Config")
	mcfg := masterconfig.New(configPath)
	if err := masterconfig.Save(mcfg, configPath); err != nil {
		return err
	}
	fmt.Println("Installation step 2: Select modules")
	modules, err := promptMultipleSelection()
	if err != nil {
		return err
	}
	fmt.Println("Installation step 3: Install modules")
	errors := []error{}
	for _, module := range modules {
		fmt.Print("  ", widened(module, maxLen(modules)), "        ")

		if err := install(module); err != nil {
			fmt.Println(color.RedString("failed"))
			errors = append(errors, err)
			continue
		}
		fmt.Println(color.GreenString("ok"))
	}
	for _, err := range errors {
		fmt.Println(err)
	}
	fmt.Println("Installation completed")
	return nil
}

func install(module string) error {
	path := fmt.Sprintf("%v/src/github.com/Galdoba/edts/cmd/%v/", gopath, module)
	if err := os.Chdir(path); err != nil {
		fmt.Println("cd:", err)
		return err
	}
	//fmt.Print("cd", path)
	buildCommand := fmt.Sprintf("go install")
	if o, e, err := command.Execute(buildCommand); err != nil {
		fmt.Println("")
		fmt.Println("install error:", err)
		fmt.Println(o)
		fmt.Println(e)
		return err
	}
	mcfg, err := masterconfig.Read()
	if err != nil {
		return fmt.Errorf("failed to reach")
	}
	for _, dir := range mcfg.Service_Paths[module] {
		if err := os.MkdirAll(dir, 0777); err != nil {
			return fmt.Errorf("failed to create directory (%v) for (%v)", dir, module)
		}
	}
	for k, vals := range mcfg.Service_Values {
		if k == module {

			if dbpath, ok := vals[masterconfig.KEY_DB_FILEPATH]; ok {
				os.Rename(dbpath, fmt.Sprintf("%v_Copy%v.bak", dbpath, time.Now().Format(time.DateOnly)))
				os.Create(dbpath)
			}
		}

	}

	return nil
}

func promptMultipleSelection() ([]string, error) {
	var installTargets []string
	selectionOpts := []huh.Option[string]{}
	for _, service := range definitions.AppsList() {
		selectionOpts = append(selectionOpts,
			huh.NewOption(service, service).Selected(true),
		)
	}
	selection := huh.NewMultiSelect[string]().
		Options(
			selectionOpts...,
		).
		Title("Modules to be installed:").
		Value(&installTargets).WithTheme(huh.ThemeBase16())
	err := selection.Run()
	return installTargets, err
}

func maxLen(sl []string) int {
	ml := 0
	for _, s := range sl {
		if len(s) > ml {
			ml = len(s)
		}
	}
	return ml
}

func widened(text string, l int) string {
	for len(text) < l {
		text += " "
	}
	return text
}

func setPaths() {
	gopath = os.Getenv("GOPATH")
	if gopath == "" {
		panic("GOPATH enviroment variable is not set (or empty)")
	}
	gopath = strings.ReplaceAll(gopath, `\`, "/")
	configPath = masterconfig.Path()
	configPath = strings.ReplaceAll(configPath, `\`, "/")

}

func checkEdtsPaths() error {
	errors := []error{}

	//kval.Default(masterconfig.Path_TEXT_EDITOR, `c:\Windows\System32\notepad.exe`)
	//kval.Default(masterconfig.Path_MEDIA_PLAYER, `ffplay`)
	pathKeys := []string{
		masterconfig.Path_EDTS_IN,
		masterconfig.Path_EDTS_PROCESS,
		masterconfig.Path_EDTS_DONE,
		masterconfig.Path_EDTS_OUT,
		masterconfig.Path_EDTS_ARCHIVE,
	}
	for _, pathKey := range pathKeys {
		var path string
		val, comms, _, _ := kval.Info(pathKey)
		// if errK != nil {
		// 	return errK
		// }
		validated, _ := validatePath(val)
		for !validated {
			val, _ := enterValue(pathKey, comms[0])

			path = val
			kval.Set(pathKey, path)
			validated = true
			fmt.Println(pathKey, "добавлен как", path)
		}

		// if err != nil {
		// 	errors = append(errors, fmt.Errorf("failed to get %v: %v", pathKey, err))
		// 	comment := ""
		// 	switch pathKey {
		// 	case "edts-files-in":
		// 		comment = "directory where edts will search input source files"
		// 	case "edts-processing":
		// 		comment = "directory where edts will process source files to output files"
		// 	case "edts-done":
		// 		comment = "directory where edts will put source files after processing"
		// 	case "edts-files-out":
		// 		comment = "directory where edts will put output files after processing"
		// 	case "edts-archive":
		// 		comment = "directory where edts will send source files after project is closed"
		// 	}
		// 	kval.Set(pathKey, "[NO-VALUE-SET]", comment)
		// 	continue
		// }
		// f, errP := os.Stat(path)
		// if errP != nil {
		// 	errors = append(errors, fmt.Errorf("failed to approve %v: %v", path, errP))
		// 	continue
		// }
		// if !f.IsDir() {
		// 	errors = append(errors, fmt.Errorf("%v (%v) is not a directory", pathKey, path))
		// 	continue
		// }
	}
	return errorsCombined(errors...)
}

func errorsCombined(errs ...error) error {
	if len(errs) == 0 {
		return nil
	}
	errText := "edts global paths error:"
	for _, err := range errs {
		errText += fmt.Sprintf("\n  %v", err)
	}
	errText += fmt.Sprintf("\nglobal paths can be modified at %v", kval.DictionaryPath())
	return fmt.Errorf(errText)
}

func installKval() error {
	path := fmt.Sprintf("%v/src/github.com/Galdoba/edts/cmd/%v/", gopath, "edts-kval-utility")
	if err := os.Chdir(path); err != nil {
		fmt.Println("cd:", err)
		return err
	}
	//fmt.Print("cd", path)
	buildCommand := fmt.Sprintf("go install")
	if o, e, err := command.Execute(buildCommand); err != nil {
		fmt.Println("")
		fmt.Println("install error:", err)
		fmt.Println(o)
		fmt.Println(e)
		return err
	}
	if err := kval.Set("version", "0.0.1"); err != nil {
		panic(err.Error())
	}
	kval.Default("edts-files-in", "[NO_VALUE_SET]", "Директория где мы принимаем файлы")
	kval.Default("edts-processing", "[NO_VALUE_SET]", "Директория где идет просчет")
	kval.Default("edts-done", "[NO_VALUE_SET]", "Директория куда летят исходники после просчета")
	kval.Default("edts-files-out", "[NO_VALUE_SET]", "Корневая директория от которой растет путь для просчитанных файлов")
	kval.Default("edts-archive", "[NO_VALUE_SET]", "Корневая директория от которой растет путь архивации исходников по завершению работы")
	return nil
}

func enterValue(key, comment string) (string, error) {
	out := ""
	inp := huh.NewInput().Prompt(key + ": ").Placeholder("путь").Description(comment).Validate(validator).Value(&out)
	inp.Run()
	return out, nil

}

func validator(path string) error {
	_, err := validatePath(path)
	return err
}

func validatePath(path string) (bool, error) {
	f, errP := os.Stat(path)
	if errP != nil {
		return false, fmt.Errorf("path not found")
	}
	if !f.IsDir() {
		return false, fmt.Errorf("path is not directory")
	}
	return true, nil
}
