package commands

import (
	"fmt"
	"os"
	"slices"

	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/urfave/cli/v2"
)

func Stats() *cli.Command {
	return &cli.Command{
		Name:   "stats",                      //
		Usage:  "show stats for edts events", //
		Action: GetStats,                     //
		//Subcommands: []*cli.Command{{Name: "health", Usage: "edts config health", Action: ReadConfig}}, //

	}

}

func GetStats(c *cli.Context) error {
	//get edtsRootPat
	mscfg, err := masterconfig.Load(masterconfig.Path())
	if err != nil {
		return fmt.Errorf("failed to load master configuration")
	}
	eventDirs := make(map[string][]string)
	for _, paths := range mscfg.Service_Paths {
		for key, path := range paths {
			switch key {
			case masterconfig.KEY_INBOX, masterconfig.KEY_OUTBOX:
				eventDirs[key] = append(eventDirs[key], path)
			}
		}
	}
	es := EdtsStats{}
	es.eventsByPublisher = make(map[string]int)
	es.eventsByType = make(map[string]int)
	es.unresolvedEvents = make(map[string]int)
	eventsRead := 0
	for dirType, dirs := range eventDirs {
		for _, dir := range dirs {
			fi, err := os.ReadDir(dir)
			if err != nil {
				fmt.Println(err)
				continue
			}
			for _, f := range fi {
				path := dir + f.Name()
				evFields, err := events.Read(path)
				if err != nil {
					fmt.Println(err)
					continue
				}
				eventsRead++
				fmt.Printf("events read: %v\r", eventsRead)
				es.eventsByPublisher[evFields[events.Key_EventPublisher]]++
				es.eventsByType[evFields[events.Key_EventType]]++
				switch dirType {
				case masterconfig.KEY_INBOX:
					es.unresolvedEvents[events.Key_EventType]++
				}
			}
		}

	}
	//
	fmt.Println("")
	fmt.Println(es)
	// list events directories
	// count event files by type
	// count event files by sender
	return nil
}

type EdtsStats struct {
	eventsByType      map[string]int
	eventsByPublisher map[string]int
	unresolvedEvents  map[string]int
}

func (es EdtsStats) String() string {
	s := "edts stats:\n"
	s += fmt.Sprintf(" total events: %v\n", summap(es.eventsByType))
	s += " events by type:\n"
	for _, line := range mapSorted(es.eventsByType) {
		s += line + "\n"
	}
	s += " events by publisher:\n"
	for _, line := range mapSorted(es.eventsByPublisher) {
		s += line + "\n"
	}
	s += " events unresolved:\n"
	for _, line := range mapSorted(es.unresolvedEvents) {
		s += line + "\n"
	}

	return s
}

func mapSorted[T any](origin map[string]T) []string {
	keys := []string{}
	for k := range origin {
		keys = append(keys, k)
	}
	slices.Sort(keys)
	out := []string{}
	for _, k := range keys {
		out = append(out, fmt.Sprintf("  %v: %v", k, origin[k]))
	}
	return out
}

func summap(origin map[string]int) int {
	s := 0
	for _, v := range origin {
		s += v
	}
	return s
}
