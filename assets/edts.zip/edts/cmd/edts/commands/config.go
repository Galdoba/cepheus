package commands

import (
	"fmt"
	"os"
	"time"

	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/urfave/cli/v2"
)

func Config() *cli.Command {
	return &cli.Command{
		Name:        "config",                                                                          //
		Usage:       "upper level command",                                                             //
		Action:      NewConfig,                                                                         //
		Subcommands: []*cli.Command{{Name: "health", Usage: "edts config health", Action: ReadConfig}}, //

	}

}

func NewConfig(c *cli.Context) error {
	path := masterconfig.Path(c.String("config_preset"))
	os.Rename(path, fmt.Sprintf("%v_%v.bak", path, time.Now().Unix()))
	cfg := masterconfig.New(path)
	masterconfig.Save(cfg, path)
	fmt.Println("new config created at", path)

	return nil
}

func ReadConfig(c *cli.Context) error {
	path := masterconfig.Path()
	fmt.Println("reading", path)
	_, err := masterconfig.Read()
	if err != nil {
		return err
	}
	fmt.Println("config file is readable")
	return nil
}
