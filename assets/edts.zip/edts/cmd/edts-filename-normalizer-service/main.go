package main

/*
обновляем списки содержимого в заданных директориях
отсылаем брокеру эвенты с изменениями
все пути в конфигах
своих логов нет?
*/
import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/cmd/edts-filename-normalizer-service/commands"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/setup"
	"github.com/urfave/cli/v2"
)

func main() {
	appName := definitions.SERVICE_FILENAME_NORMALIZER
	app := cli.NewApp()
	app.Name = appName
	app.Usage = "normalise names in selected directories"
	setup.EDTS_Service(app)
	app.Commands = []*cli.Command{
		commands.Run(),
	}
	args := os.Args
	if err := app.Run(args); err != nil {
		errOut := fmt.Sprintf("error: %v: %v", app.Name, err.Error())
		println(errOut)
		os.Exit(1)
	}
}
