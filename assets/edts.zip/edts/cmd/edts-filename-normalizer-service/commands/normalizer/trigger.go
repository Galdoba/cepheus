package normalizer

import (
	"strings"
)

type Trigger struct {
	Filename string `json:"filename"`
}

func Run(str string) string {
	out := ""
	for _, letter := range letters(str) {
		out += replaceLetter(letter)
	}
	out = strings.Join(strings.Fields(out), "_")
	return out
}

func letters(text string) []string {
	return strings.Split(text, "")
}

func replaceLetter(s string) string {
	switch s {
	default:
		return " "
	case ".", "_", "-",
		"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
		"a", "b", "c", "d", "e", "f", "g", "h", "i", "j",
		"k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
		"u", "v", "w", "x", "y", "z",
		"A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
		"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
		"U", "V", "W", "X", "Y", "Z":
		return s
	case "а", "б", "в",
		"г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л",
		"м", "н", "о", "п", "р", "с", "т", "у", "ф", "х",
		"ц", "ч", "ш", "щ", "ъ", "ы", "ь", "э", "ю", "я",
		"А", "Б", "В",
		"Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л",
		"М", "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х",
		"Ц", "Ч", "Ш", "Щ", "Ъ", "Ы", "Ь", "Э", "Ю", "Я":
		return letterTranslationMap[s]
	}
}

var letterTranslationMap = map[string]string{
	"а": "a",
	"б": "b",
	"в": "v",
	"г": "g",
	"д": "d",
	"е": "e",
	"ё": "e",
	"ж": "zh",
	"з": "z",
	"и": "i",
	"й": "y",
	"к": "k",
	"л": "l",
	"м": "m",
	"н": "n",
	"о": "o",
	"п": "p",
	"р": "r",
	"с": "s",
	"т": "t",
	"у": "u",
	"ф": "f",
	"х": "h",
	"ц": "c",
	"ч": "ch",
	"ш": "sh",
	"щ": "sh",
	"ъ": "",
	"ы": "y",
	"ь": "",
	"э": "e",
	"ю": "yu",
	"я": "ya",
	"А": "A",
	"Б": "B",
	"В": "V",
	"Г": "G",
	"Д": "D",
	"Е": "E",
	"Ё": "E",
	"Ж": "Zh",
	"З": "Z",
	"И": "I",
	"Й": "Y",
	"К": "K",
	"Л": "L",
	"М": "M",
	"Н": "N",
	"О": "O",
	"П": "P",
	"Р": "R",
	"С": "S",
	"Т": "T",
	"У": "U",
	"Ф": "F",
	"Х": "H",
	"Ц": "C",
	"Ч": "Ch",
	"Ш": "Sh",
	"Щ": "Sh",
	"Ъ": "",
	"Ы": "Y",
	"Ь": "",
	"Э": "E",
	"Ю": "Yu",
	"Я": "Ya",
}
