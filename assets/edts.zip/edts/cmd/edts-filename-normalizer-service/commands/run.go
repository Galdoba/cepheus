package commands

import (
	"errors"
	"fmt"
	"os"
	"time"

	"github.com/Galdoba/edts/cmd/edts-filename-normalizer-service/commands/normalizer"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/internal/service"
	"github.com/Galdoba/edts/pkg/action"
	"github.com/Galdoba/edts/pkg/atempted"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
	"github.com/urfave/cli/v2"
)

var srv *service.Service

var normalize_filename = "normalize_filename"

func Run() *cli.Command {
	return &cli.Command{
		Name:      "run",
		Aliases:   []string{},
		Usage:     "normalize names for new names",
		UsageText: fmt.Sprintf("%v run", definitions.SERVICE_FILENAME_NORMALIZER),
		Description: "Service will change filenames of all files in directories to production-valid ones.\n" +
			"Any changes in files are treated as Out Event",
		Args:      false,
		ArgsUsage: "Args Usage Text",
		Category:  "",
		Before: func(c *cli.Context) error {

			return nil
		},
		Action: func(c *cli.Context) error {
			//INIT
			appName := c.App.Name
			cfg, err := masterconfig.Read()
			if err != nil {
				return fmt.Errorf("service initialisation failed: %v\n", err)
			}
			if err := loadConfiguration(cfg, appName); err != nil {
				return fmt.Errorf("service config initialisation failed: %v\n", err)
			}

			atempted.SetMaxAtempts(config.maxRetryAtempts)
			atempted.SetDelay(time.Millisecond * time.Duration(config.delay))
			events.Subscribtions(appName)
			events.SetupPublisher(c.App.Name, config.outbox)
			//START
			if err := events.PublishNewEvent(events.MODULE_STARTED); err != nil {
				fmt.Fprintf(os.Stderr, "%v----\n", err)
			}

			serviceAction := action.New(normalize_filename, normalize)
			serviceAction.EnrichWith(
				action.Triggers([]string{events.FILE_CREATED}),
				//action.Cooldown(float64(config.cooldown)),
			)

			srv = service.New(c.App.Name,
				serviceAction,
				service.WithConfig(cfg),
			)
			if err := srv.AddReaction(normalize_filename, serviceAction); err != nil {
				return err
			}
			return srv.Run()

		},

		Flags: []cli.Flag{},
	}
}

type RenameProcess struct {
	Directory   string `json:"directory"`
	OldFilename string `json:"filename"`
	Normalized  string `json:"new filename"`
}

func normalize(args ...interface{}) error {
	if len(args) != 0 {
		return fmt.Errorf("action does not expect arguments")
	}
	return normalizeFilename()
}

/**/
func normalizeFilename() error {
	normAct := srv.ReactionActions[normalize_filename]
	if normAct == nil {
		return fmt.Errorf("no reaction for '%v'", "normalize_filename")
	}
	ev := normAct.TriggerEvent
	if ev == nil {
		fmt.Printf("no trigger event\r")
		time.Sleep(time.Duration(normAct.Cooldown_Seconds))
		return nil
	} else {
		fmt.Println("trigger event:", ev.Type())

	}

	switch ev.Type() {
	default:
		fmt.Println("ignore event", events.Filename(ev))
		return nil
	case events.FILE_CREATED:
		eventData := ev.Disassemble()
		originalName := eventData[payload.NAME]
		sourceDir := eventData[payload.DIRECTORY]
		// fev, err := structured.ReadFileEvent(config.inbox + events.Filename(ev))
		// if err != nil {
		// 	return fmt.Errorf("failed to read event: %v", err)
		// }
		// if fev == nil {
		// 	fmt.Printf("ignore event %v: event file absent\n", events.Filename(ev))
		// 	return service.ErrIgnore
		// }
		norm := normalizer.Run(originalName)
		if norm == originalName {
			fmt.Println("ignore event", events.Filename(ev), "(name normal)")
			//os.Remove(srv.Inbox + events.Filename(ev))
			return nil
		}
		dir := ""
		for _, dr := range config.trackedDirs {
			if dr == sourceDir {
				dir = dr
				break
			}
		}
		if dir == "" {
			fmt.Printf("ignore event %v: source file does not in target dir\n", events.Filename(ev))
			return nil
		}
		rp := RenameProcess{}
		rp.Directory = dir
		rp.Normalized = norm
		rp.OldFilename = originalName
		exist, errExist := checkFileExist(dir + originalName)
		if errExist != nil {
			return fmt.Errorf("FAILED event '%v' processing: file exist confirmation failed: %v", events.Filename(ev), errExist)
		}
		if !exist {
			fmt.Printf("ignore event %v: source file does not exist\n", events.Filename(ev))
			return nil
		}

		if err := atempted.Rename(dir+originalName, dir+norm); err != nil {
			return fmt.Errorf("FAILED event '%v' processing: %v", events.Filename(ev), err)
		}
		if err := events.PublishNewEvent(events.FILENAME_NORMALIZED,
			// payload.OldFilename(rp.OldFilename),
			// payload.NewFilename(rp.Normalized),
			// payload.Directory(rp.Directory),
			payload.String(payload.FROM_VALUE, rp.OldFilename),
			payload.String(payload.TO_VALUE, rp.Normalized),
			payload.String(payload.DIRECTORY, rp.Directory),
		); err != nil {
			return fmt.Errorf("FAILED event '%v' publshing: %v", events.Filename(ev), err)
		}
	}

	return nil
}

func checkFileExist(path string) (bool, error) {
	if _, err := os.Stat(path); err == nil {
		return true, nil
	} else if errors.Is(err, os.ErrNotExist) {
		return false, nil
	} else {
		return false, err
	}
}

type serviceConfiguration struct {
	trackedDirs     []string
	maxRetryAtempts int
	delay           int
	inbox           string
	outbox          string
	cooldown        int
}

var config *serviceConfiguration

func loadConfiguration(mcfg *masterconfig.MasterConfig, app string) error {
	config = &serviceConfiguration{}
	for _, dir := range mcfg.Service_TrackDirectories[app] {

		config.trackedDirs = append(config.trackedDirs, dir)
	}
	config.maxRetryAtempts = mcfg.Service_RetryAttempts[app]
	config.delay = mcfg.Service_RetryDelay_Milliseconds[app]
	config.inbox = mcfg.Service_Paths[app][masterconfig.KEY_INBOX]
	config.outbox = mcfg.Service_Paths[app][masterconfig.KEY_OUTBOX]
	config.cooldown = mcfg.Service_Cooldown[app]
	return nil
}
