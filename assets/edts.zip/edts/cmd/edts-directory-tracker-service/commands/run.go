package commands

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/internal/service"
	"github.com/Galdoba/edts/internal/structs/filedata"
	"github.com/Galdoba/edts/pkg/action"
	"github.com/Galdoba/edts/pkg/atempted"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
	"github.com/urfave/cli/v2"
)

const (
// listFile = "list.dts"
)

var database *db.Database

func Run() *cli.Command {
	return &cli.Command{
		Name:      "run",
		Aliases:   []string{},
		Usage:     "track directories",
		UsageText: fmt.Sprintf("%v run", definitions.SERVICE_DIRECTORY_TRACKER),
		Description: "Service will keep track of designated directories content, collect information and store it in service storage in storage.\n" +
			"Any changes in files are treated as Out Event",
		Args:      false,
		ArgsUsage: "Args Usage Text",
		Category:  "",
		Before: func(c *cli.Context) error {

			return nil
		},
		Action: func(c *cli.Context) error {

			cfg, err := masterconfig.Read()
			if err != nil {
				return err
			}
			if err := loadConfiguration(cfg, c.App.Name); err != nil {
				return err
			}
			atempted.SetMaxAtempts(config.maxRetryAtempts)
			atempted.SetDelay(time.Millisecond * time.Duration(config.delay))
			// events.SetOutbox(config.outbox)
			events.SetupPublisher(c.App.Name, config.outbox)
			if err := events.PublishNewEvent(events.MODULE_STARTED); err != nil {
				fmt.Fprintf(os.Stderr, "%v\n", err)
			}
			database = db.Create(config.storageFile, "directory")

			updateAction := action.New("update_directory", updateStorageAction)
			updateAction.EnrichWith(
				action.Cooldown(float64(config.cooldown)),
				action.Triggers([]string{events.FILENAME_NORMALIZED}),
				//action.WithArg("update_directory"+"_"+action.Cooldown_Argument+"0", cfg),
				//action.WithArg("update_directory"+"_"+action.Trigger_Argument+"0", cfg),
			)
			srv := service.New(c.App.Name,
				updateAction,
				service.WithReactiveAction(events.FILENAME_NORMALIZED, updateAction),
				service.WithConfig(cfg),
			)
			fmt.Println("service started")
			return srv.Run()

		},

		Flags: []cli.Flag{},
	}
}

func readDirectories() (map[string]*filedata.Filedata, error) {
	//result := []*filedata.Filedata{}
	res := make(map[string]*filedata.Filedata)

	for _, dir := range config.trackedDirs {
		fi, err := atempted.ReadDir(dir)
		if err != nil {
			return nil, fmt.Errorf("failed to read directories: %v", err)
		}
		for _, f := range fi {
			if f.IsDir() {
				continue
			}
			key := dir + f.Name()
			//fd := filedata.New(key)
			//		result = append(result, fd)
			res[key] = filedata.New(key)
		}
	}
	return res, nil
}

func updateStorageAction(args ...interface{}) error {
	if len(args) != 0 {
		return fmt.Errorf("action expect no arguments")
	}
	return updateStorage()
}

func updateStorage() error {
	//READ STORAGE
	db_actual := database
	db_actual, err := database.LoadCopyFromFile()
	if err != nil {

		return err
	}
	inStorage := make(map[string]*filedata.Filedata)
	for k := range db_actual.Payload {

		fd := &filedata.Filedata{}
		if err := db_actual.ReadStruct(k, fd); err != nil {

			panic(err.Error())
		}
		inStorage[k] = fd
	}

	//READ FILES
	inDirectoiries, err := readDirectories()
	if err != nil {
		return err
	}
	//COMPARE
	diff := compareReadResults(inStorage, inDirectoiries)
	if diff.changes == 0 {
		return nil
	}
	for k := range diff.deletedFiles {
		fmt.Println("deleted", k)
		db_actual.Delete(k)
	}
	for k, v := range diff.createdFiles {
		fmt.Println("created", k)
		db_actual.Update(k, v)
	}
	//SPAWN EVENTS
	if err = spawnEvents(diff); err != nil {
		return err
	}
	//WRITE TO FILE
	if err := db_actual.Save(); err != nil {
		return err
	}
	database = db_actual
	return nil
}

func fromEntry(entr db.Entry) (*filedata.Filedata, error) {
	bt, err := json.Marshal(entr)
	if err != nil {
		return nil, err
	}
	dtf := filedata.Filedata{}
	if err := json.Unmarshal(bt, &dtf); err != nil {
		return nil, err
	}
	return &dtf, nil
}

func spawnEvents(diff differenceInfo) error {
	//diff := compareReadResults(inStorage, inDirectoiries)
	requests := []spawnerRequests{}
	//SPAWN EVENTS
	for _, data := range diff.deletedFiles {
		// concrete, err := fromEntry(data)
		// if err != nil {
		// 	return err
		// }
		//requests = append(requests, spawnerRequests{events.FILE_REMOVED, concrete.Directory, concrete.Name})
		requests = append(requests, spawnerRequests{events.FILE_REMOVED, data.Directory, data.Name})
	}
	for _, data := range diff.createdFiles {
		// concrete, err := fromEntry(data)
		// if err != nil {
		// 	return err
		// }
		// if concrete.IsDir {
		// 	continue
		// }
		// requests = append(requests, spawnerRequests{events.FILE_CREATED, concrete.Directory, concrete.Name})
		requests = append(requests, spawnerRequests{events.FILE_CREATED, data.Directory, data.Name})
	}

	for _, request := range requests {
		dir := strings.ReplaceAll(request.dir, `\`, "/")
		err := events.PublishNewEvent(request.evType,
			payload.String(payload.DIRECTORY, dir),
			payload.String(payload.NAME, request.name),
		)
		if err != nil {
			fmt.Println("failed", request, "with err:", err)
			return fmt.Errorf("failed %v with err: %v", request, err)
		}
	}
	return nil
}

type spawnerRequests struct {
	evType string
	dir    string
	name   string
}

type serviceConfiguration struct {
	trackedDirs     []string
	storageFile     string
	maxRetryAtempts int
	delay           int
	inbox           string
	outbox          string
	cooldown        int
}

var config *serviceConfiguration

func loadConfiguration(mcfg *masterconfig.MasterConfig, app string) error {
	config = &serviceConfiguration{}
	config.storageFile = mcfg.Service_Values[app][masterconfig.KEY_DB_FILEPATH]
	for _, dir := range mcfg.Service_TrackDirectories[app] {
		config.trackedDirs = append(config.trackedDirs, dir)
	}
	config.maxRetryAtempts = mcfg.Service_RetryAttempts[app]
	config.delay = mcfg.Service_RetryDelay_Milliseconds[app]
	config.inbox = mcfg.Service_Paths[app][masterconfig.KEY_INBOX]
	config.outbox = mcfg.Service_Paths[app][masterconfig.KEY_OUTBOX]
	config.cooldown = mcfg.Service_Cooldown[app]
	return nil
}

type differenceInfo struct {
	deletedFiles map[string]*filedata.Filedata
	createdFiles map[string]*filedata.Filedata
	changes      int
}

func compareReadResults(inStorage, inDirectoiries map[string]*filedata.Filedata) differenceInfo {
	diff := differenceInfo{}
	diff.deletedFiles = make(map[string]*filedata.Filedata)
	diff.createdFiles = make(map[string]*filedata.Filedata)
	for path, val := range inStorage {
		if _, found := inDirectoiries[path]; !found {
			//diff.deletedFiles = append(diff.deletedFiles, val)

			diff.deletedFiles[path] = val
			diff.changes++
		}
	}
	for path, val := range inDirectoiries {
		if _, stored := inStorage[path]; !stored {
			diff.createdFiles[path] = val
			diff.changes++
		}
	}

	return diff
}
