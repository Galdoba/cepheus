package main

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/cmd/edts-event-manager/commands"
	"github.com/Galdoba/edts/cmd/edts-event-manager/commands/procedure"
	"github.com/Galdoba/edts/cmd/edts-event-manager/global"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/urfave/cli/v2"
)

func main() {
	appName := definitions.UTILITY_EVENT_MANAGER
	app := cli.NewApp()
	app.Name = appName
	app.Version = "Major.Minor.Patch:BuildDate-Qualificator [Build X]"
	app.Usage = "Tool to manage edts-events using tui or cli style, with support of bubbletea models."
	app.Description = "This is a long description."
	//app.CustomAppHelpTemplate = "this is a help screen"
	app.Commands = []*cli.Command{
		procedure.Dummy(),
		procedure.Print(),
		commands.Spawn(),
	}
	app.Flags = []cli.Flag{
		&cli.BoolFlag{
			Name:    global.FlagVerbose,
			Usage:   "print logs",
			Aliases: []string{"vb"},
		},
	}

	args := os.Args
	if err := app.Run(args); err != nil {
		errOut := fmt.Sprintf("error: %v: %v", app.Name, err.Error())
		println(errOut)
		os.Exit(1)
	}
}
