package procedure

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/render"
	"github.com/urfave/cli/v2"
)

const (
	flag_files_only = "files_only"
	flag_recursive  = "recursive"
	flag_color      = "color"
)

func Print() *cli.Command {
	return &cli.Command{
		Name:        "print",
		Aliases:     []string{},
		Usage:       "Print edts-event's content in various forms",
		UsageText:   "edts-event-manager [global options] print [options] [event_file paths]",
		Description: "This is CLI-type command, than takes commands options and args. It renders event content based on options chosen and write it selected writer(s). Program exits after printing.",
		Args:        true,
		ArgsUsage:   "Template Args Usage",
		Category:    "CLI",
		BashComplete: func(*cli.Context) {
		},
		Before: func(*cli.Context) error {
			return nil
		},
		After: func(*cli.Context) error {
			return nil
		},
		Action: func(c *cli.Context) error {
			allEvents := []events.Event{}
			////read args
			args := c.Args().Slice()
			switch len(args) {
			case 0:
				fmt.Fprintf(os.Stderr, "%v\n", "no arguments provided")
				return nil
			default:
				for _, arg := range args {
					argEvents, err := readArgument(c, arg)
					logError(c, err)
					allEvents = append(allEvents, argEvents...)
				}
			}
			////print
			switch len(allEvents) {
			case 0:
				fmt.Fprintf(os.Stderr, "%v\n", "no event files found")
				return nil
			default:
				for _, event := range allEvents {
					fmt.Println(render.Render(event))
				}
			}

			return nil
		},
		OnUsageError: func(cCtx *cli.Context, err error, isSubcommand bool) error {
			return nil
		},
		Subcommands: []*cli.Command{},
		Flags: []cli.Flag{
			&cli.BoolFlag{
				Name:    flag_color,
				Usage:   "render events with color",
				Aliases: []string{"c"},
			},
			&cli.BoolFlag{
				Name:    flag_recursive,
				Usage:   "read events in subdirectories if argument is a directory",
				Aliases: []string{"r"},
			},
			&cli.BoolFlag{
				Name:    flag_files_only,
				Usage:   "skip directories",
				Aliases: []string{"fo"},
			},
		},
		SkipFlagParsing:        false,
		HideHelp:               false,
		HideHelpCommand:        false,
		Hidden:                 false,
		UseShortOptionHandling: false,
		HelpName:               "",
		CustomHelpTemplate:     "",
	}
}

func readEvent(path string) (events.Event, error) {
	ev, err := events.Assemble(path)
	if err != nil {
		return nil, err
	}

	return ev, err
}

func readArgument(c *cli.Context, arg string) ([]events.Event, error) {
	events := []events.Event{}
	argInfo, err := os.Stat(arg)
	if err != nil {
		return nil, err
	}
	switch argInfo.IsDir() {
	case false:
		logAction(c, fmt.Sprintf("read as file: %v", arg))
		ev, err := readAsFile(arg)
		if err != nil {
			return nil, err
		}
		events = append(events, ev...)
	case true:
		if c.Bool(flag_files_only) {
			return nil, fmt.Errorf("%v is directory: skip (forbidden by options)", arg)
		}
		logAction(c, fmt.Sprintf("read as directory: %v", arg))
		inside, err := readAsDir(arg, c.Bool(flag_recursive))
		logError(c, err)
		if len(inside) > 0 {
			events = append(events, inside...)
		}
	}
	return events, nil
}

func readAsFile(path string) ([]events.Event, error) {

	ev, err := events.Assemble(path)
	if err != nil {
		return nil, err
	}
	return []events.Event{ev}, nil
}

func readAsDir(dir string, recursive bool) ([]events.Event, error) {
	events := []events.Event{}
	fi, err := os.ReadDir(dir)
	if err != nil {
		return events, err
	}
	for _, f := range fi {
		switch f.IsDir() {
		case true:
			if recursive {
				inside, err := readAsDir(dir+string(filepath.Separator)+f.Name(), recursive)
				if err != nil {
					return nil, err
				}
				events = append(events, inside...)
			}
		case false:
			ev, err := readAsFile(dir + string(filepath.Separator) + f.Name())
			if err != nil {
				return nil, err
			}
			events = append(events, ev...)
		}
	}
	return events, nil
}

/*
dirs
files

*/
