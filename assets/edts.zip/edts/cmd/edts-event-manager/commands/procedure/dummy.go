package procedure

import (
	"fmt"

	"github.com/urfave/cli/v2"
)

func Dummy() *cli.Command {
	return &cli.Command{
		Name:        "dummy",
		Aliases:     []string{},
		Usage:       "Template Usage",
		UsageText:   "Template Usage Text",
		Description: "Template Description",
		Args:        false,
		ArgsUsage:   "Template Args Usage",
		Category:    "DUMMY",
		BashComplete: func(*cli.Context) {
		},
		Before: func(*cli.Context) error {
			return nil
		},
		After: func(*cli.Context) error {
			return nil
		},
		Action: func(c *cli.Context) error {
			fmt.Printf("this is %v command\n", c.Command.Name)
			return nil
		},
		OnUsageError: func(cCtx *cli.Context, err error, isSubcommand bool) error {
			return nil
		},
		Subcommands:            []*cli.Command{},
		Flags:                  []cli.Flag{},
		SkipFlagParsing:        false,
		HideHelp:               false,
		HideHelpCommand:        false,
		Hidden:                 false,
		UseShortOptionHandling: true,
		HelpName:               "",
		CustomHelpTemplate:     "",
	}
}
