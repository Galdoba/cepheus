package procedure

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/cmd/edts-event-manager/global"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/urfave/cli/v2"
)

func logError(c *cli.Context, err error) {
	if err == nil {
		return
	}
	if !c.Bool(global.FlagVerbose) {
		return
	}
	fmt.Fprintf(os.Stderr, "error: %v\n", err)
}

func logAction(c *cli.Context, action string) {
	if !c.Bool(global.FlagVerbose) {
		return
	}
	fmt.Fprintf(os.Stderr, "action: %v\n", action)
}

func collectFromDirectory(dir string) []events.Event {
	events := []events.Event{}
	return events
}
