package commands

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/Galdoba/edts/pkg/events"
	"github.com/urfave/cli/v2"
)

const (
	category_output         = "output"
	category_event          = "event"
	flag_bool_print         = "print"
	flag_bool_no_write      = "no_write"
	flag_string_destination = "destination"
	flag_string_author      = "author"
	flag_string_type        = "type"
	flag_string_payload     = "payload"
)

func Spawn() *cli.Command {
	return &cli.Command{
		Name:        "spawn",
		Aliases:     []string{},
		Usage:       "Spawn new edts-event",
		UsageText:   "edts-event-utility [global options] spawn [command options]",
		Description: "",
		Args:        false,
		ArgsUsage:   "",
		Category:    "",
		Action: func(c *cli.Context) error {
			//preapare event
			time := time.Now()
			eventType := events.CustomType(c.String(flag_string_type))
			payload, err := parsePayload(c.String(flag_string_payload))
			if err != nil {
				return fmt.Errorf("spawn failed: %v", err)
			}
			event := events.Construct(eventType, time, c.String(flag_string_author), payload)

			//print event
			switch c.Bool(flag_bool_print) {
			case false:
			case true:
				bt, err := json.MarshalIndent(&event, "", "  ")
				if err != nil {
					return fmt.Errorf("spawn failed: %v", err)
				}
				fmt.Fprintf(os.Stdout, "%v", string(bt))
			}

			//write to file
			switch c.Bool(flag_bool_no_write) {
			case true:
			case false:
				bt, err := json.Marshal(&event)
				if err != nil {
					return fmt.Errorf("spawn failed: %v", err)
				}
				filename := events.FileName(event)
				dir, err := directory(c.String(flag_string_destination))
				if err != nil {
					return fmt.Errorf("spawn failed: %v", err)
				}
				if err := os.WriteFile(dir+filename, bt, 0666); err != nil {
					return fmt.Errorf("spawn failed: %v", err)
				}

			}
			return nil
		},
		Subcommands: []*cli.Command{},
		Flags: []cli.Flag{
			&cli.BoolFlag{
				Name:        flag_bool_print,
				Category:    category_output,
				DefaultText: "",
				FilePath:    "",
				Usage:       "show event content to stdout",
				Aliases:     []string{"p"},
			},
			&cli.BoolFlag{
				Name:        flag_bool_no_write,
				Category:    category_output,
				DefaultText: "",
				FilePath:    "",
				Usage:       "do not write event to file",
				Aliases:     []string{"nw"},
			},
			&cli.StringFlag{
				Name:        flag_string_destination,
				Category:    category_output,
				DefaultText: "current directory",
				Usage:       "directory to write event file to",
				Value:       "./",
				Aliases:     []string{"d"},
			},
			&cli.StringFlag{
				Name:        flag_string_author,
				Category:    category_event,
				DefaultText: "edts-event-utility",
				Usage:       "set publisher",
				Value:       "edts-event-utility",
				Aliases:     []string{"a"},
			},
			&cli.StringFlag{
				Name:     flag_string_type,
				Category: category_event,
				FilePath: "",
				Usage:    "set event type (required option)",
				Required: true,
				Aliases:  []string{"t"},
			},
			&cli.StringFlag{
				Name:        "payload",
				Category:    category_event,
				DefaultText: "",
				FilePath:    "",
				Usage:       "set custom payload data (format: 'key1':='val1';'key2':='val2';...;'keyN':='valN')",
				Required:    false,
				Hidden:      false,
				HasBeenSet:  false,
				Aliases:     []string{},
				EnvVars:     []string{},
				TakesFile:   false,
			},
		},
		SkipFlagParsing:        false,
		HideHelp:               false,
		HideHelpCommand:        false,
		Hidden:                 false,
		UseShortOptionHandling: false,
		HelpName:               "",
		CustomHelpTemplate:     "",
	}
}

/*
	bool
no write
print
	string
dir    -  where will write file
author -  who spawned event
	[]string
payload -  set event payload

*/

func parsePayload(flag_value string) (map[string]string, error) {
	if flag_value == "" {
		return nil, nil
	}
	if !strings.HasPrefix(flag_value, "'") {
		return nil, fmt.Errorf("invalid payload formatting: \n  %v", flag_value)
	}
	if !strings.HasSuffix(flag_value, "'") {
		return nil, fmt.Errorf("invalid payload formatting: \n  %v", flag_value)
	}
	raw := strings.TrimPrefix(flag_value, "'")
	raw = strings.TrimSuffix(raw, "'")
	if raw == "" {
		return make(map[string]string), nil
	}

	vals := make(map[string]string)
	pairs := strings.Split(raw, "';'")
	for i, pair := range pairs {
		kv := strings.Split(pair, "':='")
		if len(kv) != 2 {
			return nil, fmt.Errorf("invalid payload formating: pair %v:\n  %v", i, pair)
		}
		vals[kv[0]] = kv[1]
	}
	return vals, nil
}

func directory(flag_directory string) (string, error) {
	dir := ""
	switch flag_directory {
	case "./":
		ex, err := os.Getwd()
		if err != nil {
			return "", fmt.Errorf("directory detection failed")
		}
		dir = ex + string(filepath.Separator)
	default:
		fi, err := os.Stat(flag_directory)
		if err != nil {
			return "", fmt.Errorf("directory confirmation failed: %v")
		}
		if fi.IsDir() == false {
			return "", fmt.Errorf("'%v' is not a directory", flag_directory)
		}
		dir = flag_directory
	}
	return dir, nil
}
