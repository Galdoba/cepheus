package global

const (
	FlagVerbose  = "verbose"
	FlagLoglevel = "loglevel"
	LevelDebug   = "debug"
	LevelInfo    = "info"
	LevelError   = "error"
	LevelFatal   = "fatal"
)
