package model

type ScriptData struct {
	Type string
}
