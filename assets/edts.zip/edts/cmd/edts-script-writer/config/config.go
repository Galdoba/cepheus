package config

type ScriptWriterConfiguration struct {
	SourceDir    string
	StorageDir   string
	ExecutionDir string
	Inbox        string
	Outbox       string
}
