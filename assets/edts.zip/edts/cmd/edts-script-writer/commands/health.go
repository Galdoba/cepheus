package commands

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/urfave/cli/v2"
)

const (
// listFile = "list.dts"
)

func Health() *cli.Command {
	return &cli.Command{
		Name:        "health",
		Aliases:     []string{},
		Usage:       "check script writer's infrastructure",
		UsageText:   fmt.Sprintf("%v health", definitions.UTILITY_SCRIPT_WRITER),
		Description: "report status of script writer tool",
		Args:        false,
		ArgsUsage:   "Args Usage Text",
		Category:    "",
		Before: func(c *cli.Context) error {
			return initConfig(c)
		},
		Action: func(c *cli.Context) error {
			dirs := []string{"exec directory", "storage directory", "inbox", "outbox", "source directory"}
			path := make(map[string]string)
			path[dirs[0]] = cfg.ExecutionDir
			path[dirs[1]] = cfg.StorageDir
			path[dirs[2]] = cfg.Inbox
			path[dirs[3]] = cfg.Outbox
			path[dirs[4]] = cfg.SourceDir
			for _, dirType := range dirs {
				fmt.Println(dirType)
				f, err := os.Stat(path[dirType])
				switch err {
				case nil:
					switch f.IsDir() {
					case true:
						fmt.Println(path[dirType])
					case false:
						fmt.Printf("error: %v is not a directory\n", path[dirType])
					}
				default:
					fmt.Printf("error: %v", err)
				}
			}
			return nil
		},

		Flags: []cli.Flag{},
	}
}
