package commands

import (
	"fmt"

	"github.com/Galdoba/edts/cmd/edts-script-writer/config"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/urfave/cli/v2"
)

var cfg = config.ScriptWriterConfiguration{}

func initConfig(c *cli.Context) error {
	master, err := masterconfig.Read()
	if err != nil {
		return fmt.Errorf("failed to init config: %v", err)
	}
	cfg.ExecutionDir = master.Service_Values[c.App.Name][masterconfig.KEY_EXEC_DIR]
	cfg.SourceDir = master.Service_Values[c.App.Name][masterconfig.KEY_SOURCE_DIR]
	cfg.StorageDir = master.Service_Paths[c.App.Name][masterconfig.KEY_STORAGE]
	cfg.Inbox = master.Service_Paths[c.App.Name][masterconfig.KEY_INBOX]
	cfg.Outbox = master.Service_Paths[c.App.Name][masterconfig.KEY_OUTBOX]
	return nil
}
