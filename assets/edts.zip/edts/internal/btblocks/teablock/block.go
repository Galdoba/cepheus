package teablock

import (
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

const (
	DefaultHorisontalTrimmer = "…"
	DefaultVerticalTrimmer   = "↓"
	NoTrimmer                = ""
)

var DefaultStyle = lipgloss.NewStyle().
	Border(lipgloss.NormalBorder(), true).
	BorderForeground(lipgloss.Color("7"))

type Block struct {
	width          int
	height         int
	contentWidth   int
	contentHeight  int
	trimHorisontal string
	trimVertical   string
	inFocus        bool
	TeaModel       tea.Model
	Style          lipgloss.Style
}

func Confine(model tea.Model, width, height int, blockOptions ...BlockOption) *Block {
	bl := defaultBlock()
	for _, modify := range blockOptions {
		modify(&bl)
	}
	bl.width = width
	bl.height = height
	bl.TeaModel = model
	bl.contentWidth = bl.width - bl.Style.GetBorderLeftSize() - bl.Style.GetBorderRightSize()
	bl.contentHeight = bl.height - bl.Style.GetBorderTopSize() - bl.Style.GetBorderBottomSize()
	bl.Style = bl.Style.Width(bl.contentWidth).Height(bl.contentHeight)
	return &bl
}

func (bl *Block) Focus() {
	bl.inFocus = true
}

func (bl *Block) Blur() {
	bl.inFocus = false
}

type BlockOption func(*Block)

func WithTrimmers(horisontal, vertical string) BlockOption {
	return func(b *Block) {
		b.trimHorisontal = horisontal
		b.trimVertical = vertical
	}
}

func WithStyle(style lipgloss.Style) BlockOption {
	return func(b *Block) {
		b.Style = style
	}
}

func WithFocus(focus bool) BlockOption {
	return func(b *Block) {
		b.inFocus = focus
	}
}

func defaultBlock() Block {
	bl := Block{}
	bl.Style = DefaultStyle
	bl.trimHorisontal = DefaultHorisontalTrimmer
	bl.trimVertical = DefaultVerticalTrimmer
	bl.inFocus = true
	return bl
}
