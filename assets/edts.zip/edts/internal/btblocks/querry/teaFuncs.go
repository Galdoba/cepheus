package querry

import (
	"fmt"

	tea "github.com/charmbracelet/bubbletea"
)

func (qm *QuerryModel) Init() tea.Cmd {
	return nil
}

type SubmitMsg struct {
	Submitted bool
}

func Submit() tea.Cmd {
	return func() tea.Msg {
		return SubmitMsg{true}
	}
}

func (qm *QuerryModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "q", "ctrl+c":
			qm.Done = true
			return qm, tea.Quit
		}
	}

	switch qm.ResponseMethod {
	case Single, Multiple:
	case Undefined:
		panic(fmt.Sprintf("querry '%v' response method was not set", qm.Title))
	default:
		panic(fmt.Sprintf("querry '%v' response method unknown", qm.Title))
	}
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	case tea.KeyMsg:
		if qm.Done {
			return qm, nil
		}
		switch keypress := msg.String(); keypress {
		case "esc":
			qm.ChosenSingle = nil
			qm.ChosenMultiple = nil
			qm.Done = true
		case "enter":
			switch qm.ResponseMethod {
			case Single:
				qm.ChosenSingle = &qm.Items[qm.cursorPosition]
			case Multiple:
				for c, item := range qm.Items {
					if qm.OptionsMarked[c] {
						qm.ChosenMultiple = append(qm.ChosenMultiple, &item)
					}
				}
			}
			qm.Done = true
			return qm, Submit()
		case " ":
			switch qm.ResponseMethod {
			case Multiple:
				qm.toggleSelection()
			}
		case "right":
		case "left":
		case "up", "k", "л":
			qm.cursorPosition--
			if qm.cursorPosition < 0 {
				qm.cursorPosition = 0
			}
		case "down", "j", "о":
			qm.cursorPosition++
			if qm.cursorPosition > len(qm.Items)-1 {
				qm.cursorPosition = len(qm.Items) - 1
			}
			//qm.List, cmd = qm.List.Update(msg)
		default:

		}
	}

	return qm, cmd
}

func (qm *QuerryModel) View() string {
	s := "" // fmt.Sprintf("%v", qm) + "\n"
	switch qm.Done {
	case true:
		s += doneView(qm)
	case false:
		s += notDoneView(qm)
	}
	s = qm.mainStyle.Render(s)
	return s
}

func doneView(qm *QuerryModel) string {
	s := ""
	s += renderHeader(qm) + "\n"
	s += renderTitle(qm) + "\n"
	switch qm.ResponseMethod {
	case Single:
		s += qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render("selected: ") + "\n"
		s += qm.cursor.Passive + qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render(qm.ChosenSingle.key) + "\n"
	case Multiple:
		s += qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render("selected: ") + "\n"
		selectionPassed := false
		for i, item := range qm.Items {
			if qm.OptionsMarked[i] {
				s += qm.cursor.Passive + qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render(item.key) + "\n"
				selectionPassed = true
			}
		}
		if !selectionPassed {
			s += qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render("<<NO ITEMS SELECTED>>") + "\n"
		}

	}

	return s
}

func reportView(qm *QuerryModel) string {
	s := ""
	s += renderTitle(qm) + "\n"
	switch qm.ResponseMethod {
	case Single:
		s += qm.cursor.Passive + qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render(fmt.Sprintf("%v (%v) = %v", qm.ChosenSingle.key, qm.ChosenSingle.description, qm.ChosenSingle.payload)) + "\n"
	case Multiple:
		selectionPassed := false
		for i, item := range qm.Items {
			if qm.OptionsMarked[i] {
				s += qm.cursor.Passive + qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render(item.key) + "\n"
				selectionPassed = true
			}
		}
		if !selectionPassed {
			s += qm.cursor.Passive + qm.itemStyles.Item_Cursor_Marked.Render("<<NO ITEMS SELECTED>>") + "\n"
		}

	}
	return s
}

func notDoneView(qm *QuerryModel) string {
	s := ""
	s += renderHeader(qm) + "\n"
	s += renderTitle(qm) + "\n"
	s += renderItems(qm) + "\n"
	s += renderTail(qm)
	return s
}

func (qm *QuerryModel) toggleSelection() {
	qm.OptionsMarked[qm.cursorPosition] = !qm.OptionsMarked[qm.cursorPosition]
}

func (st *Stack) Init() tea.Cmd {
	return nil
}

func (st *Stack) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	// case tea.WindowSizeMsg:
	case SubmitMsg:
		if st.Active == len(st.Models)-1 {
			st.Done = true
		}
		if st.Active < len(st.Models)-1 {
			st.Active++
		}
	case tea.KeyMsg:
		switch keypress := msg.String(); keypress {
		case "q", "ctrl+c":
		case "0":
			st.Active = 0
			return st, nil
		case "1":
			st.Active = 1
			return st, nil
		}
	}

	var cmds []tea.Cmd

	for i, model := range st.Models {
		if i == st.Active {
			updated, cmd := model.Update(msg)
			cmds = append(cmds, cmd)
			st.Models[st.Active] = updated.(*QuerryModel)
		}
	}
	return st, tea.Batch(cmds...)
}

func (st *Stack) View() string {
	switch st.Done {
	case true:
		s := ""
		for _, m := range st.Models {
			s += reportView(m)
		}
		return s
	case false:
		return st.Models[st.Active].View()
	}
	return "no data (ERROR)"
}
