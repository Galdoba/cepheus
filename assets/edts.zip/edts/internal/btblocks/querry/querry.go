package querry

import (
	"github.com/charmbracelet/lipgloss"
)

const (
	Undefined = 0
	Single    = 1
	Multiple  = 2
	Confirm   = 3
)

type Stack struct {
	Models []*QuerryModel
	Active int
	Done   bool
}

type QuerryModel struct {
	Header         Header
	Tail           Tail
	Title          string
	Items          []Item
	OptionsMarked  map[int]bool
	cursorPosition int
	titleStyle     lipgloss.Style
	enumerator     Enumerator
	separator      Separator
	mark           Mark
	cursor         Cursor
	itemStyles     ItemStyles
	mainStyle      lipgloss.Style

	ResponseMethod    int
	Width             int
	Height            int
	gap_header_title  int
	gap_title_items   int
	gap_between_items int
	gap_items_tail    int

	UseHeader      bool
	UseTail        bool
	UseDescription bool
	UseEnumeration bool
	UseSeparator   bool
	Done           bool

	ChosenSingle   *Item
	ChosenMultiple []*Item
}

func NewQueryStack(models ...QuerryModel) Stack {
	st := Stack{}
	for _, m := range models {
		st.Models = append(st.Models, &m)
	}
	return st
}

func New(options ...QuerryOption) QuerryModel {
	qm := defaultQuerryModel()
	for _, modify := range options {
		modify(&qm)
	}

	return qm
}

type QuerryOption func(*QuerryModel)

func defaultQuerryModel() QuerryModel {
	qm := QuerryModel{}
	qm.OptionsMarked = make(map[int]bool)
	qm.enumerator = DefaultEnumerator
	qm.separator = DefaultSeparator
	qm.mark = DefaultMark
	qm.cursor = DefaultCursor
	qm.titleStyle = styleBasedValue("", color_defaultTitle)
	qm.itemStyles = DefaultItemStyles
	qm.mainStyle = defaultStyle()

	return qm
}

func styleBasedValue(literal, colorCode string) lipgloss.Style {
	return lipgloss.NewStyle().SetString(literal).Foreground(lipgloss.Color(colorCode))
}

func defaultStyle() lipgloss.Style {
	return styleBasedValue("", color_gray)
}

//////OUT

func (qm *QuerryModel) Single() *Item {
	return qm.ChosenSingle
}

func (qm *QuerryModel) Multiple() []*Item {
	return qm.ChosenMultiple
}

func (st *Stack) Chosen() map[int][]*Item {
	chosen := make(map[int][]*Item)
	for i, m := range st.Models {
		switch m.ResponseMethod {
		case Single:
			chosen[i] = []*Item{m.ChosenSingle}
		case Multiple:
			chosen[i] = m.ChosenMultiple
		}
	}
	return chosen
}
