package querry

import (
	"fmt"
	"strings"
)

func renderHeader(qm *QuerryModel) string {
	s := ""
	if qm.UseHeader {
		s += qm.Header.Style.Render(qm.Header.Text)
		for i := 0; i < qm.gap_header_title; i++ {
			s += "\n"
		}
	}
	//s += qm.titleStyle.Render(qm.Title)
	return s
}

func renderTitle(qm *QuerryModel) string {
	s := ""
	s += qm.titleStyle.Render(qm.Title)
	for i := 0; i < qm.gap_title_items; i++ {
		s += "\n"
	}
	return s

}

func renderCursor(qm *QuerryModel, n int) (string, int) {
	s := ""
	width := 0
	switch n == qm.cursorPosition {
	case true:
		s += qm.cursor.StyleActive.Render(qm.cursor.Active)
		width += lettersInWords(qm.cursor.Active)
	case false:
		s += qm.cursor.StylePassive.Render(qm.cursor.Passive)
		width += lettersInWords(qm.cursor.Passive)
	}
	return s, width
}

func renderDescription(qm *QuerryModel, n, bfrSep, afterSep int) string {
	s := ""
	if qm.UseDescription {
		for i := 0; i < bfrSep; i++ {
			s += " "
		}
		if qm.UseSeparator {
			s += qm.separator.StyleSeparator.Render(qm.separator.Separator)
		}
		for i := 0; i < afterSep; i++ {
			s += " "
		}
		s += qm.itemStyles.Description.Render(qm.Items[n].description)
	}

	return s
}

func renderEnumerator(qm *QuerryModel, n int) (string, int) {
	s := ""
	width := 0
	if qm.UseEnumeration {
		enm := qm.enumerator
		enum := enm.StylePrefix.Render(enm.Prefix) + enm.StyleValue.Render(fmt.Sprintf("%v", n+1)) + enm.StyleSuffix.Render(enm.Suffix)
		s += enum
		width += lettersInWords(enm.Prefix, fmt.Sprintf("%v", n), enm.Suffix)
	}
	return s, width
}

func renderItems(qm *QuerryModel) string {
	s := ""
	if len(qm.Items) < 1 {
		nocursor, _ := renderCursor(qm, -1)
		s += nocursor + qm.itemStyles.Item_NOT_Cursor_NOT_Marked.Render("  <<NO ITEMS>>")
	}
	for n := range qm.Items {
		beforeSep := 0

		cursRend, cursWidth := renderCursor(qm, n)
		beforeSep += cursWidth
		s += cursRend

		enumRend, enumWidth := renderEnumerator(qm, n)
		beforeSep += enumWidth
		s += enumRend

		if qm.UseSeparator {
			s += qm.separator.StyleSeparator.Render(qm.separator.Separator)
		}

		itemRend, afterSep := renderItem(qm, n)
		s += itemRend
		s += renderDescription(qm, n, beforeSep, afterSep)

		for i := 0; i < qm.gap_between_items; i++ {
			s += "\n"
		}
	}
	return s
}

func renderMark(mark Mark, positive bool) string {
	s := ""
	switch positive {
	case true:
		s += mark.StyleOut.Render(mark.Prefix) + mark.StyleIn.Render(mark.MarkPositive) + mark.StyleOut.Render(markSuffix)
	case false:
		s += mark.StyleOut.Render(mark.Prefix) + mark.StyleIn.Render(mark.MarkNegative) + mark.StyleOut.Render(markSuffix)
	}
	return s
}

func renderItem(qm *QuerryModel, n int) (string, int) {
	s := ""
	width := 0
	switch qm.ResponseMethod {
	case Single:
		itemSt := itemStyle(qm.OptionsMarked, n, qm.cursorPosition)
		switch itemSt {
		case select_Y_marked_Y, select_Y_marked_N:
			s += qm.itemStyles.Item_Cursor_Marked.Render(qm.Items[n].key) + "\n"
		case select_N_marked_Y, select_N_marked_N:
			s += qm.itemStyles.Item_NOT_Cursor_NOT_Marked.Render(qm.Items[n].key) + "\n"
		}
	case Multiple:
		itemSt := itemStyle(qm.OptionsMarked, n, qm.cursorPosition)
		switch itemSt {
		case select_Y_marked_Y:
			s += renderMark(qm.mark, true) + qm.itemStyles.Item_Cursor_Marked.Render(qm.Items[n].key) + "\n"
			width += lettersInWords(qm.mark.Prefix, qm.mark.MarkPositive, qm.mark.Suffix)
		case select_Y_marked_N:
			s += renderMark(qm.mark, false) + qm.itemStyles.Item_Cursor_NOT_Marked.Render(qm.Items[n].key) + "\n"
			width += lettersInWords(qm.mark.Prefix, qm.mark.MarkNegative, qm.mark.Suffix)
		case select_N_marked_Y:
			s += renderMark(qm.mark, true) + qm.itemStyles.Item_NOT_Cursor_Marked.Render(qm.Items[n].key) + "\n"
			width += lettersInWords(qm.mark.Prefix, qm.mark.MarkPositive, qm.mark.Suffix)
		case select_N_marked_N:
			s += renderMark(qm.mark, false) + qm.itemStyles.Item_NOT_Cursor_NOT_Marked.Render(qm.Items[n].key) + "\n"
			width += lettersInWords(qm.mark.Prefix, qm.mark.MarkNegative, qm.mark.Suffix)
		}
	}
	return s, width
}

func renderTail(qm *QuerryModel) string {
	s := ""
	if qm.UseTail {
		for i := 0; i < qm.gap_items_tail; i++ {
			s += "\n"
		}
		s += qm.Tail.Style.Render(qm.Tail.Text)
	}
	return s
}

const (
	select_Y_marked_Y = 11
	select_Y_marked_N = 10
	select_N_marked_Y = 1
	select_N_marked_N = 0
)

func itemStyle(marked map[int]bool, itemNum, cursor int) int {
	val := 0
	if cursor == itemNum {
		val += 10
	}
	if marked[itemNum] {
		val += 1
	}
	return val
}

func countLetters(str string) int {
	return len(strings.Split(str, ""))
}

func lettersInWords(words ...string) int {
	letters := 0
	for _, word := range words {
		letters += countLetters(word)
	}
	return letters
}
