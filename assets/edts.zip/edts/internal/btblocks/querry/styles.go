package querry

import "github.com/charmbracelet/lipgloss"

const (
	color_gray         = "7"
	color_dark_gray    = "241"
	color_defaultTitle = "15"
	cursor_ANSI        = " --> "
	no_cursor_ANSI     = "     "
	mark_ANSI          = "X"
	no_mark_ANSI       = " "
	markPrefix         = "["
	markSuffix         = "] "
	point              = ". "
	hash               = " #"
	separator_ANSI     = "| "
)

type Enumerator struct {
	StylePrefix lipgloss.Style
	StyleValue  lipgloss.Style
	StyleSuffix lipgloss.Style
	Prefix      string
	Suffix      string
}

var DefaultEnumerator = Enumerator{
	Prefix:      hash,
	Suffix:      point,
	StylePrefix: defaultStyle(),
	StyleSuffix: defaultStyle(),
	StyleValue:  defaultStyle(),
}

type Header struct {
	Text  string
	Style lipgloss.Style
}

func newHeader(text string, style lipgloss.Style) Header {
	h := Header{}
	h.Text = text
	h.Style = style
	return h
}

type Tail struct {
	Text  string
	Style lipgloss.Style
}

func newTail(text string, style lipgloss.Style) Tail {
	t := Tail{}
	t.Text = text
	t.Style = style
	return t
}

type Separator struct {
	Separator      string
	StyleSeparator lipgloss.Style
}

var DefaultSeparator = Separator{
	Separator:      separator_ANSI,
	StyleSeparator: defaultStyle(),
}

type Mark struct {
	Prefix       string
	MarkNegative string
	MarkPositive string
	Suffix       string
	StyleIn      lipgloss.Style
	StyleOut     lipgloss.Style
}

var DefaultMark = Mark{
	Prefix:       "[",
	MarkNegative: " ",
	MarkPositive: "X",
	Suffix:       "] ",
	StyleIn:      defaultStyle(),
	StyleOut:     defaultStyle(),
}

type Cursor struct {
	Active       string
	Passive      string
	StyleActive  lipgloss.Style
	StylePassive lipgloss.Style
}

var DefaultCursor = Cursor{
	Active:       cursor_ANSI,
	Passive:      no_cursor_ANSI,
	StyleActive:  defaultStyle(),
	StylePassive: defaultStyle(),
}

type ItemStyles struct {
	Item_Cursor_Marked         lipgloss.Style
	Item_Cursor_NOT_Marked     lipgloss.Style
	Item_NOT_Cursor_Marked     lipgloss.Style
	Item_NOT_Cursor_NOT_Marked lipgloss.Style
	Description                lipgloss.Style
}

var DefaultItemStyles = ItemStyles{
	Item_Cursor_Marked:         defaultStyle(),
	Item_Cursor_NOT_Marked:     defaultStyle(),
	Item_NOT_Cursor_Marked:     defaultStyle(),
	Item_NOT_Cursor_NOT_Marked: defaultStyle(),
	Description:                styleBasedValue("", color_dark_gray),
}

var DefaultStyle = defaultStyle()
