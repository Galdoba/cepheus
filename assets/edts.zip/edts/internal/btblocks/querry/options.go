package querry

import "github.com/charmbracelet/lipgloss"

func WithTitle(title string) QuerryOption {
	return func(qm *QuerryModel) {
		qm.Title = title
	}
}

func WithTitleStyle(style lipgloss.Style) QuerryOption {
	return func(qm *QuerryModel) {
		qm.titleStyle = style
	}
}

func WithItems(items ...Item) QuerryOption {
	return func(qm *QuerryModel) {
		qm.Items = items
	}
}

func WithHeader(text string, style lipgloss.Style) QuerryOption {
	return func(qm *QuerryModel) {
		h := newHeader(text, style)
		qm.Header = h
		qm.UseHeader = true
	}
}

func WithTail(text string, style lipgloss.Style) QuerryOption {
	return func(qm *QuerryModel) {
		t := newTail(text, style)
		qm.Tail = t
		qm.UseTail = true
	}
}

func WithResponseMethod(responce int) QuerryOption {
	return func(qm *QuerryModel) {
		qm.ResponseMethod = responce
	}
}

func WithDescriptionUsage(use bool) QuerryOption {
	return func(qm *QuerryModel) {
		qm.UseDescription = use
	}
}

func WithSeparatorUsage(use bool) QuerryOption {
	return func(qm *QuerryModel) {
		qm.UseSeparator = use
	}
}

func WithEnumeratorUsage(use bool) QuerryOption {
	return func(qm *QuerryModel) {
		qm.UseEnumeration = use
	}
}

func WithGaps(headerTitle, titleItems, betweenItems, itemsTail int) QuerryOption {
	return func(qm *QuerryModel) {
		qm.gap_header_title = headerTitle
		qm.gap_title_items = titleItems
		qm.gap_between_items = betweenItems
		qm.gap_items_tail = itemsTail
	}
}

func WithEnumerator(enumerator Enumerator) QuerryOption {
	return func(qm *QuerryModel) {
		qm.enumerator = enumerator
		qm.UseEnumeration = true
	}
}

func WithSeparator(separator Separator) QuerryOption {
	return func(qm *QuerryModel) {
		qm.separator = separator
		qm.UseSeparator = true
	}
}

func WithCursor(cursor Cursor) QuerryOption {
	return func(qm *QuerryModel) {
		qm.cursor = cursor
	}
}

func WithItemStyles(is ItemStyles) QuerryOption {
	return func(qm *QuerryModel) {
		qm.itemStyles = is
	}
}

func WithStyle(style lipgloss.Style) QuerryOption {
	return func(qm *QuerryModel) {
		qm.mainStyle = style
	}
}
