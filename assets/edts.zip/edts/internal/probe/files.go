package probe

import (
	"fmt"

	"github.com/Galdoba/edts/pkg/ump"
)

func StreamTypes(path string) (map[string]int, error) {
	mp := ump.NewProfile()
	err := mp.ConsumeFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to consume path %v: %v", path, err)
	}
	mapping := make(map[string]int)
	for _, stream := range mp.Streams {
		mapping[stream.Codec_type]++
		switch stream.Codec_type {
		case ump.CODEC_TYPE_AUDIO:
			mapping["channels"] = stream.Channels
		}
	}
	return mapping, nil
}

type StreamInfo struct {
	Path                string
	Codec               string
	SameCodecTypeInFile int
	Width               int
	Height              int
	Fps                 float64
	Channels            int
	Index               int
	Position            int
}

func Streams(path string) ([]StreamInfo, error) {
	mp := ump.NewProfile()
	err := mp.ConsumeFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to consume path %v: %v", path, err)
	}
	streams := []StreamInfo{}
	vn, an, sn, dn := 0, 0, 0, 0
	for i, stream := range mp.Streams {
		streamInfo := StreamInfo{
			Path:                path,
			Codec:               stream.Codec_type,
			SameCodecTypeInFile: sn,
			Width:               -1,
			Height:              -1,
			Fps:                 -1,
			Channels:            -1,
			Index:               i,
			Position:            -1,
		}
		switch stream.Codec_type {
		case ump.CODEC_TYPE_VIDEO:
			streamInfo.Position = vn
			streamInfo.Width = stream.Width
			streamInfo.Height = stream.Height
			streamInfo.Fps = stream.Fps()
			vn++
		case ump.CODEC_TYPE_AUDIO:
			streamInfo.Position = an
			streamInfo.Channels = stream.Channels
			an++
		case ump.CODEC_TYPE_SUBTITLE:
			streamInfo.Position = sn
			sn++
		default:
			streamInfo.Position = dn
			dn++
		}
		streams = append(streams, streamInfo)
	}
	for i, stream := range streams {
		switch stream.Codec {
		case ump.CODEC_TYPE_VIDEO:
			streams[i].SameCodecTypeInFile = vn
		case ump.CODEC_TYPE_AUDIO:
			streams[i].SameCodecTypeInFile = an
		case ump.CODEC_TYPE_SUBTITLE:
			streams[i].SameCodecTypeInFile = sn
		default:
			streams[i].SameCodecTypeInFile = dn
		}
	}

	return streams, nil
}
