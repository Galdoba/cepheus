package edtspath

import "testing"

func TestPaths(t *testing.T) {
	CreatePathFile()
}
