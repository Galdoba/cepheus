package edtspath

import (
	"fmt"
	"strings"

	"github.com/Galdoba/edts/pkg/translit"
)

type pathmaker struct {
	root   string
	base   string
	season string
	trl    bool
	agent  string
}

type PathOption func(*pathmakerOpts)

type pathmakerOpts struct {
	root   string
	base   string
	season string
	trl    bool
	agent  string
	date   string
}

func WithRoot(root string) PathOption {
	return func(po *pathmakerOpts) {
		po.root = root
	}
}

func WithBase(base string) PathOption {
	return func(po *pathmakerOpts) {
		po.base = base
	}
}

func WithSeason(season string) PathOption {
	return func(po *pathmakerOpts) {
		po.season = season
	}
}

func WithAgent(agent string) PathOption {
	return func(po *pathmakerOpts) {
		po.agent = agent
	}
}

func WithDate(date string) PathOption {
	return func(po *pathmakerOpts) {
		po.date = date
	}
}

func Trailer() PathOption {
	return func(po *pathmakerOpts) {
		po.trl = true
	}
}

func Archive(options ...PathOption) (string, error) {
	settings := pathmakerOpts{}
	for _, modify := range options {
		modify(&settings)
	}
	if settings.root == "" {
		return "", fmt.Errorf("archive root is not set")
	}
	if settings.agent == "" {
		return "", fmt.Errorf("agent is not set")
	}
	if settings.base == "" {
		return "", fmt.Errorf("base is not set")
	}
	out := ""
	switch settings.trl {
	case true:
		//\\192.168.31.4\root\IN\@TRAILERS\_DONE\12_rozhdestvenskih_sobak_2_TRL\
		if settings.season != "" {
			settings.base = settings.base + settings.season
		}
		out = fmt.Sprintf("%v@TRAILERS/_DONE/%v", settings.root, settings.base)
	case false:
		//\\192.168.31.4\root\IN\_AMEDIA\_DONE\Axios_vse_imeet_znachenie_s03\Axios_vse_imeet_znachenie_s03e03_PRT241003150551_SER_04502_16.mp4
		agentBlock := strings.ToUpper("_" + translit.String(settings.agent))
		nameBlock := settings.base
		if settings.season != "" {
			nameBlock = settings.base + "_" + settings.season + "/"
		}
		out = fmt.Sprintf("%v%v/_DONE/%v%v", settings.root, agentBlock, nameBlock)
	}
	return out, nil
}

func Edit(options ...PathOption) (string, error) {
	settings := pathmakerOpts{}
	for _, modify := range options {
		modify(&settings)
	}
	if settings.root == "" {
		return "", fmt.Errorf("archive root is not set")
	}
	if settings.agent == "" {
		return "", fmt.Errorf("agent is not set")
	}
	if settings.base == "" {
		return "", fmt.Errorf("base is not set")
	}
	out := ""
	switch settings.trl {
	case true:
		out = fmt.Sprintf("%v", settings.root)
	case false:
		//ROOT              AGENT/DATE   BASE+[SEASON]
		//\\nas\ROOT\EDIT\  _inoe\       Test_serial_s01\  Test_serial_s01_01_HD_proxy.mp4
		second := strings.ToLower(fmt.Sprintf("_%v", settings.agent))
		if settings.date != "" {
			second = editDestinationDate(settings.date)
		}
		third := ""
		if settings.season != "" {
			third = settings.base + "_" + settings.season
		}

		out = fmt.Sprintf("%v%v/%v", settings.root, second, third)
	}
	return out, nil
}

func editDestinationDate(date string) string {
	return date
}
