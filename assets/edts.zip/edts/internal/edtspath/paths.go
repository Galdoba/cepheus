package edtspath

import (
	"encoding/json"
	"os"
	"path/filepath"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/pkg/pathfinder"
)

func Inbox(app string) string {
	path, err := pathfinder.NewPath(
		pathfinder.WithSystem(definitions.SYSTEM),
		pathfinder.WithProgram(app),
		pathfinder.WithLayers([]string{"events", "inbox"}),
		pathfinder.IsSlashed(),
	)
	if err != nil {
		panic(err.Error())
	}
	return path
}

func Outbox(app string) string {
	path, err := pathfinder.NewPath(
		pathfinder.WithSystem(definitions.SYSTEM),
		pathfinder.WithProgram(app),
		pathfinder.WithLayers([]string{"events", "outbox"}),
		pathfinder.IsSlashed(),
	)
	if err != nil {
		panic(err.Error())
	}
	return path
}

func StorageDir(app string) string {
	path, err := pathfinder.NewPath(
		pathfinder.WithSystem(definitions.SYSTEM),
		pathfinder.WithProgram(app),
		pathfinder.WithLayers([]string{"storage"}),
		pathfinder.IsSlashed(),
	)
	if err != nil {
		panic(err.Error())
	}
	return path
}

func ConfigDir(app string) string {
	path, err := pathfinder.NewPath(
		pathfinder.WithSystem(definitions.SYSTEM),
		pathfinder.WithProgram(app),
		pathfinder.IsConfig(),
	)
	if err != nil {
		panic(err.Error())
	}
	return path
}

func ConfigFile(app string) string {
	path, err := pathfinder.NewPath(
		pathfinder.WithSystem(definitions.SYSTEM),
		pathfinder.WithProgram(app),
		pathfinder.WithFileName(app+"_default.config"),
		pathfinder.IsConfig(),
	)
	if err != nil {
		panic(err.Error())
	}
	return path
}

func PathFile() string {
	path, err := pathfinder.NewPath(
		pathfinder.IsConfig(),
		pathfinder.WithProgram("edts"),
		pathfinder.WithFileName("paths.json"),
	)
	if err != nil {
		panic(err.Error())
	}
	return path
}

func PathsMap() (map[string]string, error) {
	bt, err := os.ReadFile(PathFile())
	if err != nil {
		return nil, err
	}
	type Paths struct {
		PathMap map[string]string `json:"Paths"`
	}
	pth := Paths{}
	pth.PathMap = make(map[string]string)
	err = json.Unmarshal(bt, &pth)
	if err != nil {
		return nil, err
	}
	return pth.PathMap, nil
}

func CreatePathFile() error {
	type Paths struct {
		PathMap map[string]string `json:"Paths"`
	}
	pth := Paths{}
	pth.PathMap = make(map[string]string)
	pth.PathMap["alias1"] = "path1"
	pth.PathMap["alias2"] = "path2"
	bt, err := json.MarshalIndent(&pth, "", "  ")
	if err != nil {
		return err
	}
	err = os.MkdirAll(filepath.Dir(PathFile()), 0666)
	if err != nil {
		return err
	}
	f, err := os.OpenFile(PathFile(), os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		return err
	}
	_, err = f.Write(bt)
	if err != nil {
		return err
	}
	return f.Close()
}
