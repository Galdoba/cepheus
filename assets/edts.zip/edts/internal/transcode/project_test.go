package transcode

import (
	"encoding/json"
	"fmt"
	"os"
	"testing"
)

func TestCreateProjects(t *testing.T) {
	prj := Project{}
	bt, err := os.ReadFile(`c:\Users\pemaltynov\Programs\galdoba\edts\edts-project-manager-client\storage\Melochi_zhizni_01.04.2025.json`)
	fmt.Println(err)
	err = json.Unmarshal(bt, &prj)
	fmt.Println(err)
	fmt.Println(prj)
	//pr := prj.TargetProducts[0]
	//bashmaker.GenerateBashScript(pr)

}

/*
Load Project Files
Update Table Rows
Update From Table To Files
*/
