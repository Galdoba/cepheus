package transcode

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
)

type Procman struct {
	storageDir string
}

func (prm *Procman) LoadProjectsFromFiles() (map[string]*Project, error) {
	//Read Dir
	stDir := prm.storageDir
	fi, err := os.ReadDir(prm.storageDir)
	if err != nil {
		return nil, fmt.Errorf("failed to read project directory: %v", err)
	}
	prMap := make(map[string]*Project)
	for i, f := range fi {
		fmt.Println(i, f)
		name := f.Name()
		if !strings.HasSuffix(name, ".json") {
			fmt.Println("not a json")
			continue
		}
		pr := Project{}
		bt, err := os.ReadFile(stDir + name)
		if err != nil {
			return nil, fmt.Errorf("failed to read project file: %v", err)
		}
		if err := json.Unmarshal(bt, &pr); err != nil {
			return nil, fmt.Errorf("failed to unmarshal project file: %v", err)
		}
		prMap[pr.Title+pr.DateBlock] = &pr
	}
	return prMap, nil
}
