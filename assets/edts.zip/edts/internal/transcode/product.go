package transcode

// import (
// 	"fmt"
// 	"math"
// 	"strconv"
// 	"strings"

// 	"github.com/Galdoba/edts/pkg/ump"
// )

// const (
// 	REQUEST_TYPE_FILM = "FILM"
// 	REQUEST_TYPE_TRL  = "TRL"
// 	REQUEST_TYPE_SER  = "SER"

// 	REQUEST_TYPE_V        = "video"
// 	REQUEST_TYPE_Vh       = "video with hardsubs"
// 	REQUEST_TYPE_2A2      = "audio (stereo to strereo)"
// 	REQUEST_TYPE_11A2     = "audio (2 mono to strereo)"
// 	REQUEST_TYPE_6A6      = "audio (5.1 to 5.1)"
// 	REQUEST_TYPE_111111A6 = "audio (6 mono to 5.1)"
// 	REQUEST_TYPE_2112A6   = "audio (stereo+mono+mono+stereeo to 5.1)"
// 	REQUEST_TYPE_6A2      = "audio (5.1 to stereo)"
// 	REQUEST_TYPE_1A2      = "audio (mono to stereo)"
// 	REQUEST_TYPE_S        = "subtitles"
// )

// type ProductRequest struct {
// 	Type                    string                   `json:"Type"`
// 	Desc                    string                   `json:"Description"`
// 	SourceDir               string                   `json:"Source Directory"`
// 	SourceFiles             []string                 `json:"Sources"`
// 	TargetFileTypeToSources map[string][]*SourceInfo `json:"Target-Source Map"`
// 	TargetName              string                   `json:"Target Name"`
// 	Schema                  TargetSchema             `json:"Schema"`
// 	TargetDestination       string                   `json:"Target Directory"`
// 	TargetFiles             []string                 `json:"Target Files"`
// 	InitialDuration         float64                  `json:"Initial Duration,omitempty"`
// 	TargetDuration          float64                  `json:"Target Duration,omitempty"`
// }

// type SourceInfo struct {
// 	FileName          string            `json:"File"`
// 	StreamPurpose     string            `json:"Purpose,omitempty"`
// 	StreamCodec       string            `json:"Codec Type,omitempty"`
// 	StreamNum         int               `json:"Stream Number,omitempty"`
// 	Channels          int               `json:"Channel Number,omitempty"`
// 	Width             int               `json:"Width,omitempty"`
// 	Height            int               `json:"Height,omitempty"`
// 	Duration          float64           `json:"Actual Duration,omitempty"`
// 	TranscodeConserns map[string]string `json:"Transcode Issue/Decidion,omitempty"`
// }

// type TargetSchema struct {
// 	Video []string
// 	Audio []int
// 	Subs  int
// 	HSub  string
// 	Notes []string
// }

// func (sc *TargetSchema) String() string {
// 	s := ""
// 	switch len(sc.Video) {
// 	case 0:
// 	default:
// 		s += "V"
// 		for _, vid := range sc.Video {
// 			s += vid
// 		}
// 		s += ":"
// 	}
// 	switch len(sc.Audio) {
// 	case 0:
// 	default:
// 		s += "A"
// 		for _, aud := range sc.Audio {
// 			s += fmt.Sprintf("%v", aud)
// 		}
// 		s += ":"
// 	}
// 	switch sc.Subs {
// 	case 0:
// 	default:
// 		s += "S" + fmt.Sprintf("%v", sc.Subs) + ":"
// 	}
// 	if sc.HSub != "" {
// 		s += sc.HSub
// 	}
// 	s = strings.TrimSuffix(s, ":")
// 	return s
// }

// func NewSourceInfo() *SourceInfo {
// 	si := SourceInfo{}
// 	si.TranscodeConserns = make(map[string]string)
// 	return &si
// }

// func (prj *Project) AddProductRequest(prType string) *ProductRequest {
// 	pr := ProductRequest{}
// 	pr.Type = prType
// 	pr.Desc = typeDescription(pr.Type)
// 	pr.TargetFileTypeToSources = make(map[string][]*SourceInfo)
// 	return &pr
// }

// func typeDescription(t string) string {
// 	switch t {
// 	case REQUEST_TYPE_TRL:
// 		return "Трейлер"
// 	case REQUEST_TYPE_FILM:
// 		return "Фильм или Эпизод сериала"
// 	case REQUEST_TYPE_SER:
// 		return "Набор эпизодов сериала из одного сезона"
// 	case "":
// 		return "тип не указан (ошибка)"
// 	default:
// 		panic("неизвестный продукт")
// 	}
// }

// func (pr *ProductRequest) SetProdictSources(dir string, src ...string) {
// 	pr.SourceDir = dir
// 	pr.SourceFiles = src
// }

// func (pr *ProductRequest) AddTask(task string) error {
// 	//validate task
// 	pr.TargetFileTypeToSources[task] = []*SourceInfo{}
// 	return nil
// }

// func (pr *ProductRequest) SetTargetSources(tgt string, src ...string) error {
// 	//validate target
// 	//if tgt is video add Initial Duration and calculate Target Duration
// 	//sources MUST be listed as Product Sources
// 	//validate src streams by target type
// 	//create []SourceInfo from sources
// 	var srcInfo []*SourceInfo
// 	pr.TargetFileTypeToSources[tgt] = srcInfo
// 	//if Target Duration is not 0 add Target Duration to all sources
// 	return nil
// }

// func (pr *ProductRequest) SetInitialDuration(dur float64) {
// 	pr.InitialDuration = dur
// }

// // func (pr *ProductRequest) Sources() []string {
// // 	return pr.SourceFiles
// // }

// func (pr *ProductRequest) PredictSourceCombination() error {
// 	pr.Schema = TargetSchema{}
// 	videoFound := 0
// 	audioFound := 0
// 	srtFound := 0
// 	for _, src := range pr.SourceFiles {
// 		path := pr.SourceDir + src
// 		prf := ump.NewProfile()
// 		prf.ConsumeFile(path)
// 		for _, stream := range prf.Streams {
// 			srcInfo := NewSourceInfo()
// 			srcInfo.StreamCodec = stream.Codec_type
// 			switch srcInfo.StreamCodec {
// 			case ump.CODEC_TYPE_VIDEO:
// 				pr.collectInfoVideo(stream, srcInfo, videoFound)
// 				videoFound++
// 			case ump.CODEC_TYPE_AUDIO:
// 				pr.collectInfoAudio(stream, srcInfo, audioFound)
// 				audioFound++
// 			case ump.CODEC_TYPE_SUBTITLE:
// 				pr.collectInfoSubtitle(stream, srcInfo, srtFound)
// 				srtFound++
// 			default:
// 				continue
// 			}
// 			pr.TargetFileTypeToSources[src] = append(pr.TargetFileTypeToSources[src], srcInfo)
// 		}

// 	}

// 	pr.GuessSchemma()
// 	return nil
// }

// func (pr *ProductRequest) GuessSchemma() error {
// 	schema := TargetSchema{}
// 	switch len(pr.TargetFileTypeToSources) {
// 	case 0:
// 		return fmt.Errorf("can't guess: no sources")
// 	case 1:
// 		for _, val := range pr.TargetFileTypeToSources {
// 			switch len(val) {
// 			case 0:
// 				return fmt.Errorf("can't guess: no streams in source")
// 			default:
// 				for i, srcInfo := range val {
// 					switch srcInfo.StreamCodec {
// 					case ump.CODEC_TYPE_VIDEO:
// 						tag, _ := tagVideoSize(val[i].Width, val[i].Height)
// 						schema.Video = append(schema.Video, tag)
// 					case ump.CODEC_TYPE_AUDIO:
// 						schema.Audio = append(schema.Audio, val[i].Channels)
// 					case ump.CODEC_TYPE_SUBTITLE:
// 						schema.Subs++
// 						schema.HSub = " (undecided)"
// 					}
// 				}
// 			}
// 		}

// 	}
// 	schema.examine()
// 	pr.Schema = schema
// 	return nil
// }

// func (sc *TargetSchema) examine() {
// 	s := sc.String()
// 	switch len(sc.Video) {
// 	default:
// 		return
// 	case 0:
// 		sc.Notes = append(sc.Notes, "audio only")
// 	case 1:
// 	}
// 	if strings.Contains(s, "A2112") {
// 		s = strings.ReplaceAll(s, "2112", "6")
// 		sc.Notes = append(sc.Notes, "merge audio 2112")
// 	}
// 	if strings.Contains(s, "A111111") {
// 		s = strings.ReplaceAll(s, "111111", "6")
// 		sc.Notes = append(sc.Notes, "merge 6 mono to 5.1")
// 	}
// 	if strings.Contains(s, "A11") {
// 		s = strings.ReplaceAll(s, "11", "2")
// 		sc.Notes = append(sc.Notes, "merge 2 mono to stereo")
// 	}
// 	switch s {
// 	case "VHD:A2", "VHD:A6", "VHD:A22", "VHD:A62", "VHD:A66":
// 		sc.Notes = append(sc.Notes, "auto")
// 	case "V4K:A2", "V4K:A6", "V4K:A22", "V4K:A62", "V4K:A66":
// 		sc.Notes = append(sc.Notes, "auto")
// 	case "VSD:A2", "VSD:A6", "VSD:A22", "VSD:A62", "VSD:A66":
// 		sc.Notes = append(sc.Notes, "auto")
// 	}
// }

// // func listPossibleSchemmas(pr *ProductRequest, sourceMap map[string][]*SourceInfo) []string {
// // 	videos := []string{}
// // 	audios := []int{}
// // 	subs := 0
// // 	outList := []string{}
// // 	for _, srcInfoSlice := range sourceMap {
// // 		for _, srcInfo := range srcInfoSlice {
// // 			switch srcInfo.StreamCodec {
// // 			case ump.CODEC_TYPE_VIDEO:
// // 				vtag, _ := tagVideoSize(srcInfo.Width, srcInfo.Height)
// // 				videos = append(videos, vtag)
// // 			case ump.CODEC_TYPE_AUDIO:
// // 				audios = append(audios, srcInfo.Channels)
// // 			case ump.CODEC_TYPE_SUBTITLE:
// // 				subs++
// // 			}
// // 		}
// // 	}
// // 	if len(videos) > 1 {
// // 		return nil
// // 	}

// // 	return []string{}
// // }

// func combinationsOfTwo(sl []int) [][]int {
// 	list := [][]int{}
// 	type comb [2]int
// 	values := make(map[comb]int)
// 	for i, i1 := range sl {
// 		for j, i2 := range sl {
// 			cm := comb{i1, i2}
// 			if i == j {
// 				cm[1] = -1
// 			}
// 			values[cm]++
// 		}
// 	}
// 	for cb := range values {
// 		switch cb[1] {
// 		case -1:
// 			list = append(list, []int{cb[0]})
// 		default:
// 			list = append(list, []int{cb[0], cb[1]})
// 		}

// 	}
// 	return list
// }

// func (pr *ProductRequest) collectInfoVideo(stream *ump.Stream, srcInfo *SourceInfo, videoFound int) {
// 	srcInfo.StreamNum = videoFound
// 	fl, err := strconv.ParseFloat(stream.Duration, 64)
// 	if err != nil {
// 		srcInfo.TranscodeConserns["duration"] = fmt.Sprintf("failed to parse: %v", err)
// 		fl = -1
// 	}
// 	srcInfo.Duration = fl
// 	fps := fpsToFloat(stream.R_frame_rate)
// 	pr.InitialDuration = fl
// 	pr.TargetDuration = roundPrecision(pr.InitialDuration*(fps/25), 3)
// 	_, issue := tagVideoSize(stream.Width, stream.Height)
// 	srcInfo.Width = stream.Width
// 	srcInfo.Height = stream.Height
// 	if issue != "" && srcInfo.Width+srcInfo.Height != 0 {
// 		srcInfo.TranscodeConserns["video_size"] = issue
// 	}
// }

// func (pr *ProductRequest) collectInfoAudio(stream *ump.Stream, srcInfo *SourceInfo, videoFound int) {
// 	fl, err := strconv.ParseFloat(stream.Duration, 64)
// 	if err != nil {
// 		srcInfo.TranscodeConserns["duration"] = fmt.Sprintf("failed to parse: %v", err)
// 		fl = -1
// 	}
// 	srcInfo.Duration = fl
// 	srcInfo.Channels = stream.Channels
// }

// func (pr *ProductRequest) collectInfoSubtitle(stream *ump.Stream, srcInfo *SourceInfo, videoFound int) {
// }

// func difference(fl1, fl2 float64) float64 {
// 	d := fl1 - fl2
// 	if d < 0 {
// 		d = d * -1
// 	}
// 	return d
// }

// func fpsToFloat(fps string) float64 {
// 	data := strings.Split(fps, "/")
// 	i1, _ := strconv.Atoi(data[0])
// 	i2, _ := strconv.Atoi(data[1])
// 	fl := float64(i1) / float64(i2)
// 	fli := float64(int(fl*1000)) / 1000
// 	return fli
// }

// func round(num float64) int {
// 	return int(num + math.Copysign(0.5, num))
// }

// func roundPrecision(num float64, precision int) float64 {
// 	output := math.Pow(10, float64(precision))
// 	return float64(round(num*output)) / output
// }

// func tagVideoSize(width, height int) (string, string) {
// 	if width == 3840 && height == 2160 {
// 		return "4K", ""
// 	}
// 	if width == 1920 && height == 1080 {
// 		return "HD", ""
// 	}
// 	if width == 720 && height == 576 {
// 		return "HD", ""
// 	}
// 	if width >= 1920 && height <= 1080 {
// 		return "HD", "scale/pad"
// 	}
// 	if width+height == 0 {
// 		return "", ""
// 	}

// 	return "IDK", fmt.Sprintf("BAD SIZE: %v:%v", width, height)
// }
