package product

import (
	"fmt"
	"testing"
)

func TestNewFilm(t *testing.T) {
	f, err := NewProduct(
		WithOutbase("FILM_BASE"),
		WithDestination("path/to/dir"),
		// WithVideo(
		// 	NewVideo(`\\192.168.31.4\root\IN\@TRAILERS\_DONE\Nyurnberg_mnogomernost_zla_TRL\Nyurnberg_mnogomernost_zla--TRL--NYuRNBERG._MNOGOMERNOST_ZALA._TREYLER_2_4K_.mov`,
		// 		WithHardsub(NewHardsub("path/to/hardsubFile.srt", WithMarginV(15))),
		// 		WithProxy(true),
		// 	),
		// ),
		// WithAudio(
		// 	NewAudio([]string{`\\192.168.31.4\root\IN\@TRAILERS\_DONE\Nyurnberg_mnogomernost_zla_TRL\Nyurnberg_mnogomernost_zla--TRL--NYuRNBERG._MNOGOMERNOST_ZALA._TREYLER_2_4K_.mov`},
		// 		WithCustomMappings(AudioStreamMapping(0, 0), AudioStreamMapping(0, 0)),
		// 		//TODO: WithLayout("stereo"),
		// 	),
		// ),
		WithFilm(
			NewFilm(`\\192.168.31.4\root\IN\_PARADISE\_DONE\Bolshaya_svadba\Bolshaya_Svadba_235_25fps_Rus51_CENZURA_05_03_25.mov`),
		),
	)
	//panic("нужен механизм для запроса лэйаута выходного аудио + проверка не существующих стримов + механизм создания дефолтного лэйаута по принципу 'делаю все стерео и 5,1 что могу - юзер разберется'")
	if err != nil {
		t.Errorf("func error: %v", err)
		return
	}
	fmt.Println("")
	sw := ScriptWriter{}
	sw.declarations = f.Declarations()
	f.FC = *f.ToFilterComplex()
	sw.filterComlex = f.FC
	sw.mappings = SetMappings(f)

	fmt.Println("====================")
	fmt.Println(sw.ffmpegCommand())
	fmt.Println("====================")

}
