package product

import (
	"fmt"
	"path/filepath"
)

type Hardsub struct {
	filename       string
	original_size  string
	fontName       string
	fontSize       string
	primaryColor   string
	secondaryColor string
	outlineColor   string
	backColor      string
	underline      string
	strikeout      string
	scaleX         string
	scalyY         string
	spacing        string
	angle          string
	borderStyle    string
	outline        string
	shadow         string
	alignment      string
	marginL        string
	marginR        string
	marginV        string
	encoding       string
}

func NewHardsub(path string, options ...HardsubOption) Hardsub {
	hs := defaultHardsub()
	hs.filename = filepath.Base(path)
	for _, set := range options {
		set(&hs)
	}
	return hs
}

func (hs Hardsub) ToFilterComplex() string {
	return fmt.Sprintf("subtitles=filename=%v:original_size=%v:force_style='FontName=%v,Fontsize=%v,PrimaryColour=%v,SecondaryColour=%v,OutlineColour=%v,BackColour=%v,Underline=%v,StrikeOut=%v,ScaleX=%v,ScaleY=%v,Spacing=%v,Angle=%v,BorderStyle=%v,Outline=%v,Shadow=%v,Alignment=%v,MarginL=%v,MarginR=%v,MarginV=%v,Encoding=%v'",
		hs.filename, hs.original_size,
		hs.fontName, hs.fontSize,
		hs.primaryColor, hs.secondaryColor, hs.outlineColor, hs.backColor,
		hs.underline, hs.strikeout, hs.scaleX, hs.scalyY, hs.spacing, hs.angle,
		hs.borderStyle, hs.outline, hs.shadow, hs.alignment,
		hs.marginL, hs.marginR, hs.marginV, hs.encoding,
	)
}

type HardsubOption func(*Hardsub)

// WithOriginal_size - set WithOriginal_size
func WithOriginal_size(width, height int) HardsubOption {
	return func(h *Hardsub) {
		h.original_size = fmt.Sprintf("%vx%v", width, height)
	}
}

// WithFont - set WithFont
func WithFontName(value string) HardsubOption {
	return func(h *Hardsub) {
		h.fontName = value
	}
}

// WithFontsize - set WithFontsize
func WithFontSize(value float64) HardsubOption {
	return func(h *Hardsub) {
		h.fontSize = fmt.Sprintf("%v", value)
	}
}

// WithPrimaryColor - set WithPrimaryColor
func WithPrimaryColor(value string) HardsubOption {
	return func(h *Hardsub) {
		h.primaryColor = value
	}
}

// WithSecondaryColor - set WithSecondaryColor
func WithSecondaryColor(value string) HardsubOption {
	return func(h *Hardsub) {
		h.secondaryColor = value
	}
}

// WithOutlineColor - set WithOutlineColor
func WithOutlineColor(value string) HardsubOption {
	return func(h *Hardsub) {
		h.outlineColor = value
	}
}

// WithBackColor - set WithBackColor
func WithBackColor(value string) HardsubOption {
	return func(h *Hardsub) {
		h.backColor = value
	}
}

// WithUnderline - set WithUnderline
func WithUnderline(value string) HardsubOption {
	return func(h *Hardsub) {
		h.underline = value
	}
}

// WithStrikeout - set WithStrikeout
func WithStrikeout(value string) HardsubOption {
	return func(h *Hardsub) {
		h.strikeout = value
	}
}

// WithScaleX - set WithScaleX
func WithScaleX(value string) HardsubOption {
	return func(h *Hardsub) {
		h.scaleX = value
	}
}

// WithScalyY - set WithScalyY
func WithScalyY(value string) HardsubOption {
	return func(h *Hardsub) {
		h.scalyY = value
	}
}

// WithSpacing - set WithSpacing
func WithSpacing(value string) HardsubOption {
	return func(h *Hardsub) {
		h.spacing = value
	}
}

// WithAngle - set WithAngle
func WithAngle(value string) HardsubOption {
	return func(h *Hardsub) {
		h.angle = value
	}
}

// WithBorderStyle - set WithBorderStyle
func WithBorderStyle(value string) HardsubOption {
	return func(h *Hardsub) {
		h.borderStyle = value
	}
}

// WithOutline - set WithOutline
func WithOutline(value string) HardsubOption {
	return func(h *Hardsub) {
		h.outline = value
	}
}

// WithShadow - set WithShadow
func WithShadow(value string) HardsubOption {
	return func(h *Hardsub) {
		h.shadow = value
	}
}

// WithAlignment - set WithAlignment
func WithAlignment(value string) HardsubOption {
	return func(h *Hardsub) {
		h.alignment = value
	}
}

// WithMarginL - set WithMarginL
func WithMarginL(value int) HardsubOption {
	return func(h *Hardsub) {
		h.marginL = fmt.Sprintf("%v", value)
	}
}

// WithMarginR - set WithMarginR
func WithMarginR(value int) HardsubOption {
	return func(h *Hardsub) {
		h.marginR = fmt.Sprintf("%v", value)
	}
}

// WithMarginV - set WithMarginV
func WithMarginV(value int) HardsubOption {
	return func(h *Hardsub) {
		h.marginV = fmt.Sprintf("%v", value)
	}
}

// WithEncoding - set WithEncoding
func WithEncoding(value bool) HardsubOption {
	return func(h *Hardsub) {
		switch value {
		case true:
			h.encoding = "1"
		case false:
			h.encoding = "0"
		}

	}
}

func defaultHardsub() Hardsub {
	return Hardsub{
		filename:       "",
		original_size:  "1920x1080",
		fontName:       "Segoe UI",
		fontSize:       "19.4",
		primaryColor:   "'&H00EBEBEB'",
		secondaryColor: "'&H000000FF'",
		outlineColor:   "'&H00000000'",
		backColor:      "'&H80000000'",
		underline:      "0",
		strikeout:      "0",
		scaleX:         "1",
		scalyY:         "1",
		spacing:        "0",
		angle:          "0",
		borderStyle:    "1",
		outline:        "0.5",
		shadow:         "0",
		alignment:      "2",
		marginL:        "5",
		marginR:        "5",
		marginV:        "40",
		encoding:       "1",
	}
}
