package product

import (
	"fmt"
	"strings"
)

type ScriptWriter struct {
	declarations []string
	filterComlex filterComplex
	mappings     []OutputMapping
}

func (sw *ScriptWriter) ffmpegCommand() string {
	lines := []string{fmt.Sprintf(`ffmpeg \`)}
	for _, declare := range sw.declarations {
		lines = append(lines, fmt.Sprintf(` %v \`, declare))
	}
	lines = append(lines, fmt.Sprintf(`  -filter_complex "%v" \`, sw.filterComlex.String()))
	for _, mapping := range sw.mappings {
		lines = append(lines, fmt.Sprintf(` %v`, mapping.String()))
	}
	return strings.Join(lines, "\n")
}
