package product

import (
	"fmt"

	"github.com/Galdoba/edts/pkg/ump"
)

type Film struct {
	video Video
	audio []Audio
	err   error
}

func NewFilm(path string, opts ...FilmOption) Film {
	flm := Film{}
	fmt.Println("newFilm")
	flm.getDefaultFilmData(path)
	for _, set := range opts {
		set(&flm)
	}
	return flm
}

type FilmOption func(*Film)

func (flm *Film) getDefaultFilmData(path string) {
	flm.video = NewVideo(path, WithProxy(true))
	maps, err := allAudioMappings(path)
	if err != nil {
		flm.err = err
		fmt.Println(flm.err)
		return
	}
	audios, err := allAudios(path, maps)
	if err != nil {
		flm.err = err
		fmt.Println(flm.err)
		return
	}
	flm.audio = audios
}

func allAudioMappings(path string) ([]audioStreamMapping, error) {
	mappings := []audioStreamMapping{}
	mp := ump.NewProfile()
	if err := mp.ConsumeFile(path); err != nil {
		fmt.Println(err)
		return mappings, err
	}
	pos := 0
	for _, stream := range mp.Streams {
		switch stream.Codec_type {
		case ump.CODEC_TYPE_AUDIO:
			foundMapping := AudioStreamMapping(0, pos)
			switch stream.Channels {
			case 1:
				foundMapping = foundMapping.WithLayout("mono")
			case 2:
				foundMapping = foundMapping.WithLayout("stereo")
			case 6:
				foundMapping = foundMapping.WithLayout("5.1")
			}
			fmt.Println(foundMapping)
			mappings = append(mappings, foundMapping)
			pos++
		}
	}
	return mappings, nil
}

func allAudios(path string, mappings []audioStreamMapping) ([]Audio, error) {
	audios := []Audio{}
	n := 0
	layoutMap := layoutMap(mappings)
	//stereo
	for _, mapping := range mappings {
		//panic(mapping.streamLayout)
		if mapping.streamLayout == "stereo" {
			aud := NewAudio([]string{path},
				WithCustomMappings(AudioStreamMapping(0, mapping.streamPosition)),
				WithOutputLayout("20"),
			)
			aud.Language = fmt.Sprintf("%v", n) + "RUS"
			aud.Proxy = true
			audios = append(audios, aud)
			n++
		}
		if mapping.streamLayout == "5.1" {
			aud := NewAudio([]string{path},
				WithCustomMappings(AudioStreamMapping(0, mapping.streamPosition)),
				WithOutputLayout("51"),
			)
			aud.Language = fmt.Sprintf("%v", n) + "RUS"
			aud.Proxy = true
			audios = append(audios, aud)
			n++
		}
	}
	if layoutMap["mono"] == 2 {
		audios = append(audios, extractTwoMono(path, n, mappings))
		n++
	}
	if layoutMap["mono"] == 6 {
		audios = append(audios, extractSixMono(path, n, mappings))
		n++
	}
	if layoutMap["mono"] == 8 {
		audios = append(audios, extractEightMono(path, n, mappings))
		n++
	}
	if layoutMap["mono"] == 2 && layoutMap["stereo"] == 2 {
		audios = append(audios, extractFour51(path, n))
		n++
	}
	//51
	//mono+mono
	//2112
	//11111111
	return audios, nil
}

func layoutMap(mappings []audioStreamMapping) map[string]int {
	layoutMap := make(map[string]int)
	for _, check := range mappings {
		layoutMap[check.streamLayout]++
	}
	return layoutMap
}

func extractTwoMono(path string, n int, mappings []audioStreamMapping) Audio {
	ms := []int{}
	for i, mapping := range mappings {
		if mapping.streamLayout == "mono" {
			ms = append(ms, i)
		}
	}
	aud := NewAudio([]string{path},
		WithCustomMappings(
			AudioStreamMapping(0, ms[0]),
			AudioStreamMapping(0, ms[1]),
		),
		WithOutputLayout("20"),
	)
	aud.Language = fmt.Sprintf("%v", n) + "RUS"
	aud.Proxy = true
	return aud
}

func extractSixMono(path string, n int, mappings []audioStreamMapping) Audio {
	ms := []int{}
	for i, mapping := range mappings {
		if mapping.streamLayout == "mono" {
			ms = append(ms, i)
		}
	}
	aud := NewAudio([]string{path},
		WithCustomMappings(
			AudioStreamMapping(0, ms[0]),
			AudioStreamMapping(0, ms[1]),
			AudioStreamMapping(0, ms[2]),
			AudioStreamMapping(0, ms[3]),
			AudioStreamMapping(0, ms[4]),
			AudioStreamMapping(0, ms[5]),
		),
		WithOutputLayout("51"),
	)
	aud.Language = fmt.Sprintf("%v", n) + "RUS"
	aud.Proxy = true
	return aud
}

func extractEightMono(path string, n int, mappings []audioStreamMapping) Audio {
	ms := []int{}
	found := 0
	for i, mapping := range mappings {
		if mapping.streamLayout == "mono" {
			found++
			if found < 3 {
				continue
			}
			ms = append(ms, i)
		}
	}
	aud := NewAudio([]string{path},
		WithCustomMappings(
			AudioStreamMapping(0, ms[0]),
			AudioStreamMapping(0, ms[1]),
			AudioStreamMapping(0, ms[2]),
			AudioStreamMapping(0, ms[3]),
			AudioStreamMapping(0, ms[4]),
			AudioStreamMapping(0, ms[5]),
		),
		WithOutputLayout("51"),
	)
	aud.Language = fmt.Sprintf("%v", n) + "RUS"
	aud.Proxy = true
	return aud
}

func extractFour51(path string, n int) Audio {
	aud := NewAudio([]string{path},
		WithCustomMappings(
			AudioStreamMapping(0, 0).WithLayout("stereo"),
			AudioStreamMapping(0, 1),
			AudioStreamMapping(0, 2),
			AudioStreamMapping(0, 3).WithLayout("stereo"),
		),
		WithOutputLayout("51"),
	)
	aud.Language = fmt.Sprintf("%v", n) + "RUS"
	aud.Proxy = true
	return aud
}
