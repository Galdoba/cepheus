package product

import (
	"fmt"
	"strings"
)

const (
	TypeVideo     = "Video"
	TypeAudio     = "Audio"
	TypeSubtitles = "Subtitles"
	TypeFilm      = "Film"
	TypeTrailer   = "Trailer"
)

type Product struct {
	OutBase            string
	Destination        string
	Video              Video
	Audio              []Audio
	Subtitles          Subtitle
	ProductRequestType string
	FC                 filterComplex
	Mappings           []OutputMapping
	//control

}

func NewProduct(options ...ProductOption) (Product, error) {
	pr := Product{}
	for _, set := range options {
		set(&pr)
	}
	//defaultFillerFunc
	//validationFunc
	switch pr.ProductRequestType {
	case TypeVideo:
	case TypeFilm:
	case TypeAudio:
		for i, audioRequest := range pr.Audio {
			if len(audioRequest.SourceFiles) == 0 {
				return pr, fmt.Errorf("source files not provided for audio request %v", i)
			}
			if audioRequest.AtempoSettings.initialDuration == 0 {
				initial, err := getAudioDuration(audioRequest.SourceFiles[0])
				if err != nil {
					return pr, fmt.Errorf("audio request initial duration detection failed: %v", err)
				}
				pr.Audio[0].AtempoSettings.initialDuration = initial
			}
			if audioRequest.AtempoSettings.targetDuration == 0 {
				pr.Audio[0].AtempoSettings.targetDuration = pr.Audio[0].AtempoSettings.initialDuration
			}
			if len(audioRequest.InputStreamMappings) == 0 {
				//panic("delaem chto mozhem")
				pr.Audio[0].InputStreamMappings = append(pr.Audio[0].InputStreamMappings, AudioStreamMapping(0, 0))
			}
			//mapping are synced check
			filesUsedMap := make(map[int]bool)
			for _, mapping := range pr.Audio[0].InputStreamMappings {
				filesUsedMap[mapping.fileIndex] = true
				fmt.Println("set", mapping.fileIndex)
				if mapping.fileIndex >= len(pr.Audio[0].SourceFiles) {
					return pr, fmt.Errorf("audio request %v calls mapping for %v files", mapping, len(pr.Audio[0].SourceFiles))
				}
			}
			for i := range pr.Audio[0].SourceFiles {
				if filesUsedMap[i] == false {
					return pr, fmt.Errorf("audio request mappings does not call source %v", i)
				}
			}
		}

	default:
		fmt.Println(pr.ProductRequestType)
		return pr, fmt.Errorf("multiple request type feed")
	}

	return pr, nil
}

func (pr Product) Declarations() []string {
	sources := []string{}
	switch pr.ProductRequestType {
	case TypeVideo, TypeTrailer, TypeFilm:
		sources = append(sources, pr.Video.SourceName)
		for _, hs := range pr.Video.Hardsubs {
			sources = append(sources, hs.filename)
		}
	case TypeAudio:
		for _, aud := range pr.Audio {
			sources = append(sources, aud.SourceFiles...)
		}
	default:
		panic(fmt.Sprintf("unknown product request type: %v", pr.ProductRequestType))
	}

	declarations := []string{}
	for _, source := range sources {
		declarations = append(declarations, fmt.Sprintf("-i /path/to/process/dir/%v ", source))
	}
	return declarations
}

func (pr Product) ToFilterComplex() *filterComplex {
	fcSlice := []*filterComplex{}
	if pr.Video.SourceName != "" {
		fcSlice = append(fcSlice, pr.Video.ToFilterComplex())
	}
	for _, aud := range pr.Audio {
		fcSlice = append(fcSlice, aud.ToFilterComplex())
	}
	return merge(fcSlice...)
}

type ProductOption func(*Product)

func WithVideo(video Video) ProductOption {
	return func(pr *Product) {
		pr.Video = video
		pr.ProductRequestType += TypeVideo
	}
}

func WithAudio(audio ...Audio) ProductOption {
	return func(pr *Product) {
		pr.Audio = audio
		pr.ProductRequestType = strings.TrimPrefix(pr.ProductRequestType, TypeAudio) + TypeAudio
	}
}

func WithSubtitles(subtitles Subtitle) ProductOption {
	return func(pr *Product) {
		pr.Subtitles = subtitles
		pr.ProductRequestType += TypeSubtitles
	}
}

func WithHardsubs(hardsubs ...Hardsub) ProductOption {
	return func(pr *Product) {
		pr.Video.Hardsubs = append(pr.Video.Hardsubs, hardsubs...)
	}
}

func WithOutbase(outbase string) ProductOption {
	return func(pr *Product) {
		pr.OutBase = outbase
	}
}

func WithDestination(dest string) ProductOption {
	return func(pr *Product) {
		pr.Destination = dest
	}
}

func WithFilm(flm Film) ProductOption {
	return func(pr *Product) {
		pr.Video = flm.video
		pr.Audio = flm.audio
		pr.ProductRequestType += TypeFilm
	}
}

func SetMappings(pr Product) []OutputMapping {
	om := []OutputMapping{}
	keys := []string{}
	for _, statement := range pr.FC.statements {
		for _, key := range statement.mapouts {
			if strings.Contains(key, "presplit") {
				continue
			}
			keys = append(keys, key)
		}
	}
	for _, key := range keys {
		om = append(om, createMapping(pr, key))
	}
	return om
}

func createMapping(pr Product, key string) OutputMapping {
	om := defaultMapping(key)
	om.Destination = pr.Destination
	om.OutputName = om.Destination + "/" + pr.OutBase
	if pr.Video.Size != "" {
		om.OutputName += "_" + pr.Video.Size
	}
	if strings.Contains(key, "video") {
		switch pr.Video.Size {
		case "HD":
			om.Crf = 16
		case "4K":
			om.Crf = 18
		}
	}
	if strings.Contains(key, "a") {
		kpts := strings.Split(key, "_")
		kpt0 := strings.TrimPrefix(kpts[0], "a")
		om.OutputName += "_AUDIO" + strings.ToUpper(kpt0)
	}
	if strings.Contains(key, "proxy") {
		om.OutputName += "_" + "proxy"
	}

	om.OutputName += om.Ext
	return om
}
