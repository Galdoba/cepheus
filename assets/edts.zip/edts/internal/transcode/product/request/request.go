package request

import (
	"fmt"
	"slices"

	"github.com/Galdoba/edts/pkg/ump"
)

const (
	templateAudio       = "[0:a:0]"
	templateSubtitles   = "[0:s:0]"
	templateVideo       = "[0:v:0]"
	templateFilmA1      = "[0:a:0][0:v:0]"
	templateFilmA1_20   = "[0:a:0][0:v:0]{2}"
	templateFilmA1_51   = "[0:a:0][0:v:0]{6}"
	templateFilmA2      = "[0:a:0][0:a:1][0:v:0]"
	templateFilmA1_11   = "[0:a:0][0:a:1][0:v:0]{1}{1}"
	templateFilmA2_2020 = "[0:a:0][0:a:1][0:v:0]{2}{2}"
	templateFilmA2_2051 = "[0:a:0][0:a:1][0:v:0]{2}{6}"
	templateFilmA2_5120 = "[0:a:0][0:a:1][0:v:0]{6}{2}"
	templateFilmA2_5151 = "[0:a:0][0:a:1][0:v:0]{6}{6}"
)

type Request struct {
	Type          string   //FILM/video/audio/srt/TRL
	TargetSize    string   //HD/SD/4K
	Sources       []string //paths
	OutBase       string
	Destination   string
	Proxy         bool
	TargetFiles   []string
	ScriptActions []string
}

func New(paths []string, options ...RequestOption) *Request {
	r := Request{}
	r.TargetSize = "HD"
	for _, set := range options {
		set(&r)
	}
	return &r
}

type RequestOption func(*Request)

func Group(paths []string) ump.GroupProfile {
	gmp, _ := ump.CollectGroupInfo(paths...)
	//fmt.Println(err)
	return gmp
}

func VerdictType(gmp ump.GroupProfile) string {
	info := gmp.Info
	keys := []string{}
	for k := range info {
		keys = append(keys, k)
	}

	slices.Sort(keys)
	keySumm := keySum(keys)
	for _, key := range keys {
		//fmt.Println(key, gmp.ChannelLayoutMap[key])
		if info[key].Channels != 0 {
			keySumm += fmt.Sprintf("{%v}", info[key].Channels)
		}
	}

	return keySumm
}

func keySum(keys []string) string {
	s := ""
	for _, key := range keys {
		s += fmt.Sprintf("[%v]", key)
	}
	return s
}

func SortForFFMPEG(paths ...string) []string {
	srt := []string{}
	audio := []string{}
	video := []string{}
	combo := []string{}
	for _, path := range paths {
		if isSubtitle(path) {
			srt = append(srt, path)
		}
		if isAudio(path) {
			audio = append(audio, path)
		}
		if isVideo(path) {
			video = append(video, path)
		}
		if isCombo(path) {
			combo = append(combo, path)
		}
	}
	return nil
}

func isSubtitle(path string) bool {
	mp := ump.NewProfile()
	mp.ConsumeFile(path)
	if len(mp.Streams) != 1 {
		return false
	}
	if mp.Streams[0].Codec_type != ump.CODEC_TYPE_SUBTITLE {
		return false
	}
	return true
}

func isAudio(path string) bool {
	mp := ump.NewProfile()
	mp.ConsumeFile(path)
	if len(mp.Streams) != 1 {
		return false
	}
	if mp.Streams[0].Codec_type != ump.CODEC_TYPE_AUDIO {
		return false
	}
	return true
}

func isVideo(path string) bool {
	mp := ump.NewProfile()
	mp.ConsumeFile(path)
	if len(mp.Streams) != 1 {
		return false
	}
	if mp.Streams[0].Codec_type != ump.CODEC_TYPE_VIDEO {
		return false
	}
	return true
}

func isCombo(path string) bool {
	a, v := false, false
	mp := ump.NewProfile()
	mp.ConsumeFile(path)
	if len(mp.Streams) == 1 {
		return false
	}
	for _, stream := range mp.Streams {
		if stream.Codec_type != ump.CODEC_TYPE_VIDEO {
			v = true
		}
		if stream.Codec_type != ump.CODEC_TYPE_AUDIO {
			a = true
		}
		if v == true && a == true {
			return true
		}
	}

	return false
}
