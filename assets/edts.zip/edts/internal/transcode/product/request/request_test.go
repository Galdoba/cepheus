package request

import (
	"fmt"
	"testing"
)

func TestGroup(t *testing.T) {

	gmp := Group([]string{
		//`\\192.168.31.4\root\IN\_KAPELLA_FILM\_DONE\Soks_luchshiy_drug_semi\SoxAFamilysBestFriend.20PM.wav`,
		`\\192.168.31.4\root\IN\_KAPELLA_FILM\_DONE\Soks_luchshiy_drug_semi\SoxAFamilysBestFriend.HD.20.Rus.mxf`,
	})
	fmt.Println(gmp)
	for k, v := range gmp.Info {
		fmt.Println(k, v)
	}
	fmt.Println(VerdictType(gmp))
}
