package product

import (
	"fmt"
	"path/filepath"
	"strings"

	"github.com/Galdoba/edts/pkg/ump"
)

type Audio struct {
	SourceFiles         []string
	SourceNumbers       []int
	SourcePositions     []int
	InputStreamMappings []audioStreamMapping
	// DurationInitial float64
	// DurationTarget  float64
	AtempoSettings atempoSettings
	Language       string
	Layout         string
	Tag            string
	Proxy          bool
	aresample      int
}

// func NewAudio(initialDur, targetDur float64, options ...AudioOption) Audio {
// 	a := defaultAudio()
// 	a.DurationInitial = initialDur
// 	a.DurationTarget = targetDur
// 	for _, set := range options {
// 		set(&a)
// 	}
// 	return a
// }

type audioSource struct {
	files []string
}

type atempoSettings struct {
	initialDuration float64
	targetDuration  float64
}

type audioFCTagKey struct {
	sourceNum int
	sourcePos int
}

func NewAudio(sources []string, options ...AudioOption) Audio {
	a := defaultAudio()
	a.SourceFiles = sources
	for _, set := range options {
		set(&a)
	}
	return a
}

func filenames(paths ...string) []string {
	sl := []string{}
	for _, path := range paths {
		sl = append(sl, filepath.Base(path))
	}
	return sl
}

func (a Audio) ToFilterComplex() *filterComplex {
	fc := newFC()
	mainKeys := []string{}
	for _, mapping := range a.InputStreamMappings {
		mainKeys = append(mainKeys, fmt.Sprintf("%v:a:%v", mapping.fileIndex, mapping.streamPosition))
	}
	outs := []string{}
	outs = append(outs, strings.ToLower(fmt.Sprintf("a%v%v%v", a.Language, a.Layout, a.Tag+"_main")))
	fc.addStatement(newStatement(
		Keys(mainKeys...),
		Statement(fmt.Sprintf("aresample=%v", a.aresample)),
		Statement(fmt.Sprintf("atempo=(%v/%v)", a.AtempoSettings.initialDuration, a.AtempoSettings.targetDuration)),
		MapOutput(outs...),
	))
	if !a.Proxy {
		return fc
	}
	proxyKey := ""
	for i := range fc.statements[0].mapouts {
		fc.statements[0].mapouts[i] = strings.ReplaceAll(fc.statements[0].mapouts[i], "_main", "_presplit")
		proxyKey = fc.statements[0].mapouts[i]
	}
	fc.addStatement(newStatement(
		Keys(proxyKey),
		Statement("asplit=2"),
		MapOutput(
			strings.ToLower(fmt.Sprintf("a%v%v%v", a.Language, a.Layout, a.Tag+"_main")),
			strings.ToLower(fmt.Sprintf("a%v%v%v", a.Language, a.Layout, a.Tag+"_proxy")),
		),
	))
	return fc

}

type AudioOption func(*Audio)

func defaultAudio() Audio {
	return Audio{
		//Language: "RUS",
		//Layout:    "__",
		aresample: 48000,
	}
}

func WithSources(paths []string) AudioOption {
	return func(a *Audio) {
		for _, path := range paths {
			a.SourceFiles = append(a.SourceFiles, filepath.Base(path))
		}
	}
}

func WithSourceNumbers(snums []int) AudioOption {
	return func(a *Audio) {
		a.SourceNumbers = snums
	}
}

func WithCustomMappings(mappings ...audioStreamMapping) AudioOption {
	return func(a *Audio) {
		a.InputStreamMappings = mappings
	}
}

func WithSourcePositions(sposs []int) AudioOption {
	return func(a *Audio) {
		a.SourcePositions = sposs
	}
}

func WithOutputLayout(layout string) AudioOption {
	return func(a *Audio) {
		a.Layout = layout
	}
}

func getAudioDuration(path string) (float64, error) {
	mp := ump.NewProfile()

	if err := mp.ConsumeFile(path); err != nil {
		return -1, fmt.Errorf("failled to scan file: %v", path)
	}
	for _, stream := range mp.Streams {
		switch stream.Codec_type {
		default:
			continue
		case ump.CODEC_TYPE_AUDIO:
			return stream.DurationSeconds(), nil
		}
	}
	return -1, fmt.Errorf("no audio stream in: %v", path)
}

type audioStreamMapping struct {
	fileIndex      int
	streamPosition int
	streamLayout   string
}

func AudioStreamMapping(fileIndex, streamPosition int) audioStreamMapping {
	return audioStreamMapping{fileIndex: fileIndex, streamPosition: streamPosition}
}

func (asm audioStreamMapping) WithLayout(layout string) audioStreamMapping {
	asm.streamLayout = layout
	return asm
}
