package product

import "fmt"

type filterComplex struct {
	statements []fcStatement
}

type fcStatement struct {
	keys       []string
	statements []string
	mapouts    []string
}

func newFC() *filterComplex {
	return &filterComplex{}
}

func merge(fcSet ...*filterComplex) *filterComplex {
	fcM := newFC()
	for _, fc := range fcSet {
		for _, st := range fc.statements {
			fcM.addStatement(st)
		}
	}
	return fcM
}

func (fc *filterComplex) String() string {
	text := ""
	for n, fc_statement := range fc.statements {
		if n != 0 {
			text += "; "
		}
		////keys
		switch len(fc_statement.keys) {
		case 0:
			text += "[*UNSET*]"
		default:
			for _, key := range fc_statement.keys {
				text += fmt.Sprintf("[%v]", key)
			}
		}
		//statements
		for n, statementText := range fc_statement.statements {
			if n != 0 {
				text += ","
			}
			text += statementText
		}
		//mapout
		switch len(fc_statement.mapouts) {
		case 0:
			text += "[*UNSET*]"
		default:
			for _, key := range fc_statement.mapouts {
				text += fmt.Sprintf("[%v]", key)
			}
		}
	}

	return text
}

func (fc *filterComplex) addStatement(fcSt fcStatement) {
	fc.statements = append(fc.statements, fcSt)
}

func newStatement(values ...StatementValues) fcStatement {
	st := fcStatement{}
	for _, set := range values {
		set(&st)
	}
	return st
}

func appendStatement(fcs fcStatement, newStatement string) fcStatement {
	if newStatement == "" {
		return fcs
	}
	fcs.statements = append(fcs.statements, newStatement)
	return fcs
}

func prependStatement(fcs fcStatement, newStatement string) fcStatement {
	if newStatement == "" {
		return fcs
	}
	fcs.statements = append([]string{newStatement}, fcs.statements...)
	return fcs
}

type StatementValues func(*fcStatement)

func Keys(keys ...string) StatementValues {
	return func(fs *fcStatement) {
		fs.keys = keys
	}
}

func Statement(statement string) StatementValues {
	return func(fs *fcStatement) {
		if statement == "" {
			return
		}
		for _, v := range fs.statements {
			if v == statement {
				return
			}
		}
		fs.statements = append(fs.statements, statement)
	}
}

func MapOutput(mapouts ...string) StatementValues {
	return func(fs *fcStatement) {
		fs.mapouts = append(fs.mapouts, mapouts...)
	}
}
