package product

import (
	"fmt"
	"path/filepath"

	"github.com/Galdoba/edts/pkg/ump"
)

type Video struct {
	SourceNumber   int
	SourceWidth    int
	SourceHeight   int
	SourceName     string
	Size           string
	Crf            int
	Proxy          bool
	NoAudio        bool
	Hardsubs       []Hardsub
	StreamPosition int
	UserRequests   []string
	FilterDecimate int
	FilterYadif    bool
	FilterSetsar   string
	FilterUnsharp  bool
	FilterPad      bool
	Filter_Complex *filterComplex
}

func NewVideo(path string, options ...VideoOption) Video {
	v := defaultVideo()
	v.SourceName = filepath.Base(path)
	videoSize, err := getVideoSize(path)
	if err != nil {
		panic(fmt.Sprintf("не должно быть! %v", err))
	}
	v.SourceWidth = videoSize.width
	v.SourceHeight = videoSize.height
	for _, set := range options {
		set(&v)
	}
	return v
}

func NameFromPath(path string) string {
	return filepath.Base(path)
}

func (v Video) ToFilterComplex() *filterComplex {
	fc := newFC()
	videoStatements := newStatement(Keys(fmt.Sprintf("%v:v:%v", v.SourceNumber, v.StreamPosition)))
	videoStatements = appendStatement(videoStatements, fc_decimate(v))
	videoStatements = appendStatement(videoStatements, fc_scale(&v))
	videoStatements = appendStatement(videoStatements, fc_yadif(v))
	videoStatements = appendStatement(videoStatements, fc_setsar(v))
	videoStatements = appendStatement(videoStatements, fc_unsharp(v))
	videoStatements = appendStatement(videoStatements, fc_pad(v))
	for _, hs := range v.Hardsubs {
		videoStatements = appendStatement(videoStatements, hs.ToFilterComplex())
	}
	switch v.Proxy {
	case false:
		videoStatements.mapouts = []string{"video"}
		fc.addStatement(videoStatements)
	case true:
		videoStatements.mapouts = []string{"video_presplit"}
		fc.addStatement(videoStatements)
		splitStatement := newStatement(Keys("video_presplit"), Statement("split=2"), MapOutput("video", "video_proxy"))
		fc.addStatement(splitStatement)
	}

	return fc
}

type VideoOption func(*Video)

func WithSize(size string) VideoOption {
	return func(v *Video) {
		v.Size = size
	}
}

func WithProxy(proxy bool) VideoOption {
	return func(v *Video) {
		v.Proxy = proxy
	}
}

func NoAudio(noAudio bool) VideoOption {
	return func(v *Video) {
		v.NoAudio = noAudio
	}
}

func WithHardsub(hs Hardsub) VideoOption {
	return func(v *Video) {
		v.Hardsubs = append(v.Hardsubs, hs)
	}
}

func defaultVideo() Video {
	return Video{
		Size: "HD",
		Crf:  16,
	}
}

func fc_decimate(v Video) string {
	if v.FilterDecimate == 0 {
		return ""
	}
	return fmt.Sprintf("decimate=cycle=%v,setpts=N/(25*TB),fps=25", v.FilterDecimate)
}

func fc_scale(v *Video) string {
	switch v.Size {
	case "HD":
		if v.SourceWidth == 3840 && v.SourceHeight == 2160 {
			v.FilterUnsharp = true
			v.FilterPad = true
			return "scale=1920:-2"
		}
		if v.SourceWidth == 1920 && v.SourceHeight == 1080 {
			return ""
		}
		if v.SourceWidth >= 1920 && v.SourceHeight > 800 && v.SourceHeight < 2000 {
			v.FilterUnsharp = true
			v.FilterPad = true
			return "scale=1920:-2"
		}

		return "??scale??"
	default:
		return "??scale??"
	}
}

func fc_yadif(v Video) string {
	if v.FilterYadif {
		return "yadif"
	}
	return ""
}

func fc_setsar(v Video) string {
	if v.FilterSetsar == "" {
		return "setsar=(1/1)"
	}
	return v.FilterSetsar
}

func fc_unsharp(v Video) string {
	if v.FilterUnsharp {
		return "unsharp=3:3:0.3:3:3:0"
	}
	return ""
}

func fc_pad(v Video) string {
	if v.FilterPad {
		switch v.Size {
		case "HD":
			return fmt.Sprintf("pad=1920:1080:-1:-1")
		case "4K":
			return fmt.Sprintf("pad=3840:2160:-1:-1")
		case "SD":
			return fmt.Sprintf("pad=720:576:-1:-1")
		default:
			return fmt.Sprintf("pad=[%v]:[%v]:-1:-1", v.SourceWidth, v.SourceHeight)
		}
	}
	return ""
}

type videoSize struct {
	width  int
	height int
}

func getVideoSize(path string) (videoSize, error) {
	mp := ump.NewProfile()
	vals := []int{}
	if err := mp.ConsumeFile(path); err != nil {
		return videoSize{}, fmt.Errorf("failled to scan file: %v", path)
	}
	for _, stream := range mp.Streams {
		switch stream.Codec_type {
		default:
			continue
		case ump.CODEC_TYPE_VIDEO:
			vals = append(vals, stream.Width, stream.Height)
		}
	}
	switch len(vals) {
	case 0:
		return videoSize{}, fmt.Errorf("no video streams in %v", path)
	case 2:
		return videoSize{width: vals[0], height: vals[1]}, nil
	default:
		return videoSize{}, fmt.Errorf("multiple video streams in %v", path)
	}
}

///mappings
