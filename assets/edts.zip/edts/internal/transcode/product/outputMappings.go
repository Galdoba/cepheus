package product

import (
	"fmt"
	"strings"
)

type OutputMapping struct {
	StreamKey        string
	Type             string
	Destination      string
	OutputName       string
	KillMetadata     bool
	VCodec           string
	Preset           string
	Crf              int
	Pix_Fmt          string
	G                int
	BitRate          int
	MaxBitRate       int
	ACodec           string
	CompressionLevel int
	Ext              string
}

func defaultMapping(key string) OutputMapping {
	om := OutputMapping{}
	om.CompressionLevel = -1
	om.G = -1
	tags := decodeMappingKey(key)
	if tags["video"] == 1 {
		om.VCodec = "libx264"
		om.Preset = "medium"
		om.Crf = 16
		om.Pix_Fmt = "yuv420p"
		om.Ext = ".mp4"
		om.Type = "v"
	}
	if tags["video"] == 1 && tags["proxy"] == 1 {
		om.VCodec = "libx264 -x264opts interlaced=1"
		om.Preset = "superfast"
		om.Crf = 18
		om.Pix_Fmt = "yuv420p"
		om.Ext = ".mp4"
		om.BitRate = 2000
		om.MaxBitRate = 2000
		om.Type = "v"
	}
	if tags["main"] == 1 && tags["a"] >= 1 {
		om.ACodec = "alac"
		om.CompressionLevel = 0
		om.Type = "a"
		om.Ext = ".m4a"
	}
	if tags["proxy"] == 1 && tags["a"] >= 1 {
		om.ACodec = "ac3"
		om.Ext = ".ac3"
		om.BitRate = 128
		om.Type = "a"
	}
	om.StreamKey = key
	om.KillMetadata = true
	return om
}

func (om OutputMapping) String() string {
	s := fmt.Sprintf(`-map "[%v]" `, om.StreamKey)
	switch om.Type {
	case "v":
		s += filtersVideo(om)
	case "a":
		s += filtersAudio(om)
	}
	if om.KillMetadata {
		s += "-map_metadata -1 -map_chapters -1 "
	}
	s += om.OutputName
	return s
}

func filtersVideo(om OutputMapping) string {
	s := ""
	s += fmt.Sprintf("-c:v %v ", om.VCodec)
	s += fmt.Sprintf("-preset %v ", om.Preset)
	s += fmt.Sprintf("-pix_fmt %v ", om.Pix_Fmt)
	s += fmt.Sprintf("-crf %v ", om.Crf)
	if om.G >= 0 {
		s += fmt.Sprintf("-g %v ", om.G)
	}
	if om.BitRate > 0 {
		s += fmt.Sprintf("-b:v %vk ", om.BitRate)
	}
	if om.MaxBitRate > 0 {
		s += fmt.Sprintf("-maxrate %vk ", om.MaxBitRate)
	}
	return s
}

func filtersAudio(om OutputMapping) string {
	s := ""
	s += fmt.Sprintf("-c:a %v ", om.ACodec)
	if om.CompressionLevel >= 0 {
		s += fmt.Sprintf("-g %v ", om.CompressionLevel)
	}
	if om.BitRate > 0 {
		s += fmt.Sprintf("-b:a %vk ", om.BitRate)
	}
	return s
}

/*
  -map "[vidHD]" -c:v libx264 -preset medium -crf 16 -pix_fmt yuv420p -g 0 -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}.mp4  \
  -map "[vidHD_pr]" -c:v libx264 -x264opts interlaced=1 -preset superfast -pix_fmt yuv420p  -b:v 2000k -maxrate 2000k -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}_proxy.mp4  \
  -map "[arus]" -c:a alac -compression_level 0 -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}${AUDIO_OUT1}.m4a \
  -map "[arus_pr]" -c:a ac3 -b:a 128k ${EDIT_PATH}/${OUTBASE}${REV}${AUDIO_OUT1}_proxy.ac3 \
*/

func decodeMappingKey(key string) map[string]int {
	tags := make(map[string]int)
	for _, tag := range []string{"video", "rus", "eng", "20", "51", "_", "main", "proxy", "a"} {
		if strings.Contains(key, tag) {
			tags[tag]++
		}
	}

	return tags
}
