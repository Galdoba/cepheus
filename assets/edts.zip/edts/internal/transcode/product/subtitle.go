package product

type Subtitle struct {
	sourcePath string
}

func NewSubtitle(path string) Subtitle {
	s := defaultSubtitle()
	s.sourcePath = path
	return s
}

func defaultSubtitle() Subtitle {
	return Subtitle{}
}
