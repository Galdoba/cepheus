package transcode

import (
	"strings"
)

const (
	Status_UNKNOWN = iota
	Status_REJECTED
	Status_CLOSED
	Status_UPLOADING
	Status_EDIT_COMPLETE
	Status_IN_EDIT
	Status_READY_TO_EDIT
	Status_WAIT_FOR_SCRIPT
	Status_DOWNLOADING
	Status_PENDING
	Status_IDK
	Status_Not_a_project
)

type SheetRow struct {
	Cells []SheetCell
}

type SheetCell struct {
	Text string
	Note string
}

func (row *SheetRow) IsProject() bool {
	for _, text := range []string{
		row.Cells[8].Text,
		row.Cells[13].Text,
		row.Cells[14].Text,
	} {
		if text == "" {
			return false
		}

	}
	if row.Cells[7].Text != "O" {
		return false
	}
	return true
}

func (row *SheetRow) Status() int {
	status := Status_UNKNOWN
	if row.isHeader() {
		return Status_Not_a_project
	}
	if row.isRejected() {
		return Status_REJECTED
	}
	if row.isClosed() {
		return Status_CLOSED
	}
	if row.isUploading() {
		return Status_UPLOADING
	}
	if row.isEditing() {
		return Status_IN_EDIT
	}
	if row.isReady() {
		return Status_READY_TO_EDIT
	}
	if row.isWaiting() {
		return Status_WAIT_FOR_SCRIPT
	}
	if row.isDownloading() {
		return Status_DOWNLOADING
	}
	if row.isPending() {
		return Status_PENDING
	}
	return status
}

func (row *SheetRow) isClosed() bool {

	sent := false
	for _, v := range []string{"g", "G", "п", "П"} {
		if row.Cells[9].Text == v {
			sent = true
		}
	}

	return sent
}

func (row *SheetRow) isClaimed() bool {
	if strings.Contains(row.Cells[0].Text, strings.ToLower("готовит")) {
		return true
	}
	return false
}

func (row *SheetRow) isPlanned() bool {
	if strings.Contains(row.Cells[0].Text, strings.ToLower("готовит")) {
		return true
	}
	return false
}

func (row *SheetRow) isRejected() bool {
	rejected := false
	for _, v := range []string{"R", "r", "К", "к"} {
		if row.Cells[9].Text == v {
			rejected = true
		}
	}
	return rejected
}

func (row *SheetRow) isUploading() bool {
	done := false
	for _, v := range []string{"g", "G", "п", "П"} {
		if row.Cells[10].Text == v {
			done = true
		}
	}
	sent := false
	for _, v := range []string{"y", "Y", "н", "Н"} {
		if row.Cells[9].Text == v {
			sent = true
		}
	}
	if done && sent {
		return true
	}
	return false
}

func (row *SheetRow) isEditing() bool {
	done := false
	for _, v := range []string{"r", "R", "к", "К"} {
		if row.Cells[10].Text == v {
			done = true
		}
	}
	sent := false
	for _, v := range []string{"y", "Y", "н", "Н"} {
		if row.Cells[9].Text == v {
			sent = true
		}
	}
	if done && sent {
		return true
	}
	return false
}

func (row *SheetRow) isReady() bool {
	done := false
	if row.Cells[1].Text != "" {
		done = true
	}
	sent := false
	for _, v := range []string{"y", "Y", "н", "Н"} {
		if row.Cells[9].Text == v {
			sent = true
		}
	}
	if done && sent {
		return true
	}
	return false
}

func (row *SheetRow) isWaiting() bool {
	done := false
	if row.Cells[1].Text == "" {
		done = true
	}
	sent := false
	for _, v := range []string{"y", "Y", "н", "Н"} {
		if row.Cells[9].Text == v {
			sent = true
		}
	}
	if done && sent {
		return true
	}
	return false
}

func (row *SheetRow) isDownloading() bool {
	downloading := false
	for _, v := range []string{"V", "v", "М", "м"} {
		if row.Cells[9].Text == v {
			downloading = true
		}
	}
	return downloading
}

func (row *SheetRow) isPending() bool {
	if row.Cells[9].Text == "" && row.Cells[10].Text == "" {
		return true
	}
	return false
}

func (row *SheetRow) isHeader() bool {
	if row.Cells[9].Text == "С" && row.Cells[10].Text == "З" {
		return true
	}
	return false
}
