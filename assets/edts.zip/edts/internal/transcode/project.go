package transcode

import (
	"encoding/json"
	"fmt"
	"os"
	"regexp"

	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/db/worksheet"
	"github.com/Galdoba/edts/pkg/translit"
)

type Project struct {
	FileKey                string            `json:"Key"`                           //название для файла проекта
	Title                  string            `json:"Title"`                         //название из таблицы
	Agent                  string            `json:"Agent"`                         //Контрагент из таблицы
	DateBlock              string            `json:"Publication Date"`              //Блок даты/агента из таблицы
	Comment                string            `json:"Comment"`                       //Блок даты/агента из таблицы
	EditingTargetDirectory string            `json:"Editing Target Directory"`      //Блок даты/агента из таблицы
	ProjectType            []string          `json:"Project Type"`                  //тип проекта: фильм/сериал/трейлер
	PossibleBase           []string          `json:"Base Variants"`                 //Возможные названия после транслита
	ConfirmedBase          string            `json:"Confirmed Base"`                //Подтвержденное название после транслита
	Season                 string            `json:"Season,omitempty"`              //сезон (опционально)
	Episode                string            `json:"Episode,omitempty"`             //эпизод (опционально)
	SourceMap              map[string]string `json:"Purpose to Source files"`       //Исходники - что из чего считаем
	EditPath               string            `json:"Product Destination Derictory"` //Куда считаем
	ArchivePath            string            `json:"Source Archive Derictory"`      //Куда складываем исходники после просчета
	PriorityScore          int               `json:"Transcode Priority Score"`      //Приоритет (чем больше тем важнее)
	Status                 int               `json:"Status Code"`
	StatusStr              string            `json:"Status"`
	//	TargetProducts         []*product.ProductRequest `json:"Requested Products"`
}

func NewProject(sheetRow SheetRow) *Project {

	pr := Project{}
	pr.Title = sheetRow.Cells[8].Text
	pr.Agent = sheetRow.Cells[13].Text
	pr.DateBlock = sheetRow.Cells[14].Text
	pr.Comment = sheetRow.Cells[0].Text
	pr.EditingTargetDirectory = sheetRow.Cells[15].Text
	pr.Status = sheetRow.Status()
	pr.StatusStr = pr.SpellStatus()
	editPathSuffix, err := edittingTarget(sheetRow.Cells[15].Text)
	if err != nil {
		fmt.Println(sheetRow)
		panic(err.Error())
	}
	pr.EditingTargetDirectory = editPathSuffix
	pr.FileKey = pr.Key()
	pr.PossibleBase = translit.RenamingVariants(pr.Title, translit.Short_SE_Form())
	return &pr
}

func Load(path string) (*Project, error) {
	bt, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	prj := Project{}
	err = json.Unmarshal(bt, &prj)
	if err != nil {
		return nil, err
	}
	return &prj, nil
}

func ProjectFileKey(sheetRow SheetRow) string {
	title := sheetRow.Cells[8].Text
	dateBlock := sheetRow.Cells[14].Text
	return fmt.Sprintf("%v_%v", translit.String(title, translit.Short_SE_Form()), dateBlock)
}

func (pr *Project) Key() string {
	return fmt.Sprintf("%v_%v", translit.String(pr.Title, translit.Short_SE_Form()), pr.DateBlock)
}

// func (pr *Project) AddRequest(rType string) {
// 	req := product.RequestNew(rType)
// 	req.TargetDestination = pr.EditingTargetDirectory

// 	pr.TargetProducts = append(pr.TargetProducts, req)
// }

func edittingTarget(pubDate string) (string, error) {
	re := regexp.MustCompile(`(\d\d).(\d\d).20(\d\d)`)
	date := re.FindStringSubmatch(pubDate)
	switch pubDate {
	case "Дата публикации", "":
		return "", nil
	}
	switch len(date) {
	case 4:
		return fmt.Sprintf("%v_%v_%v", date[3], date[2], date[1]), nil
	case 0:
		return fmt.Sprintf("_%v", translit.String(pubDate, translit.RegisterLow())), nil
	default:
	}
	return "", fmt.Errorf("invalid publication date field: '%v'", pubDate)
}

const (
	agMark  = "Отметка для правильного считывания таблицы. НЕ УДАЛЯТЬ!!"
	eotMark = "конец таблицы"
)

func SheetRows(database *db.Database) ([]SheetRow, error) {
	localDB, err := database.LoadCopyFromFile()
	if err != nil {
		return nil, err
	}
	rows := []SheetRow{}
	agentMark := false
	eot := false

	//keyMap := make(map[string]int)
	for i := 1; i < 20000; i++ {
		row := SheetRow{}
		for _, column := range []string{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O"} {
			key := fmt.Sprintf("%v%v", column, i)
			cell := worksheet.DB_Cell{}
			err := localDB.ReadStruct(key, &cell)
			if err != nil {
				//return nil, err
			}
			shCell := SheetCell{}
			shCell.Text = cell.Text
			shCell.Note = cell.Note
			if !agentMark && cell.Note == agMark {
				agentMark = true
			}
			if cell.Note == eotMark {
				eot = true
			}

			row.Cells = append(row.Cells, shCell)
		}

		switch agentMark {
		case true:
			row.Cells = append(row.Cells, SheetCell{Text: row.Cells[13].Text})
		case false:
			row.Cells = append(row.Cells, SheetCell{Text: row.Cells[14].Text})
		}
		if eot {
			break
		}
		fmt.Printf("  строк таблицы прочитано: %v\r", len(rows))
		switch isEmpty(row) {
		case true:
			continue
		case false:
			rows = append(rows, row)
			//keyMap[row.Cells[8].Text+" "+row.Cells[14].Text]++
		}
		//fmt.Println(i, row[8].Text, "|")
		//time.Sleep(time.Second)
	}
	if !agentMark {
		//panic("Agent mark was not found")
	}

	// for k, v := range keyMap {
	// 	if v != 1 {
	// 		fmt.Println("")
	// 		fmt.Printf("наименование='%v' встречается %v раза:\n", k, v)
	// 		for i, row := range rows {
	// 			if row.Cells[8].Text+" "+row.Cells[14].Text == k {
	// 				fmt.Printf("строка %v\n", i)
	// 			}
	// 		}
	// 		time.Sleep(time.Second)
	// 	}
	// }
	// panic(000001)
	return rows, nil
}

//Комментарий	Путь	ГТ	Т	Трейлер	П	Постеры	М	Наименование	С	З	О	!	Контрагент	Дата публикации

func isEmpty(shRow SheetRow) bool {
	line := ""
	for _, cellVal := range shRow.Cells {
		line += cellVal.Text + cellVal.Note

	}
	switch line {
	case "":
		return true
	default:
		return false
	}
}

/**/
func (pr *Project) SpellStatus() string {
	switch pr.Status {
	case Status_UNKNOWN:
		return "Хбз"
	case Status_REJECTED:
		return "Отмена"
	case Status_CLOSED:
		return "Закрыт"
	case Status_UPLOADING:
		return "Сдаём"
	case Status_IN_EDIT:
		return "В монтаже"
	case Status_READY_TO_EDIT:
		return "Просчитано"
	case Status_WAIT_FOR_SCRIPT:
		return "Обработка"
	case Status_DOWNLOADING:
		return "Качается"
	case Status_PENDING:
		return "Ждем"
	case Status_IDK:
		return "аще хбз (ошибка?)"
	case Status_Not_a_project:
		return "не проект"
	default:
		panic("WUT???")
	}
}

func StatusString(st int) string {
	switch st {
	case Status_UNKNOWN:
		return "Хбз"
	case Status_REJECTED:
		return "Отмена"
	case Status_CLOSED:
		return "Закрыт"
	case Status_UPLOADING:
		return "Сдаём"
	case Status_IN_EDIT:
		return "В монтаже"
	case Status_READY_TO_EDIT:
		return "Просчитано"
	case Status_WAIT_FOR_SCRIPT:
		return "Обработка"
	case Status_DOWNLOADING:
		return "Качается"
	case Status_PENDING:
		return "Ждем"
	case Status_IDK:
		return "аще хбз (ошибка?)"
	case Status_Not_a_project:
		return "не проект"
	default:
		panic("WUT???")
	}
}
