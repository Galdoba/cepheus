package transcode

import (
	"regexp"
	"strings"

	"github.com/Galdoba/edts/pkg/translit"
)

const (
	editRoot = `//nas/ROOT/EDIT/`
)

func AssumeProjectFile(row SheetRow) string {
	return dateAsPrefix(row.Cells[13].Text) + "_" + translit.String(row.Cells[8].Text)
}

func dateAsPrefix(date string) string {
	re := regexp.MustCompile(`(\d\d).(\d\d).20(\d\d)`)
	dateSeparated := re.FindStringSubmatch(date)
	switch len(dateSeparated) {
	case 4:
		return strings.Join(dateSeparated[1:], ".")
	default:
		panic("bad date: " + date)
	}
}
