package actions

import (
	"context"

	"github.com/Galdoba/logman"
	"github.com/urfave/cli/v3"
)

var EdtsGetProjectData cli.ActionFunc = func(ctx context.Context, c *cli.Command) error {
	logman.Info("start %v action", "edts-get-project-data")
	return nil
}

// func EdtsGetProjectData() cli.ActionFunc {
// 	return func(ctx context.Context, c *cli.Command) error {
// 		logman.Info("start %v action", "edts-get-project-data")
// 		return nil
// 	}
// }
