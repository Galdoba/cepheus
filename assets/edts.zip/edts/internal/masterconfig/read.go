package masterconfig

import (
	"fmt"
	"os"

	"github.com/pelletier/go-toml/v2"
)

func Read(mods ...string) (*MasterConfig, error) {
	bt, err := os.ReadFile(Path(mods...))
	if err != nil {
		return nil, fmt.Errorf("failed to read config path: %v", err)
	}
	cfg := &MasterConfig{}
	if err := toml.Unmarshal(bt, cfg); err != nil {
		return nil, fmt.Errorf("failed to marshal config: %v", err)
	}
	return cfg, nil
}
