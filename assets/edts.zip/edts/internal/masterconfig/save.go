package masterconfig

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/pelletier/go-toml/v2"
)

func Save(cfg *MasterConfig, path string) error {
	dir := filepath.Dir(path)
	os.MkdirAll(dir, 0777)
	btHeader := []byte(Header())
	bt, err := toml.Marshal(cfg)
	if err != nil {
		return err
	}
	os.Remove(path)
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY, 0777)
	if err != nil {
		return err
	}
	bt = append(btHeader, bt...)
	if _, err := f.Write(bt); err != nil {
		return err
	}
	return f.Close()
}

func Header() string {
	return "#####################################################\n" +
		"#                                                   #\n" +
		"#  Файл использует формат сериализации данных TOML. #\n" +
		"#  Спецификации формата можно прочитать по ссылке:  #\n" +
		"#         https://ru.wikipedia.org/wiki/TOML        #\n" +
		"#                                                   #\n" +
		"#####################################################\n"

}

func Load(path string) (*MasterConfig, error) {
	mcfg := &MasterConfig{}
	mcfg.Global_Paths = make(map[string]string)
	mcfg.StartList = make(map[string]bool)
	mcfg.Service_Cooldown = make(map[string]int)
	mcfg.Service_RetryAttempts = make(map[string]int)
	mcfg.Service_RetryDelay_Milliseconds = make(map[string]int)
	mcfg.Service_TrackDirectories = make(map[string][]string)
	mcfg.Service_EventSubscribtions = make(map[string][]string)
	mcfg.Service_Paths = make(map[string]map[string]string)
	mcfg.Service_Values = make(map[string]map[string]string)
	bt, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read config: %v", err)
	}
	err = toml.Unmarshal(bt, &mcfg)
	if err != nil {
		panic("new config is unmarshalable:\n" + err.Error())
	}
	return mcfg, nil
}
