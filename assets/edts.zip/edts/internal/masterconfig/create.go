package masterconfig

import (
	"fmt"
	"os"
	"strings"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/edtspath"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/kval"
	"github.com/Galdoba/edts/pkg/pathfinder"
	"github.com/pelletier/go-toml/v2"
)

const (
	Path_EDTS_IN      = "edts-files-in"
	Path_EDTS_PROCESS = "edts-processing"
	Path_EDTS_DONE    = "edts-done"
	Path_EDTS_OUT     = "edts-files-out"
	Path_EDTS_ARCHIVE = "edts-archive"
	//Path_TEXT_EDITOR  = "text-editor"
	// Path_MEDIA_PLAYER = "media-player"
)

type MasterConfig struct {
	Global_Paths                    map[string]string            `toml:"global paths"`                                          //пути для всех сервисов работающих на этой машине
	Client_File_Associations        map[string]string            `toml:"file associations"`                                     //ассоциации файлов с программами для клиента
	StartList                       map[string]bool              `toml:"start app if not running"`                              //куда отправлять эвенты для консумеров`
	Service_Cooldown                map[string]int               `toml:"execute main action if dormant more than (seconds)"`    //для каждого сервиса: сколько попыток совершить операцию не считается ошибкой
	Service_RetryAttempts           map[string]int               `toml:"do nothing if failed operation atempts is less than"`   //для каждого сервиса: сколько попыток совершить операцию не считается ошибкой
	Service_RetryDelay_Milliseconds map[string]int               `toml:"retry if operation atempt failed after (milliseconds)"` //для каждого сервиса: через какое время повторить попытку
	Service_EventSubscribtions      map[string][]string          `toml:"service event subscribtion lists"`                      //для каждого сервиса: на какие события подписан сервис
	Service_TrackDirectories        map[string][]string          `toml:"service track directories lists"`                       //для каждого сервиса: за какими папками следит сервис
	Service_Paths                   map[string]map[string]string `toml:"service paths"`                                         //для каждого сервиса: какими папками пользуется сервис
	Service_Values                  map[string]map[string]string `toml:"service string values"`                                 //для каждого сервиса: произвольные значения
}

func Path(key ...string) string {
	mod := "master"
	for _, k := range key {
		if k != "" {
			mod = k
		}
	}
	path, err := pathfinder.NewPath(
		pathfinder.IsConfig(),
		pathfinder.WithProgram(definitions.SYSTEM),
		pathfinder.WithFileName(fmt.Sprintf("%v_%v.config", definitions.SYSTEM, mod)),
	)
	if err != nil {
		panic(fmt.Sprintf("path creation failed: %v", err))
	}
	return path
}

func home() string {
	home, err := os.UserHomeDir()
	if err != nil {
		panic(fmt.Sprintf("failed to get user home directory: %v", err))
	}
	home = strings.ReplaceAll(home, `\`, `/`) + "/"
	return home
}

func New(path string) *MasterConfig {
	cfg := MasterConfig{}
	cfg.Global_Paths = globalPathsMap()
	cfg.Client_File_Associations = fileAssociationMap()
	cfg.StartList = startMap()
	cfg.Service_Cooldown = cooldownMap()
	cfg.Service_RetryAttempts = maxAtempts()
	cfg.Service_RetryDelay_Milliseconds = delayAtempts()
	cfg.Service_TrackDirectories = trackedDirectories()
	cfg.Service_EventSubscribtions = subscribtions()
	cfg.Service_Paths = servicePaths()
	cfg.Service_Values = serviceStringValues(&cfg)
	_, err := toml.Marshal(&cfg)
	if err != nil {
		panic("new config is unmarshalable:\n" + err.Error())
	}

	return &cfg
}

func globalPathsMap() map[string]string {
	pathMap := make(map[string]string)
	for _, pathKey := range []string{
		Path_EDTS_IN,
		Path_EDTS_PROCESS,
		Path_EDTS_DONE,
		Path_EDTS_OUT,
		Path_EDTS_ARCHIVE,
		// Path_MEDIA_PLAYER,
		// Path_TEXT_EDITOR,
	} {
		var err error
		pathMap[pathKey], err = kval.Get(pathKey)
		if err != nil {
			panic(fmt.Sprintf("global path error: %v", err))
		}
	}
	return pathMap
}

func fileAssociationMap() map[string]string {
	faMap := make(map[string]string)
	faMap["default"] = "explorer"
	faMap[".jpeg"] = "ffplay"
	faMap[".jpg"] = "ffplay"
	return faMap
}

func cooldownMap() map[string]int {
	cooldownMap := make(map[string]int)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
			cooldownMap[name] = 5
		case definitions.CLIENT_PROJECT_MANAGER:
			cooldownMap[name] = 0
		case definitions.SERVICE_FILENAME_NORMALIZER:
			cooldownMap[name] = 1
		case definitions.SERVICE_SPREADSHEET_TRACKER:
			cooldownMap[name] = 600
		}
	}
	return cooldownMap
}

func startMap() map[string]bool {
	startMap := make(map[string]bool)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
			startMap[name] = true
		}
	}
	return startMap
}

func maxAtempts() map[string]int {
	retryMap := make(map[string]int)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
			retryMap[name] = 100
		case definitions.CLIENT_PROJECT_MANAGER:
			retryMap[name] = 0
		}
	}
	return retryMap
}

func delayAtempts() map[string]int {
	retryMap := make(map[string]int)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
			retryMap[name] = 50
		}
	}
	return retryMap
}

func servicePaths() map[string]map[string]string {
	pathsMap := make(map[string]map[string]string)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
			pathsMap[name] = make(map[string]string)
			pathsMap[name][KEY_INBOX] = edtspath.Inbox(name)
			pathsMap[name][KEY_OUTBOX] = edtspath.Outbox(name)
		case definitions.SERVICE_DIRECTORY_TRACKER, definitions.SERVICE_SPREADSHEET_TRACKER, definitions.CLIENT_PROJECT_MANAGER, definitions.UTILITY_SCRIPT_WRITER:
			pathsMap[name] = make(map[string]string)
			pathsMap[name][KEY_INBOX] = edtspath.Inbox(name)
			pathsMap[name][KEY_OUTBOX] = edtspath.Outbox(name)
			pathsMap[name][KEY_STORAGE] = edtspath.StorageDir(name)
		}
	}
	return pathsMap
}

func serviceStringValues(cfg *MasterConfig) map[string]map[string]string {
	fileMap := make(map[string]map[string]string)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
		case definitions.SERVICE_DIRECTORY_TRACKER:
			fileMap[name] = make(map[string]string)
			fileMap[name][KEY_DB_FILEPATH] = cfg.Service_Paths[name][KEY_STORAGE] + "directories_data.json"
		case definitions.SERVICE_SPREADSHEET_TRACKER:
			fileMap[name] = make(map[string]string)
			fileMap[name][Key_Credentials_file] = home() + `.credentials/tablegrabber.json`
			fileMap[name][KEY_DB_FILEPATH] = cfg.Service_Paths[name][KEY_STORAGE] + "spreadsheet_data.json"
			fileMap[name][Key_Spreadsheet_ID] = "1Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg"
			fileMap[name][Key_Spreadsheet_Name] = "График работ 2.0"
		case definitions.UTILITY_SCRIPT_WRITER:
			fileMap[name] = make(map[string]string)
			fileMap[name][KEY_EXEC_DIR] = globalPathsMap()[Path_EDTS_IN]
			fileMap[name][KEY_SOURCE_DIR] = cfg.Service_Paths[definitions.CLIENT_PROJECT_MANAGER][KEY_STORAGE]
		}
	}
	return fileMap
}

func subscribtions() map[string][]string {
	subscribtions := make(map[string][]string)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
		case definitions.SERVICE_FILENAME_NORMALIZER:
			subscribtions[name] = []string{events.FILE_CREATED}
		case definitions.SERVICE_SPREADSHEET_TRACKER:
			subscribtions[name] = []string{events.WORKSHEET_FETCH_REQUSTED, events.WORKSHEET_WRITE_REQUSTED}
		case definitions.CLIENT_PROJECT_MANAGER:
			subscribtions[name] = []string{events.WORKSHEET_UPDATED}

		}
	}
	return subscribtions
}

func trackedDirectories() map[string][]string {
	trackedDirectories := make(map[string][]string)
	for _, name := range definitions.AppsList() {
		switch name {
		default:
		case definitions.SERVICE_DIRECTORY_TRACKER:
			for key, dir := range globalPathsMap() {
				switch key {
				case Path_EDTS_IN, Path_EDTS_PROCESS, Path_EDTS_DONE:
					trackedDirectories[name] = append(trackedDirectories[name], dir)
				}
			}
		case definitions.SERVICE_FILENAME_NORMALIZER:
			for key, dir := range globalPathsMap() {
				switch key {
				case Path_EDTS_IN:
					trackedDirectories[name] = append(trackedDirectories[name], dir)
				}
			}

		}
	}
	return trackedDirectories
}
