package masterconfig

const (
	KEY_INBOX            = "inbox"
	KEY_OUTBOX           = "outbox"
	KEY_STORAGE          = "storage"
	KEY_DB_FILEPATH      = "db_filepath"
	KEY_EXEC_DIR         = "exec_directory"
	KEY_SOURCE_DIR       = "source_directory"
	Key_Credentials_file = "credentials_file"
	Key_Spreadsheet_ID   = "spreadsheet_id"
	Key_Spreadsheet_Name = "spreadsheet_name"
)
