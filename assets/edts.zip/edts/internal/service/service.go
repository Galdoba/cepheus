package service

import (
	"fmt"
	"os"
	"time"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/masterconfig"
	"github.com/Galdoba/edts/pkg/action"
	"github.com/Galdoba/edts/pkg/atempted"
	"github.com/Galdoba/edts/pkg/events"
	"github.com/Galdoba/edts/pkg/events/payload"
	"github.com/Galdoba/edts/pkg/pathfinder"
)

type Service struct {
	Name            string
	MainAction      *action.Action
	ReactionActions map[string]*action.Action
	Inbox           string
	Outbox          string
	SubscribedTo    []string
	ArgsMap         map[string]string
	ActiveEvent     events.Event
	Config          *masterconfig.MasterConfig
}

type Action struct {
	Function         func(events.Event, ...interface{}) error
	Triggers         []string
	Cooldown_Seconds float64
}

func New(name string, mainAction *action.Action, options ...ServiceOption) *Service {
	srv := Service{}
	srv.Name = name
	srv.MainAction = mainAction
	settings := defaultServiceOpt()
	for _, modify := range options {
		modify(&settings)
	}
	srv.ReactionActions = settings.reactionActions
	srv.ArgsMap = settings.stringsContext
	srv.Config = settings.config
	srv.Inbox = srv.Config.Service_Paths[srv.Name][masterconfig.KEY_INBOX]
	srv.Outbox = srv.Config.Service_Paths[srv.Name][masterconfig.KEY_OUTBOX]

	return &srv
}

func (srv *Service) AddReaction(key string, act *action.Action) error {
	srv.ReactionActions[key] = act
	return nil
}

var failcount int

func (srv *Service) Run() error {
	lastActionTime := time.Now().Add(-1 * time.Hour)
	for {
		//COOLDOWN ACTION
		if srv.MainAction.Cooldown_Seconds > 0 {
			done, err := srv.MainAction.ExecByCooldown(time.Since(lastActionTime))
			if done {
				lastActionTime = time.Now()
				continue
			}
			if err != nil {
				fmt.Println("failed to act:", srv.MainAction.Name, err)
				return err
			}
		}
		//EXPLORE INBOX EVENTS
		if srv.MainAction.Cooldown_Seconds <= 0 {
			time.Sleep(time.Millisecond * 100)
		}
		switch len(srv.ReactionActions) {
		case 0:
			continue
		default:
		}
		eventMap, errors := events.ReadSubscribtions(srv.Name, srv.Inbox)
		for _, err := range errors {
			fmt.Println(err)
		}
		switch len(eventMap) {
		case 0:
			time.Sleep(time.Millisecond * 100)
		default:
			for path, ev := range eventMap {
				done, err := srv.react(ev)
				switch err {
				case nil:
				default:
					if err.Error() == ErrIgnore.Error() {
						fmt.Printf("ignore event: %v\n", ev)
						done = true
						panic(9)
					}
					fmt.Printf("failed to react: %v\n", err)
					if errPublish := events.PublishNewEvent("unexpected_service_error", payload.String("error", err.Error()), payload.String("event_path", path)); errPublish != nil {
						s := fmt.Sprintf("failed to publish:\n err: %v", err)
						fmt.Println("publish err:", errPublish)
						panic(s)
					}
					failcount++
					time.Sleep(10 * time.Second)
					if failcount > 999 {
						panic("failcount 1000")
					}
					continue
				}

				switch done {
				case true:
					lastActionTime = time.Now()
					//fmt.Printf("event processed: %v\n", events.Filename(ev))
					if err := os.Remove(path); err == nil {
						delete(eventMap, path)
					}
				case false:
					fmt.Println("nor done, nor error???", done, err)
				}

			}
		}

	}
	fmt.Println("end")
	return fmt.Errorf("endless loop broken")
}

var ErrIgnore = fmt.Errorf("ignore event")

func (srv *Service) react(ev events.Event) (bool, error) {
	srv.ActiveEvent = ev
	for _, reaction := range srv.ReactionActions {
		triggered := false
		for _, trigger := range reaction.Triggers {
			if trigger == srv.ActiveEvent.Type() {
				triggered = true
			}
		}
		if triggered {
			return reaction.ExecByTrigger(ev)
		}
	}
	return false, nil
}

// func listEvents(dir string) []events.Event {
// 	eventList := []events.Event{}
// 	fi, err := os.ReadDir(dir)
// 	if err != nil {
// 		fmt.Println(err)
// 		return nil
// 	}
// 	if len(fi) == 0 {
// 		return nil
// 	}
// 	for _, f := range fi {
// 		e, err := events.Read(dir + f.Name())
// 		if err != nil {
// 			fmt.Println("failed to read event '%v': %v", f.Name(), err)
// 			continue
// 		}
// 		eventList = append(eventList, e)
// 	}
// 	return eventList
// }

type ServiceOption func(*serviceOpt)

type serviceOpt struct {
	reactionActions map[string]*action.Action
	inbox           string
	outbox          string
	stringsContext  map[string]string
	config          *masterconfig.MasterConfig
}

func defaultServiceOpt() serviceOpt {
	so := serviceOpt{}
	so.reactionActions = make(map[string]*action.Action)
	so.stringsContext = make(map[string]string)
	so.config = &masterconfig.MasterConfig{}
	return so
}

func WithReactiveAction(eventType string, act *action.Action) ServiceOption {
	return func(so *serviceOpt) {
		so.reactionActions[eventType] = act
	}
}

func WithConfig(cfg *masterconfig.MasterConfig) ServiceOption {
	return func(so *serviceOpt) {
		so.config = cfg
	}
}

func WithArg(key, val string) ServiceOption {
	return func(so *serviceOpt) {
		so.stringsContext[key] = val
	}
}

func WithInbox(inboxes string) ServiceOption {
	return func(so *serviceOpt) {
		so.inbox = inboxes
	}
}

func WithOutbox(outbox string) ServiceOption {
	return func(so *serviceOpt) {
		so.outbox = outbox
	}
}

// prep
func (srv *Service) ConnectEventPaths() error {
	path, err := pathfinder.NewPath(
		pathfinder.WithSystem(definitions.SYSTEM),
		pathfinder.WithProgram(srv.Name),
		pathfinder.WithLayers([]string{"events", "inbox"}),
		pathfinder.EnsureExistiance(),
	)
	if err != nil {
		return fmt.Errorf("inbox not connected: %v", err)
	}
	srv.Inbox = path
	path, err = pathfinder.NewPath(
		pathfinder.WithSystem(definitions.SYSTEM),
		pathfinder.WithProgram(srv.Name),
		pathfinder.WithLayers([]string{"events", "outbox"}),
		pathfinder.EnsureExistiance(),
	)
	if err != nil {
		return fmt.Errorf("inbox not connected: %v", err)
	}
	srv.Outbox = path
	srv.SubscribedTo = events.Subscribtions(srv.Name)
	events.SetupPublisher(srv.Name, srv.Outbox)
	//events.SetOutbox(srv.Outbox)
	//events.SetInbox(srv.SubscribedTo)
	return nil
}

// 0
func (srv *Service) ReadInbox() ([]string, error) {
	fi, err := atempted.ReadDir(srv.Inbox)
	if err != nil {
		return nil, fmt.Errorf("failed to read inbox: %v")
	}
	files := []string{}
	for _, f := range fi {
		files = append(files, f.Name())
	}
	return files, nil
}

// 1
// func (srv *Service) ReadEvent0(file string) events.Event {
// 	ev, err := events.Read(srv.Inbox + file)
// 	if err != nil {
// 		fmt.Println("event not confirmed:", err)
// 	}

// 	return ev
// }

func (srv *Service) ReadEvent(file string) map[string]string {
	ev, err := events.Read(srv.Inbox + file)
	if err != nil {
		fmt.Println("event not confirmed:", err)
	}

	return ev
}

// 2
func (srv *Service) IsSubscribed(ev events.Event) bool {
	signature := ev.Signature()
	if signature == "" {
		panic(fmt.Sprintf("event '%v' is not signed"))
	}
	for _, sub := range srv.SubscribedTo {
		if sub == signature {
			return true
		}
	}
	return false
}

// 3
func (srv *Service) HasReaction(ev events.Event) bool {
	if _, ok := srv.ReactionActions[ev.Type()]; ok {
		return true
	}
	return false
}

// 4
func (srv *Service) React(ev events.Event, args ...interface{}) error {
	return srv.ReactionActions[ev.Type()].Function(args...)
}

// 5
func (srv *Service) Publish(eventType string, data ...payload.PayloadData) error {
	return events.PublishNewEvent(eventType, data...)
}

// 6
func (srv *Service) DeleteFile(filename string) error {
	return atempted.Remove(srv.Inbox + filename)
}
