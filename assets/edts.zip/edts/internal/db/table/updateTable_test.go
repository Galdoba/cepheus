package table

import (
	"fmt"
	"testing"
)

func TestWDBcreate(t *testing.T) {
	tableID := "1Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg"
	tableName := "График работ 2.0"
	path := `c:/Users/pemaltynov/Programs/galdoba/edts/edts-spreadsheet-tracker-service/tableData.json`
	wdb, err := WDBcreate(`C:/Users/pemaltynov/.credentials/tablegrabber.json`)
	if err != nil {
		panic(err.Error())
	}
	fmt.Println("created")
	if err := wdb.FetchFromSpreadsheet(tableID, tableName); err != nil {
		panic(err.Error())
	}
	fmt.Println("fetch")
	if err := wdb.WriteToFile(path); err != nil {
		panic(err.Error())
	}
	fmt.Println("written")

}
