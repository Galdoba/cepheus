package table

import (
	"encoding/json"
	"fmt"
	"os"
)

type TableFileInfo struct {
	TableID         string `json:"TableID"`
	TabName         string `json:"TabName"`
	CredentialsPath string `json:"CredentialsPath"`
}

func generate() {
	tfi := TableFileInfo{}
	tfi.TableID = "1Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg"
	tfi.CredentialsPath = `c:/Users/pemaltynov/.credentials/tablegrabber.json`
	tfi.TabName = "График работ 2.0"

	bt, err := json.MarshalIndent(&tfi, "", "  ")
	fmt.Println(err)
	fmt.Println(string(bt))
}

func GetFromFile(path string) (*TableFileInfo, error) {
	fmt.Println(path)
	tfi := TableFileInfo{}
	bt, err := os.ReadFile(path)
	fmt.Println(string(bt))
	if err != nil {
		return nil, fmt.Errorf("failed to read file: %v", err)
	}
	if err := json.Unmarshal(bt, &tfi); err != nil {
		return nil, fmt.Errorf("failed to unmarshal from file: %v", err)
	}
	return &tfi, nil
}
