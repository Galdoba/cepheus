package table

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/Galdoba/edts/pkg/atempted"
	"golang.org/x/oauth2/google"
	"gopkg.in/Iwark/spreadsheet.v2"
)

type DB_Worksheet struct {
	LastUpdate time.Time   `json:"Last Updated"`
	SheetData  *SheetModel `json:"Model"`
	buffer     []byte
	filepath   string
	service    *spreadsheet.Service
	sheet      *spreadsheet.Sheet
	tableInfo  *TableFileInfo
}

func (wdb *DB_Worksheet) String() string {
	bt, err := json.Marshal(&wdb)
	if err != nil {
		panic(fmt.Sprintf("failed to marshal db: %v", err))
	}
	return string(bt)
}

func (wdb *DB_Worksheet) Unstring(str string) error {
	bt := []byte(str)
	err := json.Unmarshal(bt, wdb)
	if err != nil {
		return fmt.Errorf("failed to unmarshal table: %v", err)
	}
	return err
}

func WDBcreate(credentialsPath string) (*DB_Worksheet, error) {
	wdb := DB_Worksheet{}
	service, err := initService(credentialsPath)
	if err != nil {
		return nil, err
	}
	wdb.service = service
	return &wdb, nil
}

func initService(credentials string) (*spreadsheet.Service, error) {
	credData, err := os.ReadFile(credentials)
	if err != nil {
		return nil, fmt.Errorf("failed to read credetinals: %v", err)
	}
	conf, err := google.JWTConfigFromJSON(credData, spreadsheet.Scope)
	if err != nil {
		return nil, fmt.Errorf("failed to create service configuration: %v", err)
	}
	client := conf.Client(context.TODO())
	service := spreadsheet.NewServiceWithClient(client)

	return service, nil
}

func (wdb *DB_Worksheet) FetchFromSpreadsheet(tableID, tableName string) error {
	spreadsheet, err := wdb.service.FetchSpreadsheet(tableID)
	if err != nil {
		return fmt.Errorf("failed to fetch spreadsheet: %v", err)
	}
	sheet, err := spreadsheet.SheetByTitle(tableName) //sheetTitle
	if err != nil {
		return fmt.Errorf("failed to get sheet by title: %v", err)
	}
	sheetModel := &SheetModel{}
	for _, row := range sheet.Rows {
		rowModel := RowData{}
		for _, cell := range row {
			rowModel.Append(NewCell(cell.Value, cell.Note))
		}
		sheetModel.Append(&rowModel)
	}
	wdb.SheetData = sheetModel
	wdb.LastUpdate = time.Now()
	return nil
}

func (wdb *DB_Worksheet) WriteToFile(path string) error {
	if err := atempted.Rename(path, path+".tmp"); err != nil {
		return fmt.Errorf("failed to save back up file: %v", err)
	}
	f, err := atempted.Create(path)
	if err != nil {
		return fmt.Errorf("failed to create new db file: %v", err)
	}
	bt, err := json.Marshal(&wdb)
	if err != nil {
		return fmt.Errorf("failed to marshal db: %v", err)
	}
	_, err = f.Write(bt)
	if err != nil {
		return fmt.Errorf("failed to write db to file: %v", err)
	}
	os.Remove(path + ".tmp")
	return nil
}
