package ent1

import (
	"encoding/json"
	"fmt"
)

type T1E struct {
	Stats  map[string]int `json:"Characteristics"`
	Stats2 int            `json:"Number 2"`
	Stats3 string         `json:"TEXT"`
}

func (t1 *T1E) MarshalJSON() ([]byte, error) {
	type U *T1E
	tNew := U(t1)
	tNew.Stats = t1.Stats
	tNew.Stats2 = t1.Stats2
	tNew.Stats3 = t1.Stats3
	bt, err := json.MarshalIndent(*tNew, "", "  ")
	if err != nil {
		return nil, fmt.Errorf("failed to marshal *T1E struct: %v", err)
	}
	return bt, err
}

func (t1 *T1E) UnmarshalJSON(data []byte) error {
	type Ent *T1E
	tNew := Ent(t1)
	tNew.Stats = t1.Stats
	tNew.Stats2 = t1.Stats2
	tNew.Stats3 = t1.Stats3
	if err := json.Unmarshal(data, tNew); err != nil {
		return fmt.Errorf("failed to unmarshal *T1E struct: %v", err)
	}
	return nil
}

type T2E struct {
	Param string   `json:"Parameter"`
	Arr   []string `json:"Parameter Array,omitempty"`
}

func NewT1() *T1E {
	t1 := T1E{}
	t1.Stats = make(map[string]int)
	return &t1
}

func (t1 *T2E) MarshalJSON() ([]byte, error) {
	type U *T2E
	tNew := U(t1)
	tNew.Param = t1.Param
	tNew.Arr = t1.Arr
	bt, err := json.MarshalIndent(*tNew, "", "  ")
	if err != nil {
		return nil, fmt.Errorf("failed to marshal *T2E struct: %v", err)
	}
	return bt, nil
}

func (t1 *T2E) UnmarshalJSON(data []byte) error {
	type Ent *T2E
	tNew := Ent(t1)
	tNew.Param = t1.Param
	tNew.Arr = t1.Arr
	err := json.Unmarshal(data, tNew)
	if err != nil {
		return fmt.Errorf("failed to unmarshal: %v", err)
	}
	if len(t1.Arr) != 0 {
		return nil
	}
	if t1.Param != "" {
		return nil
	}
	return fmt.Errorf("*T2E was unmarshaled as zero value")
}
