package testdb

import (
	"encoding/json"
	"fmt"

	"github.com/Galdoba/edts/internal/db/testdb/ent1"
)

type Database struct {
	Name       string           `json:"Db NAME"`
	LastAction string           `json:"LAST ACTION"`
	Payload    map[string]Entry `json:"Entries"`
	Stats      int              `json:"Entry Number"`
}

type Entry interface {
	json.Marshaler
	json.Unmarshaler
}

func Create() *Database {
	db := Database{}
	db.Name = ""
	db.LastAction = ""
	db.Stats = 42
	db.Payload = make(map[string]Entry)
	for i := 0; i < 30; i++ {
		key := fmt.Sprintf("key %v", i)
		db.Payload[key] = &ent1.T1E{
			Stats: map[string]int{
				key + "aa": i,
			},
			Stats2: i * 2,
		}
		i += 13
	}
	return &db
}

func (db *Database) String() string {
	bt, err := json.MarshalIndent(db, "", "  ")
	if err != nil {
		panic(err.Error())
	}
	return string(bt)
}

func (db *Database) Update(key string, ent Entry) error {
	db.Payload[key] = ent
	return nil
}

func (db *Database) Read(key string) ([]byte, error) {
	if v, ok := db.Payload[key]; ok {
		return v.MarshalJSON()
	}
	return []byte{}, fmt.Errorf("no entry ith key '%v'", key)
}

func (db *Database) ReadBytes(key string) []byte {
	if v, ok := db.Payload[key]; ok {
		bt, err := v.MarshalJSON()
		if err != nil {
			return []byte{}
		}
		return bt
	}
	return []byte{}
}

func (db *Database) ReadStruct(key string, str Entry) error {
	if v, ok := db.Payload[key]; ok {
		bt, err := v.MarshalJSON()
		if err != nil {
			return fmt.Errorf("failed to marshal entry: %v", err)
		}
		if err := str.UnmarshalJSON(bt); err != nil {
			return fmt.Errorf("failed to unmarshal entry to struct: %v", err)
		}
		return nil
	}
	return fmt.Errorf("no entry with key '%v'", key)
}
