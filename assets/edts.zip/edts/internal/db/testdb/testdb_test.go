package testdb

import (
	"fmt"
	"testing"

	"github.com/Galdoba/edts/internal/db/testdb/ent1"
)

func TestCreate(t *testing.T) {
	db := Create()
	//fmt.Println(db.String())
	t1 := &ent1.T2E{}
	if err := db.ReadStruct("key 14", t1); err != nil {
		fmt.Println(err)
	}
	t1.Param = "i was read"
	db.Update("key 14c", t1)

	fmt.Println(db.String())
}
