package db

import (
	"encoding/json"
	"fmt"
	"os"
	"regexp"
	"strings"
	"time"

	"github.com/Galdoba/edts/internal/db/worksheet"
	"github.com/Galdoba/edts/internal/definitions"
	"github.com/Galdoba/edts/internal/structs/filedata"
)

const (
	TYPE_FILEDATA    = "directory"
	TYPE_SPREADSHEET = "worksheet"
)

type Database struct {
	Path    string           `json:"Filepath"`
	Comment string           `json:"Comment,omitempty"`
	Payload map[string]Entry `json:"Entries"`
	Event   string           `json:"Last event"`
}

type Entry interface {
	json.Marshaler
	json.Unmarshaler
}

// Create - preapares Database struct
func Create(path string, comment string) *Database {
	db := Database{}
	db.Comment = comment
	db.Path = path
	db.Payload = make(map[string]Entry)
	return &db
}

func (db *Database) Read(key string) ([]byte, error) {
	if _, ok := db.Payload[key]; !ok {
		return nil, fmt.Errorf("no entry with key '%v'", key)
	}
	bt, err := db.Payload[key].MarshalJSON()
	if err != nil {
		return nil, err
	}
	db.Event = fmt.Sprintf("read entry with key '%v' at %v", key, time.Now().Format(time.DateTime))
	return bt, nil
}

func (db *Database) Update(key string, ent Entry) error {
	if db.Payload == nil {
		return fmt.Errorf("database payload is not set")
	}
	db.Payload[key] = ent
	db.Event = fmt.Sprintf("updated entry with key '%v' at %v", key, time.Now().Format(time.DateTime))
	return nil
}

func (db *Database) Delete(key string) error {
	delete(db.Payload, key)
	db.Event = fmt.Sprintf("deleted entry by key %v at %v", key, time.Now().Format(time.DateTime))
	return nil
}

func (db *Database) Save() error {
	if err := os.Rename(db.Path, db.Path+".tmp"); err != nil {
		return fmt.Errorf("failed to save backup file: %v", err)
	}

	bt, err := json.MarshalIndent(db, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal data: %v", err)
	}
	f, err := os.Create(db.Path)
	defer f.Close()
	if err != nil {
		return fmt.Errorf("failed to create database file: %v", err)
	}

	if _, err := f.Write(bt); err != nil {
		return fmt.Errorf("failed to write database file: %v", err)
	}
	return nil
}

func (db *Database) LoadCopyFromFile() (*Database, error) {
	dbCopy := Database{}
	dbCopy.Path = db.Path
	dbCopy.Comment = db.Comment
	dbCopy.Event = "aaa"

	dbCopy.Payload = make(map[string]Entry)

	bt, err := os.ReadFile(db.Path)
	if err != nil {
		return nil, fmt.Errorf("failed to read database: %v", err)
	}
	keys, values := []string{}, []Entry{}
	switch db.Comment {
	case TYPE_FILEDATA:
		keys, values = listFiledata(bt)
	case TYPE_SPREADSHEET:
		keys, values = listCelldata(bt)
		//dbCopy.Workdsheet = make(map[string]*table.DB_Worksheet)
	}
	for i, key := range keys {
		dbCopy.Payload[key] = values[i]
	}

	return &dbCopy, nil
}

func listFiledata(bt []byte) ([]string, []Entry) {
	outKeys := []string{}
	outValues := []Entry{}
	keys, vals, err := ripNested2(bt)
	if err != nil {
		panic("1 " + err.Error())
	}
	for i, key := range keys {
		fd := &filedata.Filedata{}
		err = fd.UnmarshalJSON([]byte(vals[i]))
		if err != nil {
			panic("2 " + err.Error())
		}
		outKeys = append(outKeys, key)
		outValues = append(outValues, fd)
		//dbCopy.Payload[key] = fd
	}
	return outKeys, outValues
}

func listCelldata(bt []byte) ([]string, []Entry) {
	outKeys := []string{}
	outValues := []Entry{}
	keys, vals, err := ripNested2(bt)
	if err != nil {
		panic("1 " + err.Error())
	}
	for i, key := range keys {
		cellData := &worksheet.DB_Cell{}
		cellData.UnmarshalJSON([]byte(vals[i]))
		//в данном случае пустое значение допустимо
		outKeys = append(outKeys, key)
		outValues = append(outValues, cellData)
	}
	return outKeys, outValues
}

func (db *Database) ReadStruct(key string, str Entry) error {
	if key == "" {
		return nil
	}
	if v, ok := db.Payload[key]; ok {
		bt, err := v.MarshalJSON()
		if err != nil {
			return fmt.Errorf("failed to marshal entry: %v", err)
		}
		if err := str.UnmarshalJSON(bt); err != nil {
			return fmt.Errorf("failed to unmarshal entry to struct: %v", err)
		}
		return nil
	}
	return fmt.Errorf("no entry with key '%v'", key)
}

func ripNested2(bt []byte) ([]string, []string, error) {
	keys, vals := []string{}, []string{}
	text := string(bt)
	text = strings.ReplaceAll(text, "\n", "|")
	re := regexp.MustCompile("(\"Entries\": {)(.*)(}.*})")
	found := re.FindStringSubmatch(text)
	for i, f := range found {
		switch i {
		case 2:
			f = strings.ReplaceAll(f, "|", "\n")
			f := strings.ReplaceAll(f, "},\n", "}||")
			blocks := strings.Split(f, "||")
			for _, bl := range blocks {
				if bl == "" {
					continue
				}
				key, val, err := ripKeyVal(bl)
				keys = append(keys, key)
				vals = append(vals, val)
				if err != nil {
					panic(err.Error())
				}
			}
		}
	}
	return keys, vals, nil
}

func ripKeyVal(str string) (string, string, error) {
	str = strings.ReplaceAll(str, "\n", "")
	reg2 := regexp.MustCompile(`"(.*)": ([{].*[}])`)
	subs := reg2.FindStringSubmatch(str)
	if len(subs) != 3 {
		fmt.Println("subs:", subs)
		return "", "", fmt.Errorf("failed to parse")
	}

	return subs[1], subs[2], nil
}

func Worksheet() *Database {
	return Create(definitions.TableDB_Path, TYPE_SPREADSHEET)
}
