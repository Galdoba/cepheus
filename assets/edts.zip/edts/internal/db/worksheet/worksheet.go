package worksheet

import (
	"encoding/json"
	"fmt"
	"time"
)

type DB_Worksheet struct {
	LastUpdate time.Time   `json:"Last Updated"`
	SheetData  *SheetModel `json:"Model"`
}

type SheetModel struct {
	Rows []*RowData `json:"Spreadsheet"`
}

type RowData struct {
	Cell []*CellContent `json:"Row"`
}

type CellContent struct {
	Text string `json:"Value"`
	Note string `json:"Note,omitempty"`
}

func (wdb *DB_Worksheet) String() string {
	bt, err := json.Marshal(&wdb)
	if err != nil {
		panic(fmt.Sprintf("failed to marshal db: %v", err))
	}
	return string(bt)
}

func (wdb *DB_Worksheet) Unstring(str string) error {
	bt := []byte(str)
	err := json.Unmarshal(bt, wdb)
	if err != nil {
		return fmt.Errorf("failed to unmarshal table: %v", err)
	}
	return err
}

type DB_Cell struct {
	Text string `json:"Value"`
	Note string `json:"Note,omitempty"`
}

func (t1 *DB_Cell) MarshalJSON() ([]byte, error) {
	type U *DB_Cell
	tNew := U(t1)
	tNew.Text = t1.Text
	tNew.Note = t1.Note
	bt, err := json.MarshalIndent(*tNew, "", "  ")
	if err != nil {
		return nil, fmt.Errorf("failed to marshal *DB_Cell struct: %v", err)
	}
	return bt, nil
}

func (t1 *DB_Cell) UnmarshalJSON(data []byte) error {
	type Ent *DB_Cell
	tNew := Ent(t1)
	tNew.Text = t1.Text
	tNew.Note = t1.Note
	err := json.Unmarshal(data, tNew)
	if err != nil {
		return fmt.Errorf("failed to unmarshal: %v", err)
	}
	if t1.Text != "" {
		return nil
	}
	return fmt.Errorf("*DB_Cell was unmarshaled as zero value")
}
