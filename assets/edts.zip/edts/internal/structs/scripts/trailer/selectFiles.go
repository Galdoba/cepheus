package main

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/internal/structs/userinput"
	"github.com/Galdoba/edts/internal/transcode"
)

func SelectFile(dir string) (string, error) {
	files := []string{}
	fi, err := os.ReadDir(dir)
	if err != nil {
		return "no input", err
	}
	for _, f := range fi {
		if f.IsDir() {
			continue
		}
		files = append(files, f.Name())
	}
	return userinput.SelectString(userinput.Title("исходный файл:"), userinput.Options(files...)), nil
}

func TrailerNames(spreadsheet []transcode.SheetRow) []string {
	names := []string{}
	for _, row := range spreadsheet {
		cell := row.Cells[3]
		if !isRed(cell.Text) {
			continue
		}
		names = append(names, row.Cells[8].Text)
	}
	return names
}

func SelectTrailerProject(spreadsheet []transcode.SheetRow) (string, error) {
	names := []string{}
	for _, row := range spreadsheet {
		cell := row.Cells[3]
		if !isRed(cell.Text) {
			continue
		}
		names = append(names, row.Cells[8].Text)

	}
	if len(names) == 0 {
		return "", fmt.Errorf("no trailer ready projects found")
	}
	return userinput.SelectString(userinput.Title("ghjtrn"), userinput.Options(names...)), nil
}

func isRed(cellText string) bool {
	switch cellText {
	case "R", "r", "К", "к":
		return true
	}
	return false
}

func Files(dir string) ([]string, error) {
	fi, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("немогу прочитать директорию %v: %v", dir, err)
	}
	files := []string{}
	for _, f := range fi {
		if f.IsDir() {
			continue
		}
		files = append(files, f.Name())
	}
	if len(files) == 0 {
		return nil, fmt.Errorf("нет доступных файлов в %v", dir)
	}
	return files, nil
}
