package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"github.com/Galdoba/edts/cmd/edts-client/commands/client/helpers"
	"github.com/Galdoba/edts/internal/db"
	"github.com/Galdoba/edts/internal/structs/scriptmaker"
	"github.com/Galdoba/edts/internal/structs/userinput"
	"github.com/Galdoba/edts/internal/transcode"
)

const (
	BUFFER  = `//192.168.31.4/buffer/IN/`
	EDIT    = `//nas/ROOT/EDIT/`
	ARCHIVE = `//192.168.31.4/root/IN/`
	NO_KEY  = `[НИЧТО ИЗ ПЕРЕЧИСЛЕННОГО]`
)

type TrailerScriptBuilder struct {
	Type              string
	Priority          int
	InputDirectory    string
	TargetDirectory   string
	ArchiveDirectory  string
	InputFileName     string
	OutBaseName       string
	AF_Aresample      int
	VF_Scale          string
	VF_Unsharp        string
	VF_Pad            string
	VF_Setsar         string
	FPS               float64
	Languages         map[string]string
	Layout            map[string]string
	tableData         []transcode.SheetRow
	projects          map[string]*transcode.Project
	activeProject     *transcode.Project
	projectCandidates []string
	projectKey        string
	inputCandidates   []string
	mainFile          string
	hardSubFiles      []string
	subtitleFiles     []string
	audioFiles        []string
}

func main() {
	tsb, err := NewScript()
	fmt.Println(err)
	fmt.Println(len(tsb.tableData))

}

func NewScript() (TrailerScriptBuilder, error) {
	tsb := TrailerScriptBuilder{}
	fmt.Println("Загружаю контекстные данные...")
	tsb.projects = make(map[string]*transcode.Project)
	if err := tsb.loadContextData(); err != nil {
		return tsb, err
	}
	tsb.InputDirectory = BUFFER
	fmt.Println("Данные загружены")
	fmt.Println("Опрашиваю пользователя:")

	tsb.Type = userinput.SelectString(userinput.Title("Выбери тип скрипта"), userinput.Options("фильм", "трейлер"))
	fmt.Println("Тип скрипта:", tsb.Type)

	inputCandidates, err := Files(tsb.InputDirectory)
	if err != nil {
		return TrailerScriptBuilder{}, err
	}
	tsb.inputCandidates = userinput.SelectStringMulti(userinput.Title("Выбери исходник(-и)"), userinput.Options(inputCandidates...))
	if len(tsb.inputCandidates) == 0 {
		return TrailerScriptBuilder{}, fmt.Errorf("Исходные файлы не выбраны. Завершаю работу.")
	}
	fmt.Println("Исходные файлы:")
	for _, fn := range tsb.inputCandidates {
		fmt.Println("  -", fn)
	}

	projNames := []string{}
	for _, pr := range tsb.projects {
		projNames = append(projNames, pr.Title)
	}

	slices.Sort(projNames)
	projNames = append(projNames, NO_KEY)
	tsb.projectKey = userinput.SelectString(userinput.Title("Выбери проект"), userinput.Options(projNames...))
	if tsb.projectKey == NO_KEY {
		fmt.Println("Проект не выбран. Завершаю работу.")
		return TrailerScriptBuilder{}, fmt.Errorf("Проект не выбран. Завершаю работу.")
	}
	fmt.Println("Проект:", tsb.projectKey)

	for _, pr := range tsb.projects {
		if pr.Title == tsb.projectKey {
			tsb.activeProject = pr

		}
	}
	fmt.Println("Агент:", tsb.activeProject.Agent)
	tsb.OutBaseName = tsb.activeProject.ConfirmedBase
	if tsb.OutBaseName == "" {
		tsb.OutBaseName = userinput.SelectString(userinput.Title("Выбери основу имени для просчитанных файлов"), userinput.Options(tsb.activeProject.PossibleBase...))
		tsb.activeProject.ConfirmedBase = tsb.OutBaseName
	}
	fmt.Println("Основа имени выходных файлов:", tsb.OutBaseName)
	switch tsb.Type {
	case "трейлер":
		tsb.TargetDirectory = filepath.Join(`//192.168.31.4/root/EDIT/@trailers_temp/`)
		fmt.Println("Путь просчета:", tsb.TargetDirectory)
		tsb.ArchiveDirectory = filepath.Join(`//192.168.31.4/root/IN/@TRAILERS/_DONE/`, tsb.OutBaseName)
		fmt.Println("Путь архива:", tsb.activeProject.ArchivePath)
	case "фильм":
		edit, archive := helpers.OutPaths(tsb.activeProject)
		tsb.TargetDirectory = strings.Join([]string{EDIT, edit}, "")
		tsb.ArchiveDirectory = strings.Join([]string{ARCHIVE, archive}, "")
		fmt.Println("Путь просчета:", tsb.TargetDirectory)
		fmt.Println("Путь архива:", tsb.ArchiveDirectory)
	}
	tsb.Type = strings.ReplaceAll(tsb.Type, "фильм", "FLM")
	tsb.Type = strings.ReplaceAll(tsb.Type, "трейлер", "TRL")
	sr := scriptmaker.New(
		scriptmaker.InputFiles(tsb.InputDirectory+tsb.inputCandidates[0]),
		scriptmaker.Destination(tsb.TargetDirectory),
		scriptmaker.OutBase(tsb.OutBaseName),
		scriptmaker.ScriptType(tsb.Type),
	)
	if err := sr.Make(); err != nil {
		fmt.Println(err)
	}
	fmt.Println("Скрипт:")
	fmt.Println(sr.Script())

	return tsb, nil
}

func (tsb *TrailerScriptBuilder) loadContextData() error {
	//Read Dir
	stDir := `c:/Users/pemaltynov/Programs/galdoba/edts/edts-client/storage/`
	fi, err := os.ReadDir(`c:/Users/pemaltynov/Programs/galdoba/edts/edts-client/storage/`)
	if err != nil {
		return fmt.Errorf("failed to read project directory: %v", err)
	}
	prMap := make(map[string]*transcode.Project)
	for _, f := range fi {
		name := f.Name()
		if !strings.HasSuffix(name, ".json") {
			fmt.Println("not a json")
			continue
		}
		pr := transcode.Project{}
		bt, err := os.ReadFile(stDir + name)
		if err != nil {
			return fmt.Errorf("failed to read project file: %v", err)
		}
		if err := json.Unmarshal(bt, &pr); err != nil {
			return fmt.Errorf("failed to unmarshal project file: %v", err)
		}
		prMap[pr.Title+pr.DateBlock] = &pr
		fmt.Printf("  данные проектов        : %v\r", len(prMap))
	}
	tsb.projects = prMap
	fmt.Printf("\n")
	sheetRows, err := transcode.SheetRows(db.Worksheet())
	if err != nil {
		return fmt.Errorf("failed to read spreadsheet db: %v", err)
	}
	tsb.tableData = sheetRows
	fmt.Println("")
	return nil
}
