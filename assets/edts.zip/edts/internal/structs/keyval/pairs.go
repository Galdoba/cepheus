package keyval

type StringPair struct {
	Key   string
	Value string
}

func PairStrings(key, value string) StringPair {
	return StringPair{
		Key:   key,
		Value: value,
	}
}
