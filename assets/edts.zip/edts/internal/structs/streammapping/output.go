package streammapping

import (
	"fmt"
	"strings"
)

const (
	ST_VIDEO      = "video"
	ST_AUDIO      = "audio"
	ST_SUBS       = "subtitles"
	SIZE_SD       = "sd"
	SIZE_HD       = "hd"
	SIZE_4K       = "4k"
	LAYOUT_STEREO = "20"
	LAYOUT_51     = "51"
	LAYOUT_ANY    = "xx"
	PROXY         = "proxy"
)

type OutputStream struct {
	inputs     []InputStream
	StreamType string
	Index      int
	Layout     string
	WithProxy  bool
	WithHS     bool
	Tags       []string
}

func (o *OutputStream) String() string {
	body := o.StreamType
	size := ""
	for _, tag := range o.Tags {
		if strings.Contains(tag, "hd") {
			size = "hd"
		}
		if strings.Contains(tag, "4k") {
			size = "4k"
		}
	}
	switch body {
	default:
		return "undefined_output_stream"
	case ST_VIDEO:
		body = fmt.Sprintf("%v_%v", body, indexString(o.Index))
		switch size {
		default:
			body += "_" + size
		case "":
		}
	case ST_AUDIO:
		body = fmt.Sprintf("%v_%v_%v", body, indexString(o.Index), o.Layout)
	}
	if o.WithHS {
		body = fmt.Sprintf("%v_hs", body)
	}
	switch o.WithProxy {
	case true:
		return fmt.Sprintf("[%v][%v_proxy]", body, body)
	default:
		return fmt.Sprintf("[%v]", body)
	}
}

func (o *OutputStream) Inputs() string {
	return fmt.Sprintf("%v", strings.Join(ListInputMaps(o.inputs...), ""))
}

func (o *OutputStream) Bridge() (string, string) {
	return fmt.Sprintf("%v", strings.Join(ListInputMaps(o.inputs...), "")), o.String()
}

func (o *OutputStream) OutMapsSeparated() []string {
	complex := []string{fmt.Sprintf("%v", strings.Join(ListInputMaps(o.inputs...), "")), o.String()}
	out := []string{}
	for _, comp := range complex {
		parts := strings.Split(comp, "][")
		switch len(parts) {
		case 1:
			out = append(out, comp)
		case 2:
			out = append(out, parts[0]+"]")
			out = append(out, "["+parts[1])
		}
	}
	return out
}

func indexString(i int) string {
	s := fmt.Sprintf("%v", i)
	if len(strings.Split(s, "")) < 2 {
		s = "0" + s
	}
	return s
}

func outputPosibilities(inputs ...InputStream) []string {

	posibilities := []string{}
	posibilities = append(posibilities, videoPosibilities(inputs...)...)
	posibilities = append(posibilities, audioPosibilities(inputs...)...)
	return posibilities
}

func videoPosibilities(inputs ...InputStream) []string {
	streamsByType := make(map[string]int)
	streamsByLayout := make(map[string]int)
	for _, stream := range inputs {
		streamsByType[stream.StreamType]++
		streamsByLayout[stream.ChannelLayout]++
	}
	posibilities := []string{}
	if streamsByType["v"] > 0 {
		posibilities = append(posibilities, ST_VIDEO)
	}
	if streamsByType["v"] > 0 && streamsByType["s"] > 0 {
		posibilities = append(posibilities, ST_VIDEO+"_hs")
	}
	return posibilities
}

func audioPosibilities(inputs ...InputStream) []string {
	streamsByType := make(map[string]int)
	streamsByLayout := make(map[string]int)
	streamsByFile := make(map[string]int)
	for _, stream := range inputs {
		streamsByType[stream.StreamType]++
		streamsByLayout[stream.ChannelLayout]++
		streamsByFile[stream.Path]++
	}
	posibilities := []string{}
	if streamsByLayout["mono"] == 2 && streamsByLayout["stereo"] == 2 {
		posibilities = append(posibilities, ST_AUDIO+"_merge_2112")
		if len(streamsByFile) == 1 {
			return posibilities
		}
	}
	if streamsByLayout["mono"] >= 6 {
		posibilities = append(posibilities, ST_AUDIO+"_merge_6_mono")
	}
	if streamsByLayout["mono"] == 2 && streamsByLayout["stereo"] == 0 && streamsByLayout["5.1"] == 0 {
		posibilities = append(posibilities, ST_AUDIO+"_merge_2_mono")
	}
	if streamsByLayout["stereo"] >= 1 {
		posibilities = append(posibilities, ST_AUDIO+"_"+LAYOUT_STEREO)
	}
	if streamsByLayout["5.1"] >= 1 {
		posibilities = append(posibilities, ST_AUDIO+"_"+LAYOUT_51)
	}

	return posibilities
}

func layoutToMapping(layout string) string {
	switch layout {
	case "5.1":
		return LAYOUT_51
	case "stereo":
		return LAYOUT_STEREO
	default:
		return fmt.Sprintf("{unpammed:%v}", layout)
	}
}

func Tags(outs ...OutputStream) []string {
	tags := []string{}
	for _, stream := range outs {
		tags = appendUnique(tags, stream.Tags...)
	}
	return tags
}

func OutMaps(streams []OutputStream) []string {
	out := []string{}
	for _, stream := range streams {
		_, o := stream.Bridge()
		out = append(out, o)
	}
	return out
}

func InputFilePaths(streams []OutputStream) []string {
	paths := []string{}
	for _, stream := range streams {
		for _, in := range stream.inputs {
			paths = appendUnique(paths, in.Path)
		}
	}
	return paths
}
