package streammapping

import (
	"testing"
)

func TestAssess(t *testing.T) {
	// fmt.Println("Assess test")
	// outs, err := Assess(
	// 	InputFiles(
	// 		// `\\192.168.31.4\root\IN\@TRAILERS\_DONE\Vse_vremya_na_svete_TRL\VVNS_trailer_MASTER.mov`,
	// 		// `\\192.168.31.4\root\IN\@TRAILERS\_DONE\Vse_v_polnom_poryadke_s01_TRL\Vse_v_polnom_poryadke_A-teka.mp4`,
	// 		`\\192.168.31.4\root\IN\@TRAILERS\_DONE\Titanik_nepotoplyaemaya_mechta_TRL\Unsinkable_TRL_HD23_RU51.mov`,
	// 	),
	// 	ProductType(ProdType_TRL),
	// )
	// if err != nil {
	// 	fmt.Println(err)
	// 	return
	// }
	// tags := Tags(outs...)

	// fc := filtercomplex.WithFilterCalls(filtercomplex.OptionSetByTags(tags...)...)
	// fc_str := fc.String()
	// for _, out := range outs {
	// 	ins, outs := out.Bridge()
	// 	if strings.Contains(outs, "video") {
	// 		fc_str = strings.ReplaceAll(fc_str, "[unmapped_video_in]", ins)
	// 		fc_str = strings.ReplaceAll(fc_str, "[unmapped_video_out]", outs)
	// 	}
	// 	if strings.Contains(outs, "audio") {
	// 		fc_str = strings.ReplaceAll(fc_str, "[unmapped_audio_in]", ins)
	// 		fc_str = strings.ReplaceAll(fc_str, "[unmapped_audio_out]", outs)
	// 	}
	// 	fmt.Println(out.Tags)
	// }
	// for _, inputFile := range InputFilePaths(outs) {
	// 	fmt.Printf("-i %v \n", inputFile)
	// }

	// fmt.Println(fc_str)

	// fmt.Println(OutMaps(outs))
}
