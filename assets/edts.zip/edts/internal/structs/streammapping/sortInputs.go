package streammapping

import (
	"fmt"
	"slices"

	"github.com/Galdoba/edts/internal/probe"
	"github.com/Galdoba/edts/pkg/ump"
)

func assessInputs(paths ...string) ([]InputStream, error) {
	mappedStreamData := make(map[string][]probe.StreamInfo)
	for _, path := range paths {
		streams, err := probe.Streams(path)
		if err != nil {
			return nil, fmt.Errorf("failed to collect steam data: %v", err)
		}
		mappedStreamData[path] = streams
	}
	indexed, err := sortByTypeorder(paths, mappedStreamData)
	if err != nil {
		return nil, fmt.Errorf("failed to set paths indexes: %v", err)
	}
	inpStreams := []InputStream{}
	for i, indexPath := range indexed {
		for _, stream := range mappedStreamData[indexPath] {
			input := InputStream{
				Path:           indexPath,
				FileIndex:      i,
				StreamType:     mapTag(stream.Codec),
				StreamPosition: stream.Position,
				ChannelLayout:  layoutString(stream.Codec, stream.Channels),
				Width:          stream.Width,
				Height:         stream.Height,
				Fps:            stream.Fps,
			}
			inpStreams = append(inpStreams, input)
		}
	}

	return inpStreams, nil
}

func layoutString(codec string, channels int) string {
	switch codec {
	case ump.CODEC_TYPE_VIDEO, ump.CODEC_TYPE_SUBTITLE:
		return codec
	default:
		return "data"
	case ump.CODEC_TYPE_AUDIO:
	}
	switch channels {
	case 0:
		return "none"
	case 1:
		return "mono"
	case 2:
		return "stereo"
	case 6:
		return "5.1"
	default:
		return fmt.Sprintf("%vch", channels)
	}
}

func mapTag(codecType string) string {
	switch codecType {
	case ump.CODEC_TYPE_VIDEO:
		return "v"
	case ump.CODEC_TYPE_AUDIO:
		return "a"
	case ump.CODEC_TYPE_SUBTITLE:
		return "s"
	}
	return "x"
}

func sortByTypeorder(paths []string, mappedStreamData map[string][]probe.StreamInfo) ([]string, error) {
	indexed := []string{}
	slices.Sort(paths)
	if len(paths) != len(mappedStreamData) {
		return nil, fmt.Errorf("unmapped paths detected")
	}
	//first order: files with video
	for _, path := range paths {
		for _, stream := range mappedStreamData[path] {
			if stream.Codec == ump.CODEC_TYPE_VIDEO && stream.SameCodecTypeInFile >= 0 {
				indexed = appendUnique(indexed, path)
				break
			}
		}
	}
	//second order: files with audio only
	for _, path := range paths {
	files:
		for _, stream := range mappedStreamData[path] {
			switch stream.Codec {
			default:
				continue files
			case ump.CODEC_TYPE_AUDIO:
				if stream.SameCodecTypeInFile == 1 {
					indexed = appendUnique(indexed, path)
					continue files
				}

			}
		}
	}
	//third order: files with subtitles only
	for _, path := range paths {
		for _, stream := range mappedStreamData[path] {
			switch stream.Codec {
			default:
				break
			case ump.CODEC_TYPE_SUBTITLE:
				if stream.SameCodecTypeInFile > 0 {
					indexed = appendUnique(indexed, path)
					break
				}
			}
		}
	}
	if len(indexed) != len(paths) {
		return nil, fmt.Errorf("files with indefined order detected")
	}
	return indexed, nil
}

func appendUnique[T any](slice []T, elements ...T) []T {
	for _, element := range elements {
		switch sliceContains(slice, element) {
		case true:
		case false:
			slice = append(slice, element)
		}
	}
	return slice
}

func sliceContains[T any](slice []T, element T) bool {
	for _, inSlice := range slice {
		if fmt.Sprintf("%v", element) == fmt.Sprintf("%v", inSlice) {
			return true
		}
	}
	return false
}
