package streammapping

import (
	"fmt"
	"math"
)

type InOutBridge struct {
	Ins         []InputStream
	Out         OutputStream
	ProcessTags []string
}

func MappingCandidates(inputs []InputStream, tags ...string) ([]OutputStream, []OutputStream, error) {
	vidCand := candidatesAudio(inputs, tags...)
	audCand := candidatesAudio(inputs, tags...)
	return vidCand, audCand, nil
}

func candidatesVideo(inputs []InputStream, tags ...string) []OutputStream {
	//	streamsTotal := len(inputs)
	inputList := ListInputMaps(inputs...)
	output := []OutputStream{}
	asmap := inputSliceToMap(inputs)
	for _, stream := range inputs {
		if stream.StreamType == "v" && wideMatch(inputList, []string{stream.String()}) {
			out := OutputStream{
				inputs:     []InputStream{asmap[stream.String()]},
				StreamType: ST_VIDEO,
				Index:      stream.StreamPosition,
				Layout:     "",
				WithProxy:  wideMatch(tags, []string{"proxy"}),
				WithHS:     false,
			}
			tag := detectScale(stream)
			if tag != "" {
				out.Tags = append(out.Tags, tag)
			}
			out.Tags = append(out.Tags, fmt.Sprintf("%v_fps", stream.Fps))
			output = append(output, out)
		}
	}
	return output
}

var merge_2m = []string{"[0:a:0]", "[0:a:1]"}
var merge_2112 = []string{"[0:a:0]", "[0:a:1]", "[0:a:2]", "[0:a:3]"}
var merge_6ms = []string{"[0:a:0]", "[0:a:1]", "[0:a:2]", "[0:a:3]", "[0:a:4]", "[0:a:5]"}
var merge_6me = []string{"[0:a:2]", "[0:a:3]", "[0:a:4]", "[0:a:5]", "[0:a:6]", "[0:a:7]"}
var merge_6m1 = []string{"[0:a:0]", "[1:a:0]", "[2:a:0]", "[3:a:0]", "[4:a:0]", "[5:a:0]"}
var merge_6m2 = []string{"[1:a:0]", "[2:a:0]", "[3:a:0]", "[4:a:0]", "[5:a:0]", "[6:a:0]"}

func candidatesAudio(inputs []InputStream, tags ...string) []OutputStream {
	//	streamsTotal := len(inputs)
	inputList := ListInputMaps(inputs...)
	asMap := inputSliceToMap(inputs)
	output := []OutputStream{}

	//merge_2112
	if allTrue(
		wideMatch(inputList, merge_2112),
		asMap["[0:a:0]"].ChannelLayout == "stereo",
		asMap["[0:a:1]"].ChannelLayout == "mono",
		asMap["[0:a:2]"].ChannelLayout == "mono",
		asMap["[0:a:3]"].ChannelLayout == "stereo",
	) {
		output = append(output, OutputStream{
			inputs:     []InputStream{asMap["[0:a:0]"], asMap["[0:a:1]"], asMap["[0:a:2]"], asMap["[0:a:3]"]},
			StreamType: ST_AUDIO,
			Index:      len(output),
			Layout:     LAYOUT_51,
			WithProxy:  wideMatch(tags, []string{"proxy"}),
			WithHS:     false,
			Tags:       []string{"amerge_2112"},
		})
	}
	//merge_6me
	if allTrue(
		wideMatch(inputList, merge_6ms),
		asMap["[0:a:2]"].ChannelLayout == "mono",
		asMap["[0:a:3]"].ChannelLayout == "mono",
		asMap["[0:a:4]"].ChannelLayout == "mono",
		asMap["[0:a:5]"].ChannelLayout == "mono",
		asMap["[0:a:6]"].ChannelLayout == "mono",
		asMap["[0:a:7]"].ChannelLayout == "mono",
	) {
		output = append(output, OutputStream{
			inputs:     []InputStream{asMap["[0:a:2]"], asMap["[0:a:3]"], asMap["[0:a:4]"], asMap["[0:a:5]"], asMap["[0:a:6]"], asMap["[0:a:7]"]},
			StreamType: ST_AUDIO,
			Index:      len(output),
			Layout:     LAYOUT_51,
			WithProxy:  wideMatch(tags, []string{"proxy"}),
			WithHS:     false,
			Tags:       []string{"amerge_6", "internal_merge"},
		})
	}

	//merge_6ms
	if allTrue(
		wideMatch(inputList, merge_6ms),
		len(output) == 0,
		asMap["[0:a:0]"].ChannelLayout == "mono",
		asMap["[0:a:1]"].ChannelLayout == "mono",
		asMap["[0:a:2]"].ChannelLayout == "mono",
		asMap["[0:a:3]"].ChannelLayout == "mono",
		asMap["[0:a:4]"].ChannelLayout == "mono",
		asMap["[0:a:5]"].ChannelLayout == "mono",
	) {
		output = append(output, OutputStream{
			inputs:     []InputStream{asMap["[0:a:0]"], asMap["[0:a:1]"], asMap["[0:a:2]"], asMap["[0:a:3]"], asMap["[0:a:4]"], asMap["[0:a:5]"]},
			StreamType: ST_AUDIO,
			Index:      len(output),
			Layout:     LAYOUT_51,
			WithProxy:  wideMatch(tags, []string{"proxy"}),
			WithHS:     false,
			Tags:       []string{"amerge_6", "internal_merge"},
		})
	}

	//merge_6m1
	if allTrue(
		wideMatch(inputList, merge_6m1),
		len(output) == 0,
		asMap["[0:a:0]"].ChannelLayout == "mono",
		asMap["[1:a:0]"].ChannelLayout == "mono",
		asMap["[2:a:0]"].ChannelLayout == "mono",
		asMap["[3:a:0]"].ChannelLayout == "mono",
		asMap["[4:a:0]"].ChannelLayout == "mono",
		asMap["[5:a:0]"].ChannelLayout == "mono",
	) {
		output = append(output, OutputStream{
			inputs:     []InputStream{asMap["[0:a:0]"], asMap["[1:a:0]"], asMap["[2:a:0]"], asMap["[3:a:0]"], asMap["[4:a:0]"], asMap["[5:a:0]"]},
			StreamType: ST_AUDIO,
			Index:      len(output),
			Layout:     LAYOUT_51,
			WithProxy:  wideMatch(tags, []string{"proxy"}),
			WithHS:     false,
			Tags:       []string{"amerge_6", "external_merge"},
		})
	}
	//merge_6m1
	if allTrue(
		wideMatch(inputList, merge_6m1),
		len(output) <= 1,
		asMap["[1:a:0]"].ChannelLayout == "mono",
		asMap["[2:a:0]"].ChannelLayout == "mono",
		asMap["[3:a:0]"].ChannelLayout == "mono",
		asMap["[4:a:0]"].ChannelLayout == "mono",
		asMap["[5:a:0]"].ChannelLayout == "mono",
		asMap["[6:a:0]"].ChannelLayout == "mono",
	) {
		output = append(output, OutputStream{
			inputs:     []InputStream{asMap["[1:a:0]"], asMap["[2:a:0]"], asMap["[3:a:0]"], asMap["[4:a:0]"], asMap["[5:a:0]"], asMap["[6:a:0]"]},
			StreamType: ST_AUDIO,
			Index:      len(output),
			Layout:     LAYOUT_51,
			WithProxy:  wideMatch(tags, []string{"proxy"}),
			WithHS:     false,
			Tags:       []string{"amerge_6", "external_merge"},
		})
	}
	//merge_2m
	if allTrue(
		wideMatch(inputList, merge_2m),
		len(output) == 0,
		asMap["[0:a:0]"].ChannelLayout == "mono",
		asMap["[0:a:1]"].ChannelLayout == "mono",
	) {
		output = append(output, OutputStream{
			inputs:     []InputStream{asMap["[0:a:0]"], asMap["[0:a:1]"]},
			StreamType: ST_AUDIO,
			Index:      len(output),
			Layout:     LAYOUT_STEREO,
			WithProxy:  wideMatch(tags, []string{"proxy"}),
			WithHS:     false,
			Tags:       []string{"amerge_stereo", "internal_merge"},
		})
	}
	if len(output) == 0 {
		for _, stream := range inputs {
			switch stream.ChannelLayout {
			case "5.1", "stereo":
				output = append(output, OutputStream{
					inputs:     []InputStream{asMap[stream.String()]},
					StreamType: ST_AUDIO,
					Index:      len(output),
					Layout:     layoutToMapping(stream.ChannelLayout),
					WithProxy:  wideMatch(tags, []string{"proxy"}),
					WithHS:     false,
					Tags:       []string{"direct mapping"},
				})
			}
		}
	}

	return output
}

func ListInputMaps(streams ...InputStream) []string {
	sl := []string{}
	for _, stream := range streams {
		sl = append(sl, stream.String())
	}
	return sl
}

func wideMatch(wide []string, narrow []string) bool {
	if len(narrow) > len(wide) {
		return false
	}
	for i, e := range narrow {
		if !foundInSlice(wide[i:], e) {
			return false
		}
	}
	return true
}

func foundInSlice(sl []string, elem string) bool {
	for _, s := range sl {
		if s == elem {
			return true
		}
	}
	return false
}

func inputSliceToMap(inputs []InputStream) map[string]InputStream {
	asmap := make(map[string]InputStream)
	for _, stream := range inputs {
		asmap[stream.String()] = stream
	}
	return asmap
}

func allTrue(bools ...bool) bool {
	for _, b := range bools {
		if !b {
			return false
		}
	}
	return true
}

func detectScale(stream InputStream) string {
	if stream.StreamType != "v" {
		return ""
	}
	return scaleIF(stream.Width, stream.Height)
}

func scaleIF(w, h int) string {
	if w == 1920 && h == 1080 {
		return "hd"
	}
	if w == 3840 && h == 2160 {
		return "4k"
	}
	evristicsX_HD := math.Abs(float64(1920 - w))
	evristicsY_HD := math.Abs(float64(1080 - h))
	evristicsX_4K := math.Abs(float64(3840 - w))
	evristicsY_4K := math.Abs(float64(2160 - h))
	evrHD := evristicsX_HD + evristicsY_HD
	evr4K := evristicsX_4K + evristicsY_4K
	switch evrHD > evr4K {
	case true:
		return "scale_4k"
	}
	return "scale_hd"
}
