package streammapping

import "fmt"

// type Mapping struct {
// 	sourceFiles   []string
// 	sourceToIndex map[string]int
// }

type streamMapper struct {
	inputFiles       []string
	requestedOutputs []string
	breakIfUndecided bool
	assessProxy      bool
	productType      string
}

func newStreamMapper(options ...MapperOption) *streamMapper {
	sm := streamMapper{}
	for _, modify := range options {
		modify(&sm)
	}
	return &sm
}

type MapperOption func(*streamMapper)

func InputFiles(paths ...string) MapperOption {
	return func(sm *streamMapper) {
		sm.inputFiles = paths
	}
}

func SafeMode() MapperOption {
	return func(sm *streamMapper) {
		sm.breakIfUndecided = true
	}
}

func RequestOutput(outputs ...string) MapperOption {
	return func(sm *streamMapper) {
		sm.requestedOutputs = outputs
	}
}

func ProductType(product string) MapperOption {
	return func(sm *streamMapper) {
		sm.productType = product
	}
}

/*
распределить индексы для файлов
собрать карту входящих стримов
собрать перечень карт возможных комбинаций выхода
выбрать комбинацию выхода
собрать карту трансляции вход-->выход

распределение индексов:
сортировка по алфавиту
первая очередь: файлы имеющие видео
вторая очередь: аудио файлы
третья очередь: srt

*/

func Assess(options ...MapperOption) ([]OutputStream, error) {
	sm := streamMapper{
		inputFiles:       []string{},
		requestedOutputs: []string{},
		breakIfUndecided: false,
		assessProxy:      false,
		productType:      "",
	}
	for _, modify := range options {
		modify(&sm)
	}
	if len(sm.inputFiles) == 0 {
		return nil, fmt.Errorf("input files not provided")
	}
	tags := []string{}
	switch sm.productType {
	case "":
		return nil, fmt.Errorf("product type unset")
	default:
		return nil, fmt.Errorf("unsupported product type: %v", sm.productType)
	case ProdType_AUD, ProdType_TRL, ProdType_VID:
	case ProdType_FILM:
		tags = append(tags, "proxy")
	}
	inputs, err := assessInputs(sm.inputFiles...)
	if err != nil {
		return nil, fmt.Errorf("failed to assess input files: %v", err)
	}
	vid := candidatesVideo(inputs, tags...)
	aud := candidatesAudio(inputs, tags...)
	if sm.breakIfUndecided {
		if len(vid) > 1 {
			return nil, fmt.Errorf("manual decidion required (unimplemented) for video streams")
		}
		if len(aud) > 1 {
			return nil, fmt.Errorf("manual decidion required (unimplemented) for audio streams")
		}
	}
	mappingList := append(vid, aud...)
	return mappingList, nil
}
