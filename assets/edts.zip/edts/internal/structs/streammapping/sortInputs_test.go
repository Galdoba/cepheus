package streammapping

import (
	"testing"
)

func Test_assessInputs(t *testing.T) {
	// inputs, err := assessInputs(
	// 	`\\192.168.31.4\root\IN\@TRAILERS\_DONE\Kak_perevospitat_drakona_TRL\God_with_3_eyes_TLR_ProRes422HQ_1080p24_RU20_RU51.mov`,
	// 	// `\\192.168.31.4\root\IN\_VOLGA_FILM\_DONE\Bob_trevino_postavil_layk\BobTrevinoLikesIt_HD25f_RUS20LR_RUS51LRCLfeLsRs_NoPPl.mxf`,
	// 	// `\\192.168.31.4\root\IN\_VOLGA_FILM\_DONE\Bob_trevino_postavil_layk\BobTrevinoLikesIt_UHDSDR25f_ENG51_NoP_AC.wav`,
	// 	// `\\192.168.31.4\root\IN\_VOLGA_FILM\_DONE\Bob_trevino_postavil_layk\BobTrevinoLikesIt_UHDSDR25f_ENG51_NoP_AL.wav`,
	// 	// `\\192.168.31.4\root\IN\_VOLGA_FILM\_DONE\Bob_trevino_postavil_layk\BobTrevinoLikesIt_UHDSDR25f_ENG51_NoP_ALfe.wav`,
	// 	// `\\192.168.31.4\root\IN\_VOLGA_FILM\_DONE\Bob_trevino_postavil_layk\BobTrevinoLikesIt_UHDSDR25f_ENG51_NoP_ALs.wav`,
	// 	// `\\192.168.31.4\root\IN\_VOLGA_FILM\_DONE\Bob_trevino_postavil_layk\BobTrevinoLikesIt_UHDSDR25f_ENG51_NoP_AR.wav`,
	// 	// `\\192.168.31.4\root\IN\_VOLGA_FILM\_DONE\Bob_trevino_postavil_layk\BobTrevinoLikesIt_UHDSDR25f_ENG51_NoP_ARs.wav`,
	// )
	// fmt.Println(err)
	// for _, in := range inputs {
	// 	fmt.Println(in.String(), in.ChannelLayout, in.Path)
	// }
	// fmt.Println(outputPosibilities(inputs...))
	// fmt.Println(ListInputMaps(inputs...))
	// vid := candidatesVideo(inputs, "proxy")
	// for _, v := range vid {
	// 	fmt.Println(v.String(), ListInputMaps(v.inputs...), v.Tags)
	// 	fmt.Println(v.Bridge())
	// }
	// aud := candidatesAudio(inputs)
	// for _, v := range aud {
	// 	fmt.Println(v.String(), ListInputMaps(v.inputs...), v.Tags)
	// 	fmt.Println(v.Bridge())
	// }

}
