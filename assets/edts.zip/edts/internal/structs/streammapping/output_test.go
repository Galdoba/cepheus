package streammapping

import (
	"testing"
)

func TestOutputStream_String(t *testing.T) {
	tests := []struct {
		name string
		o    *OutputStream
		want string
	}{
		// test cases.
		{
			name: "video",
			o:    &OutputStream{StreamType: ST_VIDEO, Index: 0, Layout: "", WithProxy: false},
			want: "[video_00]",
		},
		{
			name: "video 42",
			o:    &OutputStream{StreamType: ST_VIDEO, Index: 42, Layout: "", WithProxy: true},
			want: "[video_42][video_42_proxy]",
		},
		{
			name: "video 42 hd",
			o:    &OutputStream{StreamType: ST_VIDEO, Index: 42, Layout: "", WithProxy: true, Tags: []string{"scale_hd"}},
			want: "[video_42_hd][video_42_hd_proxy]",
		},
		{
			name: "video 42 4k",
			o:    &OutputStream{StreamType: ST_VIDEO, Index: 42, Layout: "", WithProxy: true, Tags: []string{"4k"}},
			want: "[video_42_4k][video_42_4k_proxy]",
		},
		{
			name: "audio 1",
			o:    &OutputStream{StreamType: ST_AUDIO, Index: 1, Layout: LAYOUT_STEREO, WithProxy: true},
			want: "[audio_01_20][audio_01_20_proxy]",
		},
		{
			name: "audio 2",
			o:    &OutputStream{StreamType: ST_AUDIO, Index: 3, Layout: LAYOUT_51, WithProxy: false},
			want: "[audio_03_51]",
		},
		{
			name: "audio 3",
			o:    &OutputStream{StreamType: ST_AUDIO, Index: 3, Layout: LAYOUT_ANY, WithProxy: false},
			want: "[audio_03_xx]",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.o.String(); got != tt.want {
				t.Errorf("OutputStream.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
