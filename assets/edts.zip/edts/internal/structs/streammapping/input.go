package streammapping

import "fmt"

const (
	ProdType_FILM = "FLM"
	ProdType_TRL  = "TRL"
	ProdType_VID  = "video"
	ProdType_AUD  = "audio"
)

type InputStream struct {
	Path           string
	FileIndex      int
	StreamType     string
	StreamPosition int
	ChannelLayout  string
	Width          int
	Height         int
	Fps            float64
}

var NoInput = InputStream{FileIndex: -1, StreamType: "none", StreamPosition: -1}

func (is *InputStream) String() string {
	return fmt.Sprintf("[%v:%v:%v]", is.FileIndex, is.StreamType, is.StreamPosition)
}

func NewInput(path string, index int, strType string, pos int) InputStream {
	return InputStream{Path: path, FileIndex: index, StreamType: strType, StreamPosition: pos}
}

func noInput(i InputStream) bool {
	if i.FileIndex == -1 && i.StreamType == "none" && i.StreamPosition == -1 {
		return true
	}
	return false
}
