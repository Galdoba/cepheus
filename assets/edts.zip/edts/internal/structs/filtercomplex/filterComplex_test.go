package filtercomplex

import (
	"fmt"
	"testing"

	"github.com/Galdoba/edts/internal/structs/filtercomplex/audio"
	"github.com/Galdoba/edts/internal/structs/filtercomplex/video"
)

func TestWithFilterCalls(t *testing.T) {
	fc := WithFilterCalls(
		Aresample(audio.AresampleOption_SampleRate(44100)),
		Atempo(audio.AtempoOption_Expression(5800.64, 5466.8)),
		Crop(video.CropOption_Size(1920, 800), video.CropOption_Offset(0, 0)),
		DownScale_HD(),
		Proxy(),
		Amerge(),
		Subtitle(video.SubtitleOption_Filename("/path/to/file.srt")),
	)
	fmt.Println(fc.String())
}
