package filtercomplex

import (
	"fmt"

	"github.com/Galdoba/edts/internal/structs/filtercomplex/audio"
	"github.com/Galdoba/edts/internal/structs/filtercomplex/video"
)

const (
	fa_Asplit    = "asplit"
	fa_Amerge    = "amerge"
	fa_Aresample = "aresample"
	fa_Atempo    = "atempo"
	fv_Split     = "split"
	fv_Subtitle  = "subtitle"
	fv_Crop      = "crop"
	fv_Pad       = "pad"
	fv_Scale     = "scale"
	fv_Setsar    = "setsar"
	fv_Unsharp   = "unsharp"
)

type filterCaller struct {
	filter map[string]fmt.Stringer
}

var defaultCaller = &filterCaller{}

func newCaller() {
	fc := filterCaller{}
	fc.filter = make(map[string]fmt.Stringer)
	defaultCaller = &fc
}

type FilterCall func(*filterCaller)

// AUDIO
func Aresample(options ...audio.AresampleOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, audio.NoAresample())
		}
		a := audio.NewAresample(options...)
		defaultCaller.filter[fa_Aresample] = &a
	}
}

func Atempo(options ...audio.AtempoOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, audio.NoAtempo())
		}
		a := audio.NewAtempo(options...)
		defaultCaller.filter[fa_Atempo] = &a
	}
}

func Asplit(options ...audio.AsplitOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, audio.NoAsplit())
		}
		a := audio.NewAsplit(options...)
		defaultCaller.filter[fa_Asplit] = &a
	}
}

func Amerge(options ...audio.AmergeOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, audio.AmergeOption_Inputs(2))
		}
		a := audio.NewAmerge(options...)
		defaultCaller.filter[fa_Amerge] = &a
	}
}

// VIDEO

func Crop(options ...video.CropOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, video.NoCrop())
		}
		a := video.NewCrop(options...)
		defaultCaller.filter[fv_Crop] = &a
	}
}

func Scale(options ...video.ScaleOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, video.NoScale())
		}
		a := video.NewScale(options...)
		defaultCaller.filter[fv_Scale] = &a
	}
}

func Pad(options ...video.PadOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, video.NoPad())
		}
		a := video.NewPad(options...)
		defaultCaller.filter[fv_Pad] = &a
	}
}

func Setsar(options ...video.SetsarOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, video.SetsarOption_Square())
		}
		a := video.NewSetsar(options...)
		defaultCaller.filter[fv_Setsar] = &a
	}
}

func Unsharp(options ...video.UnsharpOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, video.NoUnsharp())
		}
		a := video.NewUnsharp(options...)
		defaultCaller.filter[fv_Unsharp] = &a
	}
}

func Subtitle(options ...video.SubtitleOption) FilterCall {
	return func(fc *filterCaller) {
		if len(options) == 0 {
			options = append(options, video.NoSubtitle())
		}
		a := video.NewSubtitle(options...)
		defaultCaller.filter[fv_Subtitle] = &a
	}
}

//CONVINIENCE

func DownScale_HD() FilterCall {
	return func(fc *filterCaller) {
		scale := video.NewScale(video.ScaleOption_Size(1920, -2))
		setsar := video.NewSetsar(video.SetsarOption_Square())
		unsharp := video.NewUnsharp(video.UnsharpOption_StandardValues())
		pad := video.NewPad(video.PadOption_HD(), video.PadOption_Centered())
		defaultCaller.filter[fv_Scale] = &scale
		defaultCaller.filter[fv_Setsar] = &setsar
		defaultCaller.filter[fv_Unsharp] = &unsharp
		defaultCaller.filter[fv_Pad] = &pad
	}
}

func Proxy() FilterCall {
	return func(fc *filterCaller) {
		split := video.NewSplit()
		asplit := audio.NewAsplit()
		defaultCaller.filter[fv_Split] = &split
		defaultCaller.filter[fa_Asplit] = &asplit
	}
}
