package audio

import "testing"

func TestAresample_String(t *testing.T) {
	a1 := NewAresample()
	a2 := NewAresample(AresampleOption_SampleRate(44100), AresampleOption_FlagValue("flag_one", "value_one"))
	a3 := NewAresample(NoAresample())
	tests := []struct {
		name string
		a    *Aresample
		want string
	}{
		{
			name: "default case",
			a:    &a1,
			want: "aresample=48000",
		}, // TODO: Add test cases.
		{
			name: "complex case",
			a:    &a2,
			want: "aresample=44100:flag_one=value_one",
		}, // TODO: Add test cases.
		{
			name: "no aresample case",
			a:    &a3,
			want: "",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.a.String(); got != tt.want {
				t.Errorf("Aresample.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
