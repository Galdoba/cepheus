package audio

import "testing"

func TestAsplit_String(t *testing.T) {
	sp1 := NewAsplit()
	sp2 := NewAsplit(NoAsplit())
	sp3 := NewAsplit(AsplitOption_OutputsNumber(3))
	tests := []struct {
		name string
		sp   *Asplit
		want string
	}{
		{
			name: "default",
			sp:   &sp1,
			want: "asplit=2",
		}, // TODO: Add test cases.
		{
			name: "none",
			sp:   &sp2,
			want: "",
		}, // TODO: Add test cases.
		{
			name: "custom",
			sp:   &sp3,
			want: "asplit=3",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.sp.String(); got != tt.want {
				t.Errorf("Asplit.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
