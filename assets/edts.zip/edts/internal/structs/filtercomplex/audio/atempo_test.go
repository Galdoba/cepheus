package audio

import "testing"

func TestAtempo_String(t *testing.T) {
	a1 := NewAtempo()
	a2 := NewAtempo(NoAtempo())
	a3 := NewAtempo(AtempoOption_Expression(25.25, 60))
	tests := []struct {
		name string
		a    *Atempo
		want string
	}{
		{
			name: "default",
			a:    &a1,
			want: "atempo=1",
		}, // TODO: Add test cases.
		{
			name: "none",
			a:    &a2,
			want: "",
		}, // TODO: Add test cases.
		{
			name: "expession",
			a:    &a3,
			want: "atempo=(25.25/60)",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.a.String(); got != tt.want {
				t.Errorf("Atempo.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
