package audio

import "fmt"

type Amerge struct {
	// Merge two or more audio streams into a single multi-channel stream.
	// Set the number of inputs. Default is 2.

	// If the channel layouts of the inputs are disjoint, and therefore compatible, the channel layout of the output will be set accordingly and the channels will be reordered as necessary. If the channel layouts of the inputs are not disjoint, the output will have all the channels of the first input then all the channels of the second input, in that order, and the channel layout of the output will be the default value corresponding to the total number of channels.
	// For example, if the first input is in 2.1 (FL+FR+LF) and the second input is FC+BL+BR, then the output will be in 5.1, with the channels in the following order: a1, a2, b1, a3, b2, b3 (a1 is the first channel of the first input, b1 is the first channel of the second input).
	// On the other hand, if both input are in stereo, the output channels will be in the default order: a1, a2, b1, b2, and the channel layout will be arbitrarily set to 4.0, which may or may not be the expected value.

	// All inputs must have the same sample rate, and format.
	// If inputs do not have the same duration, the output will stop with the shortest.
	Inputs int

	omit bool
}

func NewAmerge(options ...AmergeOption) Amerge {
	state := Amerge{
		Inputs: 2,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (a *Amerge) String() string {
	if a.omit {
		return ""
	}
	return fmt.Sprintf("amerge=%v", a.Inputs)
}

type AmergeOption func(*Amerge)

func AmergeOption_Inputs(value int) AmergeOption {
	return func(sp *Amerge) {
		sp.Inputs = value
	}
}

func NoAmerge() AmergeOption {
	return func(sp *Amerge) {
		sp.omit = true
	}
}
