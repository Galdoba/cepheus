package audio

import (
	"fmt"
	"strings"
)

type Aresample struct {
	Sample_Rate int
	OptKeys     []string
	OptValues   []string
	omit        bool
}

func NewAresample(options ...AresampleOption) Aresample {
	state := Aresample{
		Sample_Rate: 48000,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (a *Aresample) String() string {
	if a.omit {
		return ""
	}
	s := fmt.Sprintf("aresample=%v:", a.Sample_Rate)
	for i := range a.OptKeys {
		s += fmt.Sprintf("%v=%v:", a.OptKeys[i], a.OptValues[i])
	}
	return strings.TrimSuffix(s, ":")
}

type AresampleOption func(*Aresample)

func AresampleOption_SampleRate(value int) AresampleOption {
	return func(a *Aresample) {
		a.Sample_Rate = value
	}
}

func AresampleOption_FlagValue(key, value string) AresampleOption {
	return func(a *Aresample) {
		a.OptKeys = append(a.OptKeys, key)
		a.OptValues = append(a.OptValues, value)
	}
}

func NoAresample() AresampleOption {
	return func(a *Aresample) {
		a.omit = true
	}
}
