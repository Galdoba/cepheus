package audio

import "testing"

func TestAmerge_String(t *testing.T) {
	a1 := NewAmerge()
	a2 := NewAmerge(NoAmerge())
	a3 := NewAmerge(AmergeOption_Inputs(3))
	tests := []struct {
		name string
		sp   *Amerge
		want string
	}{
		{
			name: "default",
			sp:   &a1,
			want: "amerge=2",
		}, // TODO: Add test cases.
		{
			name: "none",
			sp:   &a2,
			want: "",
		}, // TODO: Add test cases.
		{
			name: "custom",
			sp:   &a3,
			want: "amerge=3",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.sp.String(); got != tt.want {
				t.Errorf("Amerge.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
