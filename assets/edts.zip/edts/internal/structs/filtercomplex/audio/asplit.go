package audio

import (
	"fmt"
)

type Asplit struct {
	// Asplit input into several identical outputs.
	// Works with audio.
	// The filter accepts a single parameter which specifies the number of outputs. If unspecified, it defaults to 2.
	OutputsNumber int
	omit          bool
}

func NewAsplit(options ...AsplitOption) Asplit {
	state := Asplit{
		OutputsNumber: 2,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (sp *Asplit) String() string {
	if sp.omit {
		return ""
	}
	return fmt.Sprintf("asplit=%v", sp.OutputsNumber)
}

type AsplitOption func(*Asplit)

func AsplitOption_OutputsNumber(value int) AsplitOption {
	return func(sp *Asplit) {
		sp.OutputsNumber = value
	}
}

func NoAsplit() AsplitOption {
	return func(sp *Asplit) {
		sp.omit = true
	}
}
