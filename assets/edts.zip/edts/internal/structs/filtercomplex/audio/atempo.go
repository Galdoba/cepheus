package audio

import "fmt"

type Atempo struct {
	// Adjust audio tempo.
	// The filter accepts exactly one parameter, the audio tempo. If not specified then the filter will assume nominal 1.0 tempo. Tempo must be in the [0.5, 100.0] range.
	// Note that tempo greater than 2 will skip some samples rather than blend them in. If for any reason this is a concern it is always possible to daisy-chain several instances of atempo to achieve the desired product tempo.
	Parameter float64

	// Custom Expression: atempo=(Initial/Target)
	ExpTargetDurationSeconds float64
	ExpActualDurationSeconds float64
	useExp                   bool

	omit bool
}

func NewAtempo(options ...AtempoOption) Atempo {
	state := Atempo{
		Parameter: 1.0,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (a *Atempo) String() string {
	if a.omit {
		return ""
	}
	if a.useExp {
		return fmt.Sprintf("atempo=(%v/%v)", a.ExpActualDurationSeconds, a.ExpTargetDurationSeconds)
	}
	return fmt.Sprintf("atempo=%v", a.Parameter)
}

type AtempoOption func(*Atempo)

func AtempoOption_Parameter(value float64) AtempoOption {
	return func(a *Atempo) {
		a.Parameter = value
	}
}

func AtempoOption_Expression(initial, target float64) AtempoOption {
	return func(a *Atempo) {
		a.ExpActualDurationSeconds = initial
		a.ExpTargetDurationSeconds = target
		a.useExp = true
	}
}

func NoAtempo() AtempoOption {
	return func(a *Atempo) {
		a.omit = true
	}
}
