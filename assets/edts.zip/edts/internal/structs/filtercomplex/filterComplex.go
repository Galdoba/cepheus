package filtercomplex

import (
	"fmt"
	"strings"

	"github.com/Galdoba/edts/internal/structs/filtercomplex/audio"
)

type FilterComplex struct {
	Statements []FC_Statement
}

type FC_Statement struct {
	inMap   []string
	outMap  []string
	filters []fmt.Stringer
}

func WithFilterCalls(calls ...FilterCall) *FilterComplex {
	fc := FilterComplex{}
	newCaller()
	for _, modify := range calls {
		modify(defaultCaller)
	}
	fc.addStatement([]string{"[unmapped_video_in]"}, []string{"[unmapped_video_out]"},
		defaultCaller.filter[fv_Subtitle],
		defaultCaller.filter[fv_Crop],
		defaultCaller.filter[fv_Scale],
		defaultCaller.filter[fv_Setsar],
		defaultCaller.filter[fv_Unsharp],
		defaultCaller.filter[fv_Pad],
		defaultCaller.filter[fv_Split],
	)
	fc.addStatement([]string{"[unmapped_audio_in]"}, []string{"[unmapped_audio_out]"},
		defaultCaller.filter[fa_Amerge],
		defaultCaller.filter[fa_Aresample],
		defaultCaller.filter[fa_Atempo],
		defaultCaller.filter[fa_Asplit],
	)
	return &fc
}

//scale=1920:-2,setsar=1/1,unsharp=3:3:0.3:3:3:0,pad=1920:1080:-1:-1

func (fc *FilterComplex) String() string {
	s := ""
	if len(fc.Statements) == 0 {
		return s
	}
	for _, statement := range fc.Statements {
		switch statement.String() {
		case "":
			continue
		default:
			s += statement.String() + "; "
		}
	}
	return strings.TrimSuffix(s, "; ")
}

func (fs *FC_Statement) String() string {
	s := ""
	if len(fs.filters) == 0 {
		return s
	}
	for _, in := range fs.inMap {

		s += in
	}

	for _, f := range fs.filters {
		if f.String() == "" {
			continue
		}
		s += f.String() + ","
	}
	s = strings.TrimSuffix(s, ",")
	for _, out := range fs.outMap {
		s += out
	}

	return s
}

func (fc *FilterComplex) addStatement(in, out []string, stringers ...fmt.Stringer) {
	statement := FC_Statement{
		inMap:  in,
		outMap: out,
	}
	for _, stringer := range stringers {
		if stringer == nil {
			continue
		}
		if stringer.String() == "" {
			continue
		}
		statement.filters = append(statement.filters, stringer)
	}
	fc.Statements = append(fc.Statements, statement)
}

func OptionSetByTags(tags ...string) []FilterCall {
	filters := []FilterCall{}
	for _, tag := range tags {
		switch tag {
		case "hd", "4k":
			filters = append(filters, Setsar())
		case "scale_hd":
			filters = append(filters, DownScale_HD())
		case "amerge_2112":
			filters = append(filters, Amerge(audio.AmergeOption_Inputs(2112)))
		case "amerge_6":
			filters = append(filters, Amerge(audio.AmergeOption_Inputs(6)))
		case "amerge_2":
			filters = append(filters, Amerge(audio.AmergeOption_Inputs(2)))
		case "proxy":
			filters = append(filters, Proxy())
		case "direct mapping":
			filters = append(filters, Aresample(audio.AresampleOption_SampleRate(48000)))
		case "25_fps":
			filters = append(filters, Atempo(audio.AtempoOption_Parameter(fps25)))
		case "24_fps":
			filters = append(filters, Atempo(audio.AtempoOption_Parameter(fps24)))
		case "23.976_fps":
			filters = append(filters, Atempo(audio.AtempoOption_Parameter(fps23_97)))
		}
	}
	return filters
}

var fps25 = float64(25) / float64(25)
var fps24 = float64(25) / float64(24)
var fps23_97 = float64(25) / (float64(24000) / float64(1001))

func (fc *FilterComplex) InjectMappings(ins []string, outs []string) error {
	if len(fc.Statements) != len(outs) {
		return fmt.Errorf("not equal mappings to filter_complex: (%v != %v)", len(fc.Statements), len(outs))
	}

	for i := range fc.Statements {
		fc.Statements[i].inMap = SplitMappingDeclaration(ins[i])
		fc.Statements[i].outMap = SplitMappingDeclaration(outs[i])
	}
	return nil
}

func SplitMappingDeclaration(s string) []string {
	parts := strings.Split(s, "]")
	result := []string{}
	for i := range parts {
		if parts[i] != "" {
			parts[i] += "]"
			result = append(result, parts[i])
		}
	}
	return result
}
