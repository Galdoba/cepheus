package video

import (
	"testing"
)

func TestScale_String(t *testing.T) {
	noScale := NewScale(NoScale())
	sc1 := NewScale(ScaleOption_Size(1920, 1080))
	tests := []struct {
		name string
		sc   *Scale
		want string
	}{
		{
			name: "no scale",
			sc:   &noScale,
			want: "",
		}, // TODO: Add test cases.
		{
			name: "scale size",
			sc:   &sc1,
			want: "scale=1920:1080",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.sc.String(); got != tt.want {
				t.Errorf("Scale.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
