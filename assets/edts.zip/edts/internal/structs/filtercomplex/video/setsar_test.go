package video

import "testing"

func TestSetsar_String(t *testing.T) {
	sq := NewSetsar(SetsarOption_Square())
	tests := []struct {
		name string
		ss   *Setsar
		want string
	}{
		{
			name: "",
			ss:   &sq,
			want: "setsar=(1/1)",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.ss.String(); got != tt.want {
				t.Errorf("Setsar.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
