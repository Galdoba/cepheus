package video

import "fmt"

type Setsar struct {
	Horisontal int
	Vertical   int
	omit       bool
}

func NewSetsar(options ...SetsarOption) Setsar {
	state := Setsar{
		Horisontal: 0,
		Vertical:   0,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (ss *Setsar) String() string {
	s := ""
	if ss.omit {
		return s
	}
	return fmt.Sprintf("setsar=(%v/%v)", ss.Horisontal, ss.Vertical)
}

type SetsarOption func(*Setsar)

func SetsarOption_Square() SetsarOption {
	return func(s *Setsar) {
		s.Vertical = 1
		s.Horisontal = 1
	}
}

func SetsarOption_SD_169() SetsarOption {
	return func(s *Setsar) {
		s.Horisontal = 64
		s.Vertical = 45
	}
}

func SetsarOption_SD_43() SetsarOption {
	return func(s *Setsar) {
		s.Horisontal = 16
		s.Vertical = 15
	}
}

func SetsarOption_Custom(hors, vert int) SetsarOption {
	return func(s *Setsar) {
		s.Horisontal = hors
		s.Vertical = vert
	}
}

func NoSetsar() SetsarOption {
	return func(s *Setsar) {
		s.omit = true
	}
}
