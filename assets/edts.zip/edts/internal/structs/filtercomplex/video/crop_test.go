package video

import "testing"

func TestCrop_String(t *testing.T) {
	cr1 := NewCrop(CropOption_Size(1000, 500), CropOption_Offset(250, 125))
	tests := []struct {
		name string
		c    *Crop
		want string
	}{
		{
			name: "",
			c:    &cr1,
			want: "crop=1000:500:250:125",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.c.String(); got != tt.want {
				t.Errorf("Crop.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
