package video

import "fmt"

type Unsharp struct {
	//unsharp=3:3:0.3:3:3:0
	//Set the luma matrix horizontal size. It must be an odd integer between 3 and 23. The default value is 5.
	Luma_msize_x int

	//Set the luma matrix vertical size. It must be an odd integer between 3 and 23. The default value is 5.
	Luma_msize_y int

	/*Set the luma effect strength. It must be a floating point number, reasonable values lay between -1.5 and 1.5.
	  Negative values will blur the input video, while positive values will sharpen it, a value of zero will disable the effect.
	  Default value is 1.0.*/
	Luma_amount float64

	//Set the chroma matrix horizontal size. It must be an odd integer between 3 and 23. The default value is 5.
	Chroma_msize_x int

	//Set the chroma matrix vertical size. It must be an odd integer between 3 and 23. The default value is 5.
	Chroma_msize_y int

	/*Set the chroma effect strength. It must be a floating point number, reasonable values lay between -1.5 and 1.5.
	  Negative values will blur the input video, while positive values will sharpen it, a value of zero will disable the effect.
	  Default value is 0.0.*/
	Chroma_amount float64

	//Set the alpha matrix horizontal size. It must be an odd integer between 3 and 23. The default value is 5.
	Alpha_msize_x int

	//Set the alpha matrix vertical size. It must be an odd integer between 3 and 23. The default value is 5.
	Alpha_msize_y int

	/*Set the alpha effect strength. It must be a floating point number, reasonable values lay between -1.5 and 1.5.
	  Negative values will blur the input video, while positive values will sharpen it, a value of zero will disable the effect.
	  Default value is 0.0.*/
	Alpha_amount float64
}

func (us *Unsharp) String() string {
	s := ""
	if us.Alpha_amount == 0 && us.Chroma_amount == 0 && us.Luma_amount == 0 {
		return s
	}
	s += fmt.Sprintf("unsharp=%v:%v:%v:%v:%v:%v",
		us.Luma_msize_x, us.Luma_msize_y, us.Luma_amount,
		us.Chroma_msize_x, us.Chroma_msize_y, us.Chroma_amount,
	)
	if us.Alpha_amount != 0 {
		s += fmt.Sprintf(":%v:%v:%v", us.Alpha_msize_x, us.Alpha_msize_y, us.Alpha_amount)
	}
	return s
}

func NewUnsharp(options ...UnsharpOption) Unsharp {
	state := Unsharp{
		Luma_msize_x:   5,
		Luma_msize_y:   5,
		Luma_amount:    1.0,
		Chroma_msize_x: 5,
		Chroma_msize_y: 5,
		Chroma_amount:  0,
		Alpha_msize_x:  5,
		Alpha_msize_y:  5,
		Alpha_amount:   0,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

type UnsharpOption func(*Unsharp)

//Set filter's StandardValues
func UnsharpOption_StandardValues() UnsharpOption {
	return func(u *Unsharp) {
		//unsharp=3:3:0.3:3:3:0
		u.Luma_msize_x = 3
		u.Luma_msize_y = 3
		u.Luma_amount = 0.3
		u.Chroma_msize_x = 3
		u.Chroma_msize_y = 3
		u.Chroma_amount = 0
		u.Alpha_msize_x = 5
		u.Alpha_msize_y = 5
		u.Alpha_amount = 0
	}
}

//Set filter's Luma_msize_x
func UnsharpOption_Luma_msize_x(value int) UnsharpOption {
	return func(u *Unsharp) {
		u.Luma_msize_x = value
	}
}

//Set filter's Luma_msize_y
func UnsharpOption_Luma_msize_y(value int) UnsharpOption {
	return func(u *Unsharp) {
		u.Luma_msize_y = value
	}
}

//Set filter's Luma_amount
func UnsharpOption_Luma_amount(value float64) UnsharpOption {
	return func(u *Unsharp) {
		u.Luma_amount = value
	}
}

//Set filter's Chroma_msize_x
func UnsharpOption_Chroma_msize_x(value int) UnsharpOption {
	return func(u *Unsharp) {
		u.Chroma_msize_x = value
	}
}

//Set filter's Chroma_msize_y
func UnsharpOption_Chroma_msize_y(value int) UnsharpOption {
	return func(u *Unsharp) {
		u.Chroma_msize_y = value
	}
}

//Set filter's Chroma_amount
func UnsharpOption_Chroma_amount(value float64) UnsharpOption {
	return func(u *Unsharp) {
		u.Chroma_amount = value
	}
}

//Set filter's Alpha_msize_x
func UnsharpOption_Alpha_msize_x(value int) UnsharpOption {
	return func(u *Unsharp) {
		u.Alpha_msize_x = value
	}
}

//Set filter's Alpha_msize_y
func UnsharpOption_Alpha_msize_y(value int) UnsharpOption {
	return func(u *Unsharp) {
		u.Alpha_msize_y = value
	}
}

//Set filter's Alpha_amount
func UnsharpOption_Alpha_amount(value float64) UnsharpOption {
	return func(u *Unsharp) {
		u.Alpha_amount = value
	}
}

func NoUnsharp() UnsharpOption {
	return func(u *Unsharp) {
		u.Alpha_amount = 0.0
		u.Chroma_amount = 0.0
		u.Luma_amount = 0.0
	}
}
