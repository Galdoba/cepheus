package video

import (
	"fmt"
	"strings"
)

type Scale struct {
	// Set the output video dimension expression. Default value is the input dimension.
	// If the width or w value is 0, the input width is used for the output. If the height or h value is 0, the input height is used for the output.
	// If one and only one of the values is -n with n >= 1, the scale filter will use a value that maintains the aspect ratio of the input image, calculated from the other specified dimension. After that it will, however, make sure that the calculated dimension is divisible by n and adjust the value if necessary.
	// If both values are -n with n >= 1, the behavior will be identical to both values being set to 0 as previously detailed.
	Width  int
	Height int

	// Specify when to evaluate width and height expression. It accepts the following values:
	// ‘init’
	// Only evaluate expressions once during the filter initialization or when a command is processed.
	// ‘frame’
	// Evaluate expressions for each incoming frame.
	// Default value is ‘init’.
	Eval string

	// Set the interlacing mode. It accepts the following values:
	// ‘1’
	// Force interlaced aware scaling.
	// ‘0’
	// Do not apply interlaced scaling.
	// ‘-1’
	// Select interlaced aware scaling depending on whether the source frames are flagged as interlaced or not.
	// Default value is ‘0’.
	Interl int
	//omit filter
	omit bool
}

func (sc *Scale) String() string {
	s := ""
	if sc.omit {
		return ""
	}
	if sc.Height == 0 && sc.Width == 0 {
		return s
	}
	s += fmt.Sprintf("scale=%v:%v:", sc.Width, sc.Height)
	if sc.Eval != "init" {
		s += fmt.Sprintf("eval=%v:", sc.Eval)
	}
	if sc.Interl != 0 {
		s += fmt.Sprintf("interl=%v:", sc.Interl)
	}
	return strings.TrimSuffix(s, ":")
}

func NewScale(options ...ScaleOption) Scale {
	state := Scale{
		Width:  0,
		Height: 0,
		Eval:   "init",
		Interl: 0,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

type ScaleOption func(*Scale)

func NoScale() ScaleOption {
	return func(s *Scale) {
		s.omit = true
	}
}

func ScaleOption_Size(width, height int) ScaleOption {
	return func(s *Scale) {
		s.Width = width
		s.Height = height
	}
}

func With_Eval(value string) ScaleOption {
	return func(s *Scale) {
		s.Eval = value
	}
}
func With_Interl(value int) ScaleOption {
	return func(s *Scale) {
		s.Interl = value
	}
}
