package video

import "testing"

func TestSubtitle_String(t *testing.T) {
	sub1 := NewSubtitle(SubtitleOption_Filename("/path/to/file.srt"))
	tests := []struct {
		name string
		sub  *Subtitle
		want string
	}{
		{
			name: "default",
			sub:  &sub1,
			want: "subtitles=filename=/path/to/file.srt:original_size=1920x1080:force_style='Fontname=Segoe UI,Fontsize=19.4,PrimaryColour='&H00EBEBEB',SecondaryColour='&H000000FF',OutlineColour='&H00000000',BackColour='&H80000000',Bold=0,Italic=0,Underline=0,StrikeOut=0,ScaleX=1,ScaleY=1,Spacing=0,Angle=0,BorderStyle=1,Outline=1,Shadow=0,Alignment=2,MarginL=5,MarginR=5,MarginV=40,Encoding=1'",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.sub.String(); got != tt.want {
				t.Errorf("Subtitle.String() = \n%v\n, want \n%v", got, tt.want)
			}
		})
	}
}
