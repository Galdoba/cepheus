package video

import "testing"

func TestPad_String(t *testing.T) {
	pad1 := NewPad(PadOption_HD(), PadOption_Centered())
	pad2 := NewPad(PadOption_4K(), PadOption_Horisontal())
	tests := []struct {
		name string
		p    *Pad
		want string
	}{
		{
			name: "hd centered",
			p:    &pad1,
			want: "pad=1920:1080:-1:-1",
		}, // TODO: Add test cases.
		{
			name: "4k horisontal",
			p:    &pad2,
			want: "pad=3840:2160:0:-1",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.p.String(); got != tt.want {
				t.Errorf("Pad.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
