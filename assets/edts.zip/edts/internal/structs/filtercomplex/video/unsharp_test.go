package video

import "testing"

func TestUnsharp_String(t *testing.T) {
	us1 := NewUnsharp(UnsharpOption_StandardValues())
	tests := []struct {
		name string
		us   *Unsharp
		want string
	}{
		{
			name: "",
			us:   &us1,
			want: "unsharp=3:3:0.3:3:3:0",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.us.String(); got != tt.want {
				t.Errorf("Unsharp.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
