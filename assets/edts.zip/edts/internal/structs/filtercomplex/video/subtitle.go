package video

import (
	"fmt"
	"strings"

	"github.com/Galdoba/edts/internal/structs/filtercomplex/video/hsubstyle"
)

const (
	sf_Name            = hsubstyle.Field_Name
	sf_Fontname        = hsubstyle.Field_Fontname
	sf_Fontsize        = hsubstyle.Field_Fontsize
	sf_PrimaryColour   = hsubstyle.Field_PrimaryColour
	sf_SecondaryColour = hsubstyle.Field_SecondaryColour
	sf_OutlineColor    = hsubstyle.Field_OutlineColor
	sf_BackColour      = hsubstyle.Field_BackColour
	sf_Bold            = hsubstyle.Field_Bold
	sf_Italic          = hsubstyle.Field_Italic
	sf_Underline       = hsubstyle.Field_Underline
	sf_StrikeOut       = hsubstyle.Field_StrikeOut
	sf_ScaleX          = hsubstyle.Field_ScaleX
	sf_ScaleY          = hsubstyle.Field_ScaleY
	sf_Spacing         = hsubstyle.Field_Spacing
	sf_Angle           = hsubstyle.Field_Angle
	sf_BorderStyle     = hsubstyle.Field_BorderStyle
	sf_Outline         = hsubstyle.Field_Outline
	sf_Shadow          = hsubstyle.Field_Shadow
	sf_Alignment       = hsubstyle.Field_Alignment
	sf_MarginL         = hsubstyle.Field_MarginL
	sf_MarginR         = hsubstyle.Field_MarginR
	sf_MarginV         = hsubstyle.Field_MarginV
	sf_AlphaLevel      = hsubstyle.Field_AlphaLevel
	sf_Encoding        = hsubstyle.Field_Encoding
)

type Subtitle struct {
	// Draw subtitles on top of input video using the libass library.
	// To enable compilation of this filter you need to configure FFmpeg with --enable-libass. This filter also requires a build with libavcodec and libavformat to convert the passed subtitles file to ASS (Advanced Substation Alpha) subtitles format.
	// The filter accepts the following options:

	// Set the filename of the subtitle file to read. It must be specified.
	Filename string

	// Specify the size of the original video, the video for which the ASS file was composed. For the syntax of this option, check the (ffmpeg-utils)"Video size" section in the ffmpeg-utils manual. Due to a misdesign in ASS aspect ratio arithmetic, this is necessary to correctly scale the fonts if the aspect ratio has been changed.
	Original_Size [2]int

	// Set a directory path containing fonts that can be used by the filter. These fonts will be used in addition to whatever the font provider uses.
	Fontsdir string

	// Process alpha channel, by default alpha channel is untouched.
	Alpha bool

	// Set subtitles input character encoding. subtitles filter only. Only useful if not UTF-8.
	Charenc string

	// Set subtitles stream index. subtitles filter only.
	Stream_index int

	// Override default style or script info parameters of the subtitles. It accepts a string containing ASS style format KEY=VALUE couples separated by ",".
	Force_style map[string]string

	// wrap_unicode
	// Break lines according to the Unicode Line Breaking Algorithm. Availability requires at least libass release 0.17.0 (or LIBASS_VERSION 0x01600010), and libass must have been built with libunibreak.
	// The option is enabled by default except for native ASS.
	Wrap_unicode bool

	// If the first key is not specified, it is assumed that the first value specifies the filename.
	// For example, to render the file sub.srt on top of the input video, use the command:
	// 	subtitles=sub.srt
	// which is equivalent to:
	// 	subtitles=filename=sub.srt

	// To render the default subtitles stream from file video.mkv, use:
	// 	subtitles=video.mkv
	// To render the second subtitles stream from that file, use:
	// 	subtitles=video.mkv:si=1
	// To make the subtitles stream from sub.srt appear in 80% transparent blue DejaVu Serif, use:
	// 	subtitles=sub.srt:force_style='Fontname=DejaVu Serif,PrimaryColour=&HCCFF0000'

	omit bool
}

func NewSubtitle(options ...SubtitleOption) Subtitle {
	state := Subtitle{
		Filename:      "",
		Original_Size: [2]int{1920, 1080},
		Fontsdir:      "",
		Alpha:         false,
		Charenc:       "",
		Stream_index:  -1,
		Force_style:   hsubstyle.ContentcomStyle().ToMap(),
		Wrap_unicode:  false,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (sub *Subtitle) String() string {
	if sub.omit {
		return ""
	}
	s := ""
	s += fmt.Sprintf("subtitles=filename=%v:", sub.Filename)
	if sub.Original_Size[0] != 0 && sub.Original_Size[1] != 0 {
		s += fmt.Sprintf("original_size=%vx%v:", sub.Original_Size[0], sub.Original_Size[1])
	}
	if sub.Fontsdir != "" {
		s += fmt.Sprintf("fontsdir=%v:", sub.Fontsdir)
	}
	if sub.Alpha != false {
		s += fmt.Sprintf("alpha=1:")
	}
	if sub.Charenc != "" {
		s += fmt.Sprintf("charenc=%v:", sub.Charenc)
	}
	if sub.Stream_index > 0 {
		s += fmt.Sprintf("stream_index=%v:", sub.Stream_index)
	}
	if len(sub.Force_style) > 0 {
		styleText := "force_style='"
		for _, field := range styleFields() {
			if _, ok := sub.Force_style[field]; !ok {
				continue
			}
			switch field {
			case sf_Name:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Fontname:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Fontsize:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_PrimaryColour:
				styleText += fmt.Sprintf("%v='%v',", field, sub.Force_style[field])
			case sf_SecondaryColour:
				styleText += fmt.Sprintf("%v='%v',", field, sub.Force_style[field])
			case sf_OutlineColor:
				styleText += fmt.Sprintf("%v='%v',", field, sub.Force_style[field])
			case sf_BackColour:
				styleText += fmt.Sprintf("%v='%v',", field, sub.Force_style[field])
			case sf_Bold:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Italic:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Underline:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_StrikeOut:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_ScaleX:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_ScaleY:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Spacing:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Angle:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_BorderStyle:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Outline:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Shadow:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Alignment:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_MarginL:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_MarginR:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_MarginV:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_AlphaLevel:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			case sf_Encoding:
				styleText += fmt.Sprintf("%v=%v,", field, sub.Force_style[field])
			}
		}
		styleText = strings.TrimSuffix(styleText, ",")
		styleText += "'"
		s += styleText + ":"
	}
	if sub.Wrap_unicode {
		s += "wrap_unicode:"
	}
	return strings.TrimSuffix(s, ":")
}

type SubtitleOption func(*Subtitle)

func NoSubtitle() SubtitleOption {
	return func(s *Subtitle) {
		s.omit = true
	}
}

func SubtitleOption_Filename(value string) SubtitleOption {
	return func(s *Subtitle) {
		s.Filename = value
	}
}

func SubtitleOption_Original_Size(width, height int) SubtitleOption {
	return func(s *Subtitle) {
		s.Original_Size = [2]int{width, height}
	}
}
func SubtitleOption_Fontsdir(value string) SubtitleOption {
	return func(s *Subtitle) {
		s.Fontsdir = value
	}
}
func SubtitleOption_Alpha(value bool) SubtitleOption {
	return func(s *Subtitle) {
		s.Alpha = value
	}
}
func SubtitleOption_Charenc(value string) SubtitleOption {
	return func(s *Subtitle) {
		s.Charenc = value
	}
}
func SubtitleOption_Stream_index(value int) SubtitleOption {
	return func(s *Subtitle) {
		s.Stream_index = value
	}
}
func SubtitleOption_Force_style(style hsubstyle.HardSubStyle) SubtitleOption {
	return func(s *Subtitle) {
		styleMap := style.ToMap()
		s.Force_style = styleMap
	}
}
func SubtitleOption_ForceStyleField(key, value string) SubtitleOption {
	return func(s *Subtitle) {
		s.Force_style[key] = value
	}
}

func SubtitleOption_Wrap_unicode(value bool) SubtitleOption {
	return func(s *Subtitle) {
		s.Wrap_unicode = value
	}
}

func styleFields() []string {
	return []string{
		sf_Name,
		sf_Fontname,
		sf_Fontsize,
		sf_PrimaryColour,
		sf_SecondaryColour,
		sf_OutlineColor,
		sf_BackColour,
		sf_Bold,
		sf_Italic,
		sf_Underline,
		sf_StrikeOut,
		sf_ScaleX,
		sf_ScaleY,
		sf_Spacing,
		sf_Angle,
		sf_BorderStyle,
		sf_Outline,
		sf_Shadow,
		sf_Alignment,
		sf_MarginL,
		sf_MarginR,
		sf_MarginV,
		sf_AlphaLevel,
		sf_Encoding,
	}
}
