package video

import (
	"fmt"
	"strings"
)

type Pad struct {
	// Specify an expression for the size of the output image with the paddings added. If the value for width or height is 0, the corresponding input size is used for the output.
	// The width expression can reference the value set by the height expression, and vice versa.
	// The default value of width and height is 0.
	Width  int
	Height int

	// Specify the offsets to place the input image at within the padded area, with respect to the top/left border of the output image.
	// The x expression can reference the value set by the y expression, and vice versa.
	// The default value of x and y is 0.
	// If x or y evaluate to a negative number, they’ll be changed so the input image is centered on the padded area.
	X int
	Y int

	// Specify the color of the padded area. For the syntax of this option, check the (ffmpeg-utils)"Color" section in the ffmpeg-utils manual.
	// The default value of color is "black".
	Color string

	// Specify when to evaluate width, height, x and y expression.
	// It accepts the following values:
	// ‘init’
	// Only evaluate expressions once during the filter initialization or when a command is processed.
	// ‘frame’
	// Evaluate expressions for each incoming frame.
	// Default value is ‘init’.
	Eval string

	omit bool
}

func NewPad(options ...PadOption) Pad {
	state := Pad{
		Width:  0,
		Height: 0,
		X:      0,
		Y:      0,
		Color:  "black",
		Eval:   "init",
		omit:   false,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (p *Pad) String() string {
	if p.omit {
		return ""
	}
	s := fmt.Sprintf("pad=%v:%v:%v:%v:", p.Width, p.Height, p.X, p.Y)
	if p.Color != "black" {
		s += fmt.Sprintf("color=%v:", p.Color)
	}
	if p.Eval != "init" {
		s += fmt.Sprintf("color=%v:", p.Eval)
	}
	return strings.TrimSuffix(s, ":")
}

type PadOption func(*Pad)

func PadOption_Output(w, h int) PadOption {
	return func(p *Pad) {
		p.Width = w
		p.Height = h
	}
}

func PadOption_Offset(x, y int) PadOption {
	return func(p *Pad) {
		p.X = x
		p.Y = y
	}
}

func PadOption_Color(value string) PadOption {
	return func(p *Pad) {
		p.Color = value
	}
}
func PadOption_Eval(value string) PadOption {
	return func(p *Pad) {
		p.Eval = value
	}
}

func PadOption_HD() PadOption {
	return func(p *Pad) {
		p.Width = 1920
		p.Height = 1080
	}
}

func PadOption_4K() PadOption {
	return func(p *Pad) {
		p.Width = 3840
		p.Height = 2160
	}
}

func PadOption_Centered() PadOption {
	return func(p *Pad) {
		p.X = -1
		p.Y = -1
	}
}

func PadOption_Horisontal() PadOption {
	return func(p *Pad) {
		p.X = 0
		p.Y = -1
	}
}

func PadOption_Vertical() PadOption {
	return func(p *Pad) {
		p.X = -1
		p.Y = 0
	}
}

func NoPad() PadOption {
	return func(p *Pad) {
		p.omit = true
	}
}
