package video

import "testing"

func TestSplit_String(t *testing.T) {
	sp1 := NewSplit()
	sp2 := NewSplit(NoSplit())
	sp3 := NewSplit(SplitOption_OutputsNumber(3))
	tests := []struct {
		name string
		sp   *Split
		want string
	}{
		{
			name: "default",
			sp:   &sp1,
			want: "split=2",
		}, // TODO: Add test cases.
		{
			name: "none",
			sp:   &sp2,
			want: "",
		}, // TODO: Add test cases.
		{
			name: "custom",
			sp:   &sp3,
			want: "split=3",
		}, // TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.sp.String(); got != tt.want {
				t.Errorf("Split.String() = %v, want %v", got, tt.want)
			}
		})
	}
}
