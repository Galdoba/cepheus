package video

import (
	"fmt"
	"strings"
)

type Crop struct {
	// The width of the output video. It defaults to iw. This expression is evaluated only once during the filter configuration, or when the ‘w’ or ‘out_w’ command is sent.
	Width int

	// The height of the output video. It defaults to ih. This expression is evaluated only once during the filter configuration, or when the ‘h’ or ‘out_h’ command is sent.
	Height int

	// The horizontal position, in the input video, of the left edge of the output video. It defaults to (in_w-out_w)/2. This expression is evaluated per-frame.
	X int

	// The vertical position, in the input video, of the top edge of the output video. It defaults to (in_h-out_h)/2. This expression is evaluated per-frame.
	Y int

	// If set to 1 will force the output display aspect ratio to be the same of the input, by changing the output sample aspect ratio. It defaults to 0.
	Keep_aspect int

	// Enable exact cropping. If enabled, subsampled videos will be cropped at exact width/height/x/y as specified and will not be rounded to nearest smaller value. It defaults to 0.
	Exact int

	omit bool
}

func NewCrop(options ...CropOption) Crop {
	state := Crop{
		Width:       0,
		Height:      0,
		X:           0,
		Y:           0,
		Keep_aspect: 0,
		Exact:       0,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (c *Crop) String() string {
	if c.omit {
		return ""
	}
	s := fmt.Sprintf("crop=%v:%v:%v:%v:", c.Width, c.Height, c.X, c.Y)
	if c.Keep_aspect != 0 {
		s += fmt.Sprintf("%v:", c.Keep_aspect)
	}
	if c.Exact != 0 {
		s += fmt.Sprintf("%v:", c.Exact)
	}
	return strings.TrimSuffix(s, ":")
}

type CropOption func(*Crop)

func CropOption_Size(width, height int) CropOption {
	return func(c *Crop) {
		c.Width = width
		c.Height = height
	}
}

func CropOption_Offset(x, y int) CropOption {
	return func(c *Crop) {
		c.X = x
		c.Y = y
	}
}

func CropOption_Keep_aspect(value int) CropOption {
	return func(c *Crop) {
		c.Keep_aspect = value
	}
}
func CropOption_Exact(value int) CropOption {
	return func(c *Crop) {
		c.Exact = value
	}
}
func NoCrop() CropOption {
	return func(c *Crop) {
		c.omit = true
	}
}
