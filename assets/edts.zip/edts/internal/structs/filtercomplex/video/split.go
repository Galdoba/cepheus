package video

import (
	"fmt"
)

type Split struct {
	// Split input into several identical outputs.
	// Works with video.
	// The filter accepts a single parameter which specifies the number of outputs. If unspecified, it defaults to 2.
	OutputsNumber int
	omit          bool
}

func NewSplit(options ...SplitOption) Split {
	state := Split{
		OutputsNumber: 2,
	}
	for _, modify := range options {
		modify(&state)
	}
	return state
}

func (sp *Split) String() string {
	if sp.omit {
		return ""
	}
	return fmt.Sprintf("split=%v", sp.OutputsNumber)
}

type SplitOption func(*Split)

func SplitOption_OutputsNumber(value int) SplitOption {
	return func(sp *Split) {
		sp.OutputsNumber = value
	}
}

func NoSplit() SplitOption {
	return func(sp *Split) {
		sp.omit = true
	}
}
