package hsubstyle

import "fmt"

const (
	Field_Name            = "Name"
	Field_Fontname        = "Fontname"
	Field_Fontsize        = "Fontsize"
	Field_PrimaryColour   = "PrimaryColour"
	Field_SecondaryColour = "SecondaryColour"
	Field_OutlineColor    = "OutlineColour"
	Field_BackColour      = "BackColour"
	Field_Bold            = "Bold"
	Field_Italic          = "Italic"
	Field_Underline       = "Underline"
	Field_StrikeOut       = "StrikeOut"
	Field_ScaleX          = "ScaleX"
	Field_ScaleY          = "ScaleY"
	Field_Spacing         = "Spacing"
	Field_Angle           = "Angle"
	Field_BorderStyle     = "BorderStyle"
	Field_Outline         = "Outline"
	Field_Shadow          = "Shadow"
	Field_Alignment       = "Alignment"
	Field_MarginL         = "MarginL"
	Field_MarginR         = "MarginR"
	Field_MarginV         = "MarginV"
	Field_AlphaLevel      = "AlphaLevel"
	Field_Encoding        = "Encoding"
)

type HardSubStyle struct {
	/*
		Styles define the appearance and position of subtitles. All styles used by the script are are defined by a Style line in the script.
		Any of the the settings in the Style, (except shadow/outline type and depth) can overridden by control codes in the subtitle text.
		The fields which appear in each Style definition line are named in a special line with the line type “Format:”. The Format line must appear before any Styles - because it defines how SSA will interpret the Style definition lines. The field names listed in the format line must be correctly spelled!
		The fields are as follows:
			Name
			Fontname
			Fontsize
			PrimaryColour
			SecondaryColour
			TertiaryColour
			BackColour
			Bold
			Italic
			Underline
			StrikeOut
			ScaleX
			ScaleY
			Spacing
			Angle
			BorderStyle
			Outline
			Shadow
			Alignment
			MarginL
			MarginR
			MarginV
			AlphaLevel
			Encoding

		The format line allows new fields to be added to the script format in future, and yet allow old versions of the software to read the fields it recognises - even if the field order is changed.

		examples: https://hhsprings.bitbucket.io/docs/programming/examples/ffmpeg/subtitle/ass.html
	*/
	//The name of the Style. Case sensitive. Cannot include commas.
	Name string

	//The fontname as used by Windows. Case-sensitive.
	Fontname string

	//Font size
	Fontsize float64
	// A long integer BGR (blue-green-red)  value. ie. the byte order in the hexadecimal equivelent of this number is BBGGRR
	// This is the colour that a subtitle will normally appear in.
	// example: PrimaryColour='&H00EBEBEB'
	PrimaryColour string

	// A long integer BGR (blue-green-red)  value. ie. the byte order in the hexadecimal equivelent of this number is BBGGRR
	// This colour may be used instead of the Primary colour when a subtitle is automatically shifted to prevent an onscreen collsion, to distinguish the different subtitles.
	SecondaryColour string

	// (TertiaryColour). A long integer BGR (blue-green-red)  value. ie. the byte order in the hexadecimal equivelent of this number is BBGGRR
	// This colour may be used instead of the Primary or Secondary colour when a subtitle is automatically shifted to prevent an onscreen collsion, to distinguish the different subtitles.
	OutlineColor string

	// This is the colour of the subtitle outline or shadow, if these are used. A long integer BGR (blue-green-red)  value. ie. the byte order in the hexadecimal equivelent of this number is BBGGRR.
	BackColour string

	// Field 4-7:  The color format contains the alpha channel, too. (AABBGGRR)

	// This defines whether text is bold (true) or not (false). -1 is True, 0 is False. This is independant of the Italic attribute - you can have have text which is both bold and italic.
	Bold bool

	// This defines whether text is italic (true) or not (false). -1 is True, 0 is False. This is independant of the bold attribute - you can have have text which is both bold and italic.
	Italic bool

	// [-1 or 0]
	Underline bool

	// [-1 or 0]
	Strikeout bool

	// Modifies the width of the font. [percent]
	ScaleX float64

	// Modifies the height of the font. [percent]
	ScaleY float64

	// Extra space between characters. [pixels]
	Spacing int

	// The origin of the rotation is defined by the alignment. Can be a floating point number. [degrees]
	Angle float64

	//BorderStyle. 1=Outline + drop shadow, 3=Opaque box
	BorderStyle int

	// If BorderStyle is 1,  then this specifies the width of the outline around the text, in pixels.
	// Values may be 0, 1, 2, 3 or 4.
	Outline float64

	// If BorderStyle is 1,  then this specifies the depth of the drop shadow behind the text, in pixels.
	// Values may be 0, 1, 2, 3 or 4. Drop shadow is always used in addition to an outline - SSA will force an outline of 1 pixel if no outline width is given.
	Shadow float64

	// Alignment values are based on the numeric keypad. 1 - bottom left, 2 - bottom center, 3 - bottom right, 4 - center left, 5 - center center, 6 - center right, 7 - top left, 8 - top center, 9 - top right. In addition to determining the position of the subtitle, this also determines the alignment of the text itself.
	// or
	// 1=Left, 2=Centered, 3=Right. Add 4 to the value for a "Toptitle". Add 8 to the value for a "Midtitle". eg. 5 = left-justified toptitle (this one works)
	Alignment int

	// This defines the Left Margin in pixels. It is the distance from the left-hand edge of the screen.The three onscreen margins (MarginL, MarginR, MarginV) define areas in which the subtitle text will be displayed.
	MarginL int

	// This defines the Right Margin in pixels. It is the distance from the right-hand edge of the screen. The three onscreen margins (MarginL, MarginR, MarginV) define areas in which the subtitle text will be displayed.
	MarginR int

	// This defines the vertical Left Margin in pixels.
	// For a subtitle, it is the distance from the bottom of the screen.
	// For a toptitle, it is the distance from the top of the screen.
	// For a midtitle, the value is ignored - the text will be vertically centred
	MarginV int

	// This specifies the font character set or encoding and on multi-lingual Windows installations it provides access to characters used in multiple than one languages. It is usually 0 (zero) for English (Western, ANSI) Windows.
	Encoding int
}

func ContentcomStyle() HardSubStyle {
	hs := HardSubStyle{
		Name:            "", //   "contentcom",
		Fontname:        "Segoe UI",
		Fontsize:        19.4,
		PrimaryColour:   "&H00EBEBEB",
		SecondaryColour: "&H000000FF",
		OutlineColor:    "&H00000000",
		BackColour:      "&H80000000",
		Bold:            false,
		Italic:          false,
		Underline:       false,
		Strikeout:       false,
		ScaleX:          1,
		ScaleY:          1,
		Spacing:         0,
		Angle:           0,
		BorderStyle:     1,
		Outline:         1,
		Shadow:          0,
		Alignment:       2,
		MarginL:         5,
		MarginR:         5,
		MarginV:         40,
		Encoding:        1,
	}
	return hs
}

func (s HardSubStyle) ToMap() map[string]string {
	styleMap := make(map[string]string)
	if s.Name != "" {
		styleMap[Field_Name] = s.Name
	}
	if s.Fontname != "" {
		styleMap[Field_Fontname] = s.Fontname
	}
	if s.Fontsize != 0 {
		styleMap[Field_Fontsize] = fmt.Sprintf("%v", s.Fontsize)
	}
	if s.PrimaryColour != "" {
		styleMap[Field_PrimaryColour] = s.PrimaryColour
	}
	if s.SecondaryColour != "" {
		styleMap[Field_SecondaryColour] = s.SecondaryColour
	}
	if s.OutlineColor != "" {
		styleMap[Field_OutlineColor] = s.OutlineColor
	}
	if s.BackColour != "" {
		styleMap[Field_BackColour] = s.BackColour
	}
	switch s.Bold {
	case true:
		styleMap[Field_Bold] = "-1"
	case false:
		styleMap[Field_Bold] = "0"
	}

	switch s.Italic {
	case true:
		styleMap[Field_Italic] = "-1"
	case false:
		styleMap[Field_Italic] = "0"
	}

	switch s.Underline {
	case true:
		styleMap[Field_Underline] = "-1"
	case false:
		styleMap[Field_Underline] = "0"
	}

	switch s.Strikeout {
	case true:
		styleMap[Field_StrikeOut] = "-1"
	case false:
		styleMap[Field_StrikeOut] = "0"
	}

	styleMap[Field_ScaleX] = fmt.Sprintf("%v", s.ScaleX)
	styleMap[Field_ScaleY] = fmt.Sprintf("%v", s.ScaleY)
	styleMap[Field_Spacing] = fmt.Sprintf("%v", s.Spacing)
	styleMap[Field_Angle] = fmt.Sprintf("%v", s.Angle)
	styleMap[Field_BorderStyle] = fmt.Sprintf("%v", s.BorderStyle)
	styleMap[Field_Outline] = fmt.Sprintf("%v", s.Outline)
	styleMap[Field_Shadow] = fmt.Sprintf("%v", s.Shadow)
	styleMap[Field_Alignment] = fmt.Sprintf("%v", s.Alignment)
	styleMap[Field_MarginL] = fmt.Sprintf("%v", s.MarginL)
	styleMap[Field_MarginR] = fmt.Sprintf("%v", s.MarginR)
	styleMap[Field_MarginV] = fmt.Sprintf("%v", s.MarginV)
	styleMap[Field_Encoding] = fmt.Sprintf("%v", s.Encoding)

	return styleMap
}
