package trailer

type Trailer struct {
	Priority       int
	Input          string
	OutputNameBase string
	SeasonTag      string
	DestinationDir string
	ArchiveDir     string
	//FC_Video
	FCV_Crop string
}

/*
PRIORITY=8
FILE="_____________"
OUTBASE="__________TRL"
EDIT_PATH="/mnt/pemaltynov/ROOT/EDIT/@trailers_temp"
ARCHIVE_PATH="/mnt/pemaltynov/ROOT/IN/@TRAILERS"
FC_AUD="aresample=48000,atempo=25/(__)"
FC_VID="scale=1920:-2,setsar=1/1,unsharp=3:3:0.3:3:3:0,pad=1920:1080:-1:-1"
AUDIO_OUT1="AUDIORUS__"
REV="_HD"
mkdir -p ${ARCHIVE_PATH}/_DONE/${OUTBASE}
mkdir -p ${EDIT_PATH}
clear && mv /home/pemaltynov/IN/${FILE} /home/pemaltynov/IN/_IN_PROGRESS/  && \
fflite -r 25 -i /home/pemaltynov/IN/_IN_PROGRESS/${FILE} \
-filter_complex "[0:v:0]${FC_VID}[video]; [0:a:0]${FC_AUD}[audio]" \
   -map "[video]" @crf10 ${EDIT_PATH}/${OUTBASE}${REV}.mp4 \
   -map "[audio]" @alac0 ${EDIT_PATH}/${OUTBASE}${REV}_${AUDIO_OUT1}.m4a
*/

/*
PRIORITY=8
FILE="_____________"
OUTBASE="__________TRL"
EDIT_PATH="/mnt/pemaltynov/ROOT/EDIT/@trailers_temp"
ARCHIVE_PATH="/mnt/pemaltynov/ROOT/IN/@TRAILERS"
FC_AUD="aresample=48000,atempo=25/(__)"
FC_VID="setsar=1/1"
FC_VID="scale=1920:-2,setsar=1/1,unsharp=3:3:0.3:3:3:0,pad=1920:1080:-1:-1"
AUDIO_OUT1="AUDIORUS__"
REV="_HD"
mkdir -p ${ARCHIVE_PATH}/_DONE/${OUTBASE}
mkdir -p ${EDIT_PATH}
clear && mv /home/pemaltynov/IN/${FILE} /home/pemaltynov/IN/_IN_PROGRESS/  && \
fflite -r 25 -i /home/pemaltynov/IN/_IN_PROGRESS/${FILE} \
-filter_complex "[0:v:0]${FC_VID}[video]; [0:a:0]${FC_AUD}[audio]" \
   -map "[video]" @crf10 ${EDIT_PATH}/${OUTBASE}${REV}.mp4 \
   -map "[audio]" @alac0 ${EDIT_PATH}/${OUTBASE}${REV}_${AUDIO_OUT1}.m4a && \
echo "\\\\nas\\root\\EDIT\\@trailers_temp\\${OUTBASE}${REV}" > /home/pemaltynov/IN/notifications/${OUTBASE}.done && \
mv /home/pemaltynov/IN/_IN_PROGRESS/${FILE} ${ARCHIVE_PATH}/_DONE/${OUTBASE} && clear && mv "$0" /home/pemaltynov/IN/_DONE/bash/
*/
