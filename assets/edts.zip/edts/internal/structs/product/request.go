package product

type ProductRequest struct {
	Field      map[string]string
	Candidates map[string][]string
}

type Scriptwriter interface {
	WriteScript() (string, error)
}
