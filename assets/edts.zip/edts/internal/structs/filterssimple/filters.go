package filterssimple

import (
	"strings"
)

type FilterSet struct {
	tags    []string
	filters map[string]string
}

func Preset(key string, tags ...string) FilterSet {
	f := FilterSet{
		tags:    []string{},
		filters: make(map[string]string),
	}
	if strings.Contains(key, "video") {
		f.filters["c:v"] = "-c:v libx264"
		f.filters["preset"] = "-preset medium"
		f.filters["crf"] = "-crf 16"
		f.filters["pix_fmt"] = "-pix_fmt yuv420p"
		f.filters["g"] = "-g 0"
		f.filters["map"] = "-map_metadata -1 -map_chapters -1"
	}
	if strings.Contains(key, "hd") {
		f.filters["c:v"] = "-c:v libx264"
		f.filters["preset"] = "-preset medium"
		f.filters["crf"] = "-crf 16"
		f.filters["pix_fmt"] = "-pix_fmt yuv420p"
		f.filters["g"] = "-g 0"
		f.filters["map"] = "-map_metadata -1 -map_chapters -1"
	}
	if strings.Contains(key, "4k") {
		f.filters["c:v"] = "-c:v libx264"
		f.filters["preset"] = "-preset medium"
		f.filters["crf"] = "-crf 18"
		f.filters["pix_fmt"] = "-pix_fmt yuv420p"
		f.filters["g"] = "-g 0"
		f.filters["map"] = "-map_metadata -1 -map_chapters -1"
	}
	if strings.Contains(key, "audio") {
		f.filters["c:a"] = "-c:a alac"
		f.filters["compression_level"] = "-compression_level 0"
		f.filters["map"] = "-map_metadata -1 -map_chapters -1"
	}
	if strings.Contains(key, "proxy") && strings.Contains(key, "video") {
		f.filters["c:v"] = "-c:v libx264"
		f.filters["x264opts"] = "-x264opts interlaced=1"
		f.filters["preset"] = "-preset superfast"
		f.filters["crf"] = ""
		f.filters["b:v"] = "-b:v 2000k"
		f.filters["maxrate"] = "-maxrate 2000k"
		f.filters["pix_fmt"] = "-pix_fmt yuv420p"
		f.filters["g"] = ""
		f.filters["map"] = "-map_metadata -1 -map_chapters -1"
		f.filters["c:a"] = ""
		f.filters["b:a"] = ""
		f.filters["compression_level"] = ""
	}
	if strings.Contains(key, "proxy") && strings.Contains(key, "audio") {
		f.filters["c:v"] = ""
		f.filters["x264opts"] = ""
		f.filters["preset"] = ""
		f.filters["crf"] = ""
		f.filters["b:v"] = ""
		f.filters["maxrate"] = ""
		f.filters["pix_fmt"] = ""
		f.filters["g"] = ""
		f.filters["map"] = "-map_metadata -1 -map_chapters -1"
		f.filters["c:a"] = "-c:a ac3"
		f.filters["b:a"] = "-b:a 128k"
		f.filters["compression_level"] = ""
	}
	//-map "[vidHD_pr]" -c:v libx264 -x264opts interlaced=1 -preset superfast -pix_fmt yuv420p  -b:v 2000k -maxrate 2000k -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}_proxy.mp4  \
	//-map "[arus]" -c:a alac -compression_level 0 -map_metadata -1 -map_chapters -1 ${EDIT_PATH}/${OUTBASE}${REV}_${AUDIO_OUT1}.m4a \
	//-map "[arus_pr]" -c:a ac3 -b:a 128k ${EDIT_PATH}/${OUTBASE}${REV}_${AUDIO_OUT1}_proxy.ac3 \
	return f
}

func (f *FilterSet) String() string {
	s := ""
	for _, key := range []string{
		"c:v",
		"x264opts",
		"preset",
		"crf",
		"pix_fmt",
		"g",
		"c:a",
		"compression_level",
		"b:v",
		"maxrate",
		"b:a",
		"map",
	} {
		switch value := f.filters[key]; value {
		case "":
		default:
			s += value + " "
		}
	}
	return strings.TrimSuffix(s, " ")
}
