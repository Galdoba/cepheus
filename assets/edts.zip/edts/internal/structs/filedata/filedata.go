package filedata

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
)

type Filedata struct {
	Directory string `json:"Directory"`
	Name      string `json:"Name"`
	IsDir     bool   `json:"IsDir"`
	LastWrite string `json:"Write Time,omitempty"`
	Size      string `json:"Size,omitempty"`
	Perm      string `json:"Permission,omitempty"`
	Err       string `json:"Error,omitempty"`
}

func Payload() map[string]*Filedata {
	return make(map[string]*Filedata)
}

// func (entry *Filedata) MarshalJSON0() ([]byte, error) {
// 	bt, err := json.MarshalIndent(entry, "", "  ")
// 	if err != nil {
// 		panic(1)
// 		return bt, err
// 	}
// 	return bt, err
// }

// func (entry *Filedata) Unstring(s string) error {
// 	bt := []byte(s)
// 	dummy := Filedata{}
// 	err := json.Unmarshal(bt, &dummy)
// 	if err != nil {
// 		return err
// 	}
// 	entry.Directory = dummy.Directory
// 	entry.Name = dummy.Name
// 	entry.IsDir = dummy.IsDir
// 	entry.LastWrite = dummy.LastWrite
// 	entry.Size = dummy.Size
// 	entry.Perm = dummy.Perm
// 	entry.Err = dummy.Err
// 	return nil
// }

// func (entry *Filedata) UnmarshalJSON0(bt []byte) error {

// 	err := json.Unmarshal(bt, &entry)
// 	if err != nil {
// 		panic(2)
// 	}

// 	return nil
// }

// func (entry *Filedata) String() string {
// 	return fmt.Sprintf("%v %v %v %v %v %v %v",
// 		entry.Directory,
// 		entry.Name,
// 		entry.IsDir,
// 		entry.LastWrite,
// 		entry.Size,
// 		entry.Perm,
// 		entry.Err,
// 	)
// }

func New(path string) *Filedata {
	fd := Filedata{}
	f, err := os.Stat(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to get stats: %v", err)
		fd.Err = "failed to get stats"
		return &fd
	}
	fd.Name = f.Name()

	if f.IsDir() {
		fd.IsDir = f.IsDir()
		fd.Directory = path
		fd.Directory = strings.ReplaceAll(fd.Directory, `\`, "/")
		fmt.Println(path, "set dir", dir(fd.Directory))
		return &fd
	}
	fd.Directory = dir(path)
	fd.Directory = strings.ReplaceAll(fd.Directory, `\`, "/")
	fd.Size = fmt.Sprintf("%v", f.Size())
	fd.Perm = f.Mode().Perm().String()
	switch runtime.GOOS {
	case "windows":
		// d := f.Sys().(*syscall.Win32FileAttributeData)
		//cTime := time.Unix(0, d.CreationTime.Nanoseconds())
		// cTime := time.Unix(0, d.LastWriteTime.Nanoseconds())
		// timeStamp := cTime.Format(time.DateTime)
		// fd.LastWrite = timeStamp
	case "linux":
		stat := f.Sys().(*syscall.Timespec)
		cTime := time.Unix(int64(stat.Sec), int64(stat.Nsec))
		timeStamp := cTime.Format(time.DateTime)
		fd.LastWrite = timeStamp
	}
	return &fd
}

func dir(path string) string {
	return strings.TrimSuffix(filepath.Dir(path), string(filepath.Separator)) + string(filepath.Separator)
}

type T2E struct {
	Param string   `json:"Parameter"`
	Arr   []string `json:"Parameter Array,omitempty"`
}

func (fd *Filedata) MarshalJSON() ([]byte, error) {
	type Alias *Filedata
	alias := Alias(fd)
	alias.Directory = fd.Directory
	alias.Name = fd.Name
	alias.IsDir = fd.IsDir
	alias.LastWrite = fd.LastWrite
	alias.Size = fd.Size
	alias.Perm = fd.Perm
	alias.Err = fd.Err
	bt, err := json.MarshalIndent(*alias, "", "  ")
	if err != nil {
		return nil, fmt.Errorf("failed to marshal *Filedata struct: %v", err)
	}
	return bt, nil
}

func (fd *Filedata) UnmarshalJSON(data []byte) error {
	type Alias *Filedata
	alias := Alias(fd)
	alias.Directory = fd.Directory
	alias.Name = fd.Name
	alias.IsDir = fd.IsDir
	alias.LastWrite = fd.LastWrite
	alias.Size = fd.Size
	alias.Perm = fd.Perm
	alias.Err = fd.Err
	err := json.Unmarshal(data, alias)
	if err != nil {
		return fmt.Errorf("failed to unmarshal: %v", err)
	}
	if fd.Directory != "" {
		return nil
	}
	if fd.Name != "" {
		return nil
	}
	return fmt.Errorf("*Filedata was unmarshaled as zero value (%v) \n[%v]", len(data), string(data))
}
