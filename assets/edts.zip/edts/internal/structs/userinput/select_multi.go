package userinput

import "github.com/charmbracelet/huh"

func SelectStringMulti(options ...UserSelectOption) []string {
	selected := []string{}
	selection := selectOtions{}
	for _, modify := range options {
		modify(&selection)
	}
	if selection.title == "" {
		return selected
	}
	if len(selection.options) < 1 {
		return selected
	}

	huh.NewMultiSelect[string]().Title(selection.title).
		Options(selection.options...).
		Value(&selected).
		Description(selection.description).
		Run()
	return selected
}
