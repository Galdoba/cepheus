package userinput

import "github.com/charmbracelet/huh"

func SelectString(options ...UserSelectOption) string {
	selected := ""
	selection := selectOtions{}
	for _, modify := range options {
		modify(&selection)
	}
	if selection.title == "" {
		return ""
	}
	if len(selection.options) < 1 {
		return ""
	}

	huh.NewSelect[string]().Title(selection.title).
		Options(selection.options...).
		Value(&selected).
		Description(selection.description).
		Run()
	return selected
}

type selectOtions struct {
	title       string
	options     []huh.Option[string]
	description string
}

type UserSelectOption func(*selectOtions)

func Title(title string) UserSelectOption {
	return func(so *selectOtions) {
		so.title = title
	}
}

func Description(desc string) UserSelectOption {
	return func(so *selectOtions) {
		so.description = desc
	}
}

func Options(options ...string) UserSelectOption {
	return func(so *selectOtions) {
		opts := []huh.Option[string]{}
		for _, op := range options {
			opts = append(opts, huh.NewOption[string](op, op))
		}
		so.options = opts
	}
}
