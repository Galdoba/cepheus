package scriptmaker

import (
	"fmt"
	"path/filepath"
	"strings"

	"github.com/Galdoba/edts/internal/structs/filtercomplex"
	"github.com/Galdoba/edts/internal/structs/filterssimple"
	"github.com/Galdoba/edts/internal/structs/streammapping"
)

type ScriptMaker struct {
	Inputs            []string
	Outputs           []string
	ScriptType        string
	BaseName          string
	Destination       string
	TargetDuration    float64
	TargetTags        map[string]string
	FC_gloabalFilters []*filtercomplex.FilterCall
	FC                *filtercomplex.FilterComplex
	TargetStreams     []streammapping.OutputStream
	Declarations      []string
	Processors        []string
}

func New(options ...ScriptMakerOption) *ScriptMaker {
	sm := ScriptMaker{
		Inputs:            []string{},
		Outputs:           []string{},
		ScriptType:        "",
		BaseName:          "",
		Destination:       "",
		TargetDuration:    0,
		TargetTags:        make(map[string]string),
		FC_gloabalFilters: []*filtercomplex.FilterCall{},
		FC:                &filtercomplex.FilterComplex{},
		TargetStreams:     []streammapping.OutputStream{},
		Declarations:      []string{},
		Processors:        []string{},
	}
	for _, modify := range options {
		modify(&sm)
	}
	return &sm
}

type ScriptMakerOption func(*ScriptMaker)

func InputFiles(paths ...string) ScriptMakerOption {
	return func(sm *ScriptMaker) {
		sm.Inputs = paths
	}
}

func ScriptType(script string) ScriptMakerOption {
	return func(sm *ScriptMaker) {
		sm.ScriptType = script
	}
}

func OutBase(basename string) ScriptMakerOption {
	return func(sm *ScriptMaker) {
		sm.BaseName = basename
	}
}

func Destination(destination string) ScriptMakerOption {
	return func(sm *ScriptMaker) {
		sm.Destination = destination
	}
}

///////////////////

func (sm *ScriptMaker) Make() error {
	streams, err := streammapping.Assess(
		streammapping.InputFiles(sm.Inputs...),
		streammapping.ProductType(sm.ScriptType),
	)
	if err != nil {
		return fmt.Errorf("assessing failed: %v", err)
	}
	if sm.ScriptType == "TRL" {
		sm.Destination = "//192.168.31.4/root/EDIT/@trailers_temp/"
	}
	sm.TargetStreams = streams
	sm.Declarations = streammapping.InputFilePaths(sm.TargetStreams)
	sm.FC = filtercomplex.WithFilterCalls(filtercomplex.OptionSetByTags(streammapping.Tags(sm.TargetStreams...)...)...)
	ins, outs := []string{}, []string{}
	for _, stream := range streams {
		in, out := stream.Bridge()
		ins = append(ins, in)
		outs = append(outs, out)
	}
	if err := sm.FC.InjectMappings(ins, outs); err != nil {
		return fmt.Errorf("failed to inject mappings: %v", err)
	}

	// for _, statement := range sm.FC.Statements {
	// 	//fmt.Println(statement.String())
	// }
	for _, stream := range streams {
		_, out := stream.Bridge()
		if strings.Contains(out, "hd") {
			sm.TargetTags["size"] = "HD"
		}
		if strings.Contains(out, "4k") {
			sm.TargetTags["size"] = "4K"
		}
	}
	//panic("проверить функцию; добавить имя и папку для выхода")
	return nil
}

func (sm *ScriptMaker) Script() string {
	s := ""
	s += fmt.Sprintf("ffmpeg ")
	for _, declaration := range sm.Declarations {
		s += fmt.Sprintf("-r 25 -i %v \n", declaration)
	}
	s += fmt.Sprintf(`-filter_complex "%v" `, sm.FC.String()) + "\n"

	for _, outmap := range sm.ListProductMappings() {
		line := fmt.Sprintf(" -map %v %v %v", outmap, "{out_filters}", "{out_path}")
	streamCheck:
		for _, stream := range sm.TargetStreams {
			for _, out := range stream.OutMapsSeparated() {
				if out != outmap {
					continue
				}
			}

			preset := filterssimple.Preset(outmap, stream.Tags...)
			line = strings.ReplaceAll(line, "{out_filters}", preset.String())
			suffix := NameSuffix(*sm, outmap)
			if !strings.Contains(outmap, "proxy") {
				suffix = strings.ReplaceAll(suffix, "_proxy", "")
			}

			line = strings.ReplaceAll(line, "{out_path}", fmt.Sprintf("%v_%v", filepath.ToSlash(filepath.Join(sm.Destination, sm.BaseName)), suffix))
			break streamCheck
		}
		s += line + "\n"
	}
	s = strings.ReplaceAll(s, "atempo=1.0416666666666667", "atempo=25/(24)")
	s = strings.ReplaceAll(s, "atempo=1.0427083333333333", "atempo=25/(24000/1001)")
	s = strings.ReplaceAll(s, "atempo=1[", "atempo=25/(25)[")

	return s
}

func (sm *ScriptMaker) ListProductMappings() []string {
	list := []string{}
	for _, outmaps := range streammapping.OutMaps(sm.TargetStreams) {
		for _, outmap := range filtercomplex.SplitMappingDeclaration(outmaps) {
			list = append(list, outmap)
		}
	}
	return list
}

func NameSuffix(sm ScriptMaker, outMapping string) string {
	s := ""
	switch sm.ScriptType {
	case streammapping.ProdType_TRL:
		s += "TRL_"
	case streammapping.ProdType_FILM:
		// s += "[flm]_"
		// panic(1)
	}
	if sm.TargetTags["size"] != "" {
		s += sm.TargetTags["size"]
	}
	// if i >= len(sm.TargetStreams) {
	// 	fmt.Println(sm.TargetStreams)
	// 	panic(0)
	// 	return "SUFFIX_FOR_STREAM_" + fmt.Sprintf("%v", i) + ".zzz"
	// }
	// _, out := sm.TargetStreams[i].Bridge()
	ext := ".mp4"
	if strings.Contains(outMapping, "audio") {
		s += "_AUDIORUS"
		if strings.Contains(outMapping, "20") {
			s += "20"
		}
		if strings.Contains(outMapping, "51") {
			s += "51"
		}
		ext = ".m4a"
		if strings.Contains(outMapping, "proxy") {
			ext = ".ac3"
		}
	}
	if strings.Contains(outMapping, "proxy") {
		s += "_proxy"
	}
	s += ext
	return s
}
