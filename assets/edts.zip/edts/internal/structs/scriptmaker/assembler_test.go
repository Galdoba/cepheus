package scriptmaker

import (
	"fmt"
	"testing"
)

func TestScriptMaker_Script(t *testing.T) {
	sm := New(
		InputFiles(`\\192.168.31.4\root\IN\@TRAILERS\_DONE\Chelovek_nevidimka_vozvrashenie_legendy_TRL\FearTheInvisibleMan_TRL_1080_RU-XX_12_20_24fps_H264_30Mbt.mp4`),
		ScriptType(`FLM`),
		OutBase(`Titanik_nepotoplyaemaya_mechta`),
		Destination(`/path/to/destination/`),
	)
	if err := sm.Make(); err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(sm.Script())

	sm = New(
		InputFiles(`\\192.168.31.4\root\IN\@TRAILERS\_DONE\Chelovek_nevidimka_vozvrashenie_legendy_TRL\FearTheInvisibleMan_TRL_1080_RU-XX_12_20_24fps_H264_30Mbt.mp4`),
		ScriptType(`TRL`),
		OutBase(`Titanik_nepotoplyaemaya_mechta`),
		Destination(`/path/to/destination/`),
	)
	if err := sm.Make(); err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(sm.Script())

	sm = New(
		InputFiles(`\\192.168.31.4\buffer\IN\test_trl_in.mp4`),
		ScriptType(`TRL`),
		OutBase(`Test_trailer_out`),
		Destination(`/mnt/pemaltynov/ROOT/EDIT/@trailers_temp`),
	)
	if err := sm.Make(); err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(sm.Script())
}
