package definitions

import "fmt"

const (
	SYSTEM                      = "edts"
	CLIENT_PROJECT_MANAGER      = "edts-client"
	SERVICE_DIRECTORY_TRACKER   = "edts-directory-tracker-service"
	SERVICE_DISPATCHER          = "edts-dispatcher-service"
	SERVICE_EVENT_BROKER        = "edts-event-broker-service"
	SERVICE_FILENAME_NORMALIZER = "edts-filename-normalizer-service"
	SERVICE_SPREADSHEET_TRACKER = "edts-spreadsheet-tracker-service"
	UTILITY_KVAL                = "edts-kval-utility"
	UTILITY_GET                 = "edts-get"
	UTILITY_EVENT_MANAGER       = "edts-event-manager"
	UTILITY_SCRIPT_WRITER       = "edts-script-writer"
	UTILITY_RENAMER             = "edts-renamer"
)

func Version(app string) string {
	switch app {
	case CLIENT_PROJECT_MANAGER:
		return "0.0.1"
	case SERVICE_DIRECTORY_TRACKER:
		return "0.0.2"
	case SERVICE_EVENT_BROKER:
		return "0.0.2"
	case SERVICE_FILENAME_NORMALIZER:
		return "0.0.2"
	case SERVICE_SPREADSHEET_TRACKER:
		return "0.0.2"
	case UTILITY_KVAL:
		return "0.0.1"
	default:
		return fmt.Sprintf("no version for '%v'", app)
	}
}

func AppsList() []string {
	return []string{
		CLIENT_PROJECT_MANAGER,
		SERVICE_DIRECTORY_TRACKER,
		SERVICE_EVENT_BROKER,
		SERVICE_FILENAME_NORMALIZER,
		SERVICE_SPREADSHEET_TRACKER,
		UTILITY_SCRIPT_WRITER,
	}
}

var TableDB_Path = `c:\Users\pemaltynov\Programs\galdoba\edts\edts-spreadsheet-tracker-service\storage\spreadsheet_data.json`
