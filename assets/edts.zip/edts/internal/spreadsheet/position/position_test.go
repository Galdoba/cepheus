package position

import (
	"fmt"
	"testing"
)

func TestPosition(t *testing.T) {
	fmt.Printf("%v\n", Position("A5").String())
	fmt.Printf("%v\n", Position("AA15").String())
	fmt.Printf("%v\n", Coordinates(5, 5).String())
	fmt.Printf("%v\n", Coordinates(0, 0).String())
	fmt.Printf("%v\n", Coordinates(2, 2).String())
	fmt.Printf("%v\n", Coordinates(2, 2).Pos())
	fmt.Println(Coordinates(2, 2).Coords())
	fmt.Println(Position("C2").Coords())
	fmt.Printf("%v\n", Coordinates(0, -1).String())
	fmt.Printf("%v\n", Coordinates(-2, 5).String())
}
