package position

import (
	"errors"
	"fmt"
	"math"
	"slices"
	"strconv"
	"strings"
)

type CellPositioning struct {
	List     string `json:"list,omitempty"`
	Position string `json:"position"`
	Row      int    `json:"row"`
	Column   int    `json:"column"`
	err      error
}

func Position(pos string) CellPositioning {
	c := CellPositioning{}
	c.Position = pos
	c.Row, c.Column, c.err = positionToCoordinates(c.Position)
	return c
}

func Coordinates(row, col int) CellPositioning {
	c := CellPositioning{}
	c.Row, c.Column = row, col
	code, err := columnToCode(ColumnCodes, c.Column)
	if err != nil {
		c.err = err
		return c
	}
	rowStr, err := rowToCode(c.Row)
	if err != nil {
		c.err = err
		return c
	}
	c.Position = fmt.Sprintf("%v%v", code, rowStr)
	return c
}

func (cp CellPositioning) String() string {
	pos := cp.Position
	if cp.List != "" {
		pos = cp.List + ":" + pos
	}
	if cp.err != nil {
		return fmt.Sprintf("cell '%v' (%v, %v): error: %v", pos, cp.Row, cp.Column, cp.err)
	}
	return fmt.Sprintf("cell '%v' (%v, %v)", pos, cp.Row, cp.Column)
}

func (cp CellPositioning) Pos() string {
	if cp.err != nil {
		return ""
	}
	return cp.Position
}

func (cp CellPositioning) Coords() (int, int) {
	if cp.err != nil {
		return -1, -1
	}
	return cp.Row, cp.Column
}

func (cp CellPositioning) Validate() error {
	if cp.err != nil {
		return cp.err
	}
	return nil
}

//calculations

func columnToCode(codeValues []string, i int) (string, error) {
	if i < 0 {
		return "", fmt.Errorf("negaive column provided: %v", i)
	}
	if i >= 0 && i <= len(codeValues)-1 {
		return codeValues[i], nil
	}
	suffix_nums := []int{}
	current := i
	rest := current
	columnCodesNum := len(codeValues)
	for current > columnCodesNum-1 {
		code := current % (columnCodesNum)
		rest = (current / columnCodesNum) - 1
		current = rest
		suffix_nums = append(suffix_nums, code)
	}
	suffix_nums = append(suffix_nums, rest)
	code := ""
	for l := len(suffix_nums) - 1; l >= 0; l-- {
		code += codeValues[suffix_nums[l]]
	}
	return code, nil
}

func rowToCode(row int) (string, error) {
	if row < 0 {
		return "", fmt.Errorf("negative row provided: %v", row)
	}
	return fmt.Sprintf("%v", row+1), nil
}

func codeToNumber(codeValues []string, code string) (int, error) {
	if code == "" {
		return 0, errors.New("code is empty")
	}
	codeSplits := strings.Split(code, "")
	vals := []int{}
codeLoop:
	for _, split := range codeSplits {
		for i, val := range codeValues {
			if val == split {
				vals = append(vals, i)
				continue codeLoop
			}
		}
		return 0, fmt.Errorf("no value %v from code %v in codeValues provided: %v", split, code, codeValues)
	}
	num := 0
	switch len(vals) {
	case 1:
		return vals[0], nil
	default:
		codeSliced := strings.Split(code, "")
		slices.Reverse(codeSliced)
		for p, val := range codeSliced {
			switch p {
			case 0:
				sliceNum, err := codeToNumber(codeValues, val)
				if err != nil {
					return 0, err
				}
				num += sliceNum
			default:
				sliceNum, err := codeToNumber(codeValues, val)
				if err != nil {
					return 0, err
				}
				valuePowered := powerOf(len(codeValues), p) * (sliceNum + 1)
				num += valuePowered
			}
		}
	}
	return num, nil
}

func powerOf(int1, p int) int {
	f1 := float64(int1)
	power := float64(p)
	val := math.Pow(f1, power)
	return int(val)
}

func positionToCoordinates(pos string) (int, int, error) {
	rowStr, colStr, err := splitPosition(pos)
	if err != nil {
		return -1, -1, err
	}
	row, err := strconv.Atoi(rowStr)
	if err != nil {
		return -1, -1, err
	}
	row--
	col, err := codeToNumber(ColumnCodes, colStr)
	if err != nil {
		return row, -1, err
	}
	return row, col, nil
}

var ColumnCodes = []string{
	"A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
	"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
	"U", "V", "W", "X", "Y", "Z"}

func splitPosition(pos string) (string, string, error) {
	vals := strings.Split(pos, "")
	colStr, rowStr := "", ""
	doneColumn := false
	for _, val := range vals {
		switch val {
		case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9":
			if len(colStr) == 0 {
				return "", "", fmt.Errorf("invalid position code: %v", pos)
			}
			rowStr += val
			doneColumn = true
		case "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
			"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
			"U", "V", "W", "X", "Y", "Z":
			if doneColumn {
				return "", "", fmt.Errorf("invalid position code: %v", pos)
			}
			colStr += val
		default:
			return "", "", fmt.Errorf("invalid position code: %v", pos)
		}
	}
	return rowStr, colStr, nil

}
