package gsagent

import (
	"fmt"
	"time"

	"github.com/Galdoba/edts/internal/spreadsheet/position"
)

// Fetch - get data on spreadsheet and activates the sheet list to track.
func (sa *SpreadsheetAgent) Fetch() error {
	if sa.spreadsheetTitle == "" {
		return fmt.Errorf("can't fetch spreadsheet: table title not set")
	}
	spreadsheet, err := sa.service.FetchSpreadsheet(sa.spreadsheetID)
	if err != nil {
		return fmt.Errorf("failed to fetch: %v", err)
	}
	sa.spreadsheet = spreadsheet
	if err := sa.SetSheet(sa.spreadsheetTitle); err != nil {
		return err
	}
	return nil
}

// SetSheet - switch agent to track enother sheet list.
func (sa *SpreadsheetAgent) SetSheet(title string) error {
	sheet, err := sa.spreadsheet.SheetByTitle(title)
	if err != nil {
		return err
	}
	sa.sheet = sheet
	return nil
}

// GetCells - считывает все ячейки, извлекает значения тех, что совпадают с предоставленными позициями.
// Если колличество предоставленных позиций равно 0, то извлекает значения всех ячеек.
// Возвращает ТОЛЬКО считанные ячейки ибо так решил создатель.
func GetCells[T PositionRetriever](sa *SpreadsheetAgent, coords ...T) (map[string]Cell, error) {
	if sa.sheet == nil {
		panic("sheet was not set: run Fetch function")
	}
	cellPositions := []string{}
	coords = filterSlice(coords)
	for _, coord := range coords {
		crd, err := uniPos(coord)
		if err != nil {
			return nil, fmt.Errorf("failed to cypher coordinate %v: %v", coord, err)
		}
		cellPositions = append(cellPositions, crd)
	}
	cellsExtracted := make(map[string]Cell)
	updateTime := time.Now().Unix()
	for r, row := range sa.sheet.Rows {
		for c, cell := range row {
			pos := cell.Pos()
			switch len(coords) {
			case 0:
			default:
				if !inSlice(cellPositions, pos) {
					continue
				}
			}
			cellsExtracted[pos] = Cell{Position: pos, Column: c, Row: r, Value: cell.Value, Note: cell.Note, UpdateTime: updateTime, Error: nil}
		}
	}

	for k, v := range cellsExtracted {
		sa.cellsExtracted[k] = v
	}
	return cellsExtracted, nil
}

///////////////////////////////////////

func filterSlice[T PositionRetriever](slice []T) []T {
	count := make(map[string]int)
	for _, element := range slice {
		count[fmt.Sprintf("%v", element)]++
	}
	filtered := []T{}
	for _, element := range slice {
		if count[fmt.Sprintf("%v", element)] == 1 {
			filtered = append(filtered, element)
		}
	}
	return filtered
}

func inSlice[T PositionRetriever](slice []T, elem T) bool {
	for _, s := range slice {
		if fmt.Sprintf("%v", s) == fmt.Sprintf("%v", elem) {
			return true
		}
	}
	return false
}

type PositionRetriever interface {
	position.CellPositioning | string
}

func uniPos[T PositionRetriever](input T) (string, error) {
	switch t := any(input).(type) {
	case string:
		crd := position.Position(t)
		if err := crd.Validate(); err != nil {
			return "", err
		}
		return crd.Position, nil
	case position.CellPositioning:
		if err := t.Validate(); err != nil {
			return "", err
		}
		return t.Position, nil
	default:
		return "", fmt.Errorf("invalid position argument type (expect string or spreadsheetagent.CellCoordiantes) : %T", t)
	}
}
