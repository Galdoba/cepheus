package gsagent

import (
	"fmt"

	"github.com/Galdoba/edts/internal/spreadsheet/position"
)

type Cell struct {
	Position   string `json:"position"`
	Row        int    `json:"row"`
	Column     int    `json:"column"`
	Value      string `json:"value,omitempty"`
	Note       string `json:"note,omitempty"`
	UpdateTime int64  `json:"update unixtime"`
	Error      error  `json:"error,omitempty"`
}

func NewCellWithPosition(pos string, opts ...CellOption) (Cell, error) {
	cell := Cell{}
	coordinates := position.Position(pos)
	if err := coordinates.Validate(); err != nil {
		return cell, fmt.Errorf("failed to create cell: %v", err)
	}
	cell.Position = pos
	cell.Column = coordinates.Column
	cell.Row = coordinates.Row
	for _, enrich := range opts {
		enrich(&cell)
	}
	return cell, nil
}

func NewCellWithCoordinates(row, col int, opts ...CellOption) (Cell, error) {
	cell := Cell{}
	coordinates := position.Coordinates(row, col)
	if err := coordinates.Validate(); err != nil {
		return cell, fmt.Errorf("failed to create cell: %v", err)
	}
	cell.Position = coordinates.Position
	cell.Column = coordinates.Column
	cell.Row = coordinates.Row
	for _, enrich := range opts {
		enrich(&cell)
	}
	return cell, nil
}

type CellOption func(*Cell)

func WithValue(val string) CellOption {
	return func(c *Cell) {
		c.Value = val
	}
}

func WithNote(note string) CellOption {
	return func(c *Cell) {
		c.Note = note
	}
}
