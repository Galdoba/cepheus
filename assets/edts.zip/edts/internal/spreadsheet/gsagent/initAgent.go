package gsagent

import (
	"context"
	"fmt"
	"os"

	"golang.org/x/oauth2/google"
	"gopkg.in/Iwark/spreadsheet.v2"
)

func initService(credentials string) (*spreadsheet.Service, error) {
	credData, err := os.ReadFile(credentials)
	if err != nil {
		return nil, fmt.Errorf("failed to read credetinals: %v", err)
	}
	conf, err := google.JWTConfigFromJSON(credData, spreadsheet.Scope)
	if err != nil {
		return nil, fmt.Errorf("failed to create service configuration: %v", err)
	}
	client := conf.Client(context.TODO())
	service := spreadsheet.NewServiceWithClient(client)

	return service, nil
}
