package gsagent

import (
	"testing"
)

func TestSpreadsheetIDfromAdress(t *testing.T) {
	// // sheetID, err := SpreadsheetIDfromAdress(`https://docs.google.com/spreadsheets/d/1Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg/edit?gid=250314867#gid=250314867`)
	// // fmt.Println(err)
	// // fmt.Println(sheetID)
	// cred := `c:\Users\pemaltynov\.credentials\tablegrabber.json`
	// adress := `https://docs.google.com/spreadsheets/d/1Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg/edit?gid=250314867#gid=250314867`
	// //adressBAD := `https://docs.google.com/spreadsheets/d/01Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg/edit?gid=250314867#gid=250314867`
	// title := "График работ 2.0"
	// sa, err := NewAgent(
	// 	WithCredentials(cred),
	// 	WithAdress(adress),
	// 	WithTitle(title),
	// )
	// if err != nil {
	// 	t.Errorf("%v", err)
	// }
	// fmt.Println("start fetch")
	// if err := sa.Fetch(); err != nil {
	// 	t.Errorf("%v", err)
	// }

	// fmt.Println("start update")
	// err = sa.UpdateCellValue("A2797", "rakaraka")
	// err = sa.UpdateCellNote("B2797", "Me PATHS")
	// if err != nil {
	// 	t.Errorf("%v", err)
	// }
	// fmt.Println("start sync")
	// sa.sheet.Synchronize()
	// fmt.Println("end update")
	// //UpdateCell(sa, newCell, conditions...) error
}
