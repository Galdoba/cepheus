package gsagent

import (
	"fmt"

	"github.com/Galdoba/edts/internal/spreadsheet/position"
)

/*
Возможность синхронизировать есть только в один шит, значит пишем тоже только в один.
шиттайтл отвечает за активный шит - перед апдейтом нужно назначить шит по имени

	sa.UpdateSheet(map[coords/position]newValue) error - как-то так?
	Хочу запихивать координаты числами и стрингом
	coords := SetPosition(args ...interface{}) *CellCoordinates

*/

func (sa *SpreadsheetAgent) UpdateCellValue(pos string, newValue string) error {
	cell := position.Position(pos)
	if err := cell.Validate(); err != nil {
		return fmt.Errorf("failed to update cell value: %v", err)
	}
	sa.sheet.Update(cell.Row, cell.Column, newValue)
	return nil
}

func (sa *SpreadsheetAgent) UpdateCellNote(pos string, newValue string) error {
	cell := position.Position(pos)
	if err := cell.Validate(); err != nil {
		return fmt.Errorf("failed to update cell note: %v", err)
	}
	sa.sheet.UpdateNote(cell.Row, cell.Column, newValue)
	return nil
}

// func (sa *SpreadsheetAgent) validatePosition(pos string) (position.CellPositioning, error) {

// 	if sa.sheet == nil {
// 		return position.CellPositioning{}, fmt.Errorf("must fetch spreadsheet before writing")
// 	}
// 	//crd, err := PositionToCoordinates(pos)
// 	cellPosition := position.Position(pos)
// 	if err := cellPosition.Validate(); err != nil {

// 	}
// 	if err != nil {
// 		return position.CellPositioning{}, fmt.Errorf("bad position provided %v: %v", position, err)
// 	}
// 	if crd.col >= len(sa.sheet.Columns) {
// 		return position.CellPositioning{}, fmt.Errorf("column provided is out of bounds %v: %v", position, err)
// 	}
// 	if crd.row >= len(sa.sheet.Rows) {
// 		return position.CellPositioning{}, fmt.Errorf("row provided is out of bounds %v: %v", position, err)
// 	}
// 	return cellPosition, nil
// }

func (sa *SpreadsheetAgent) UpdateCellNotes(cells ...Cell) {
	for _, cell := range cells {
		sa.sheet.Update(cell.Row, cell.Column, cell.Value)
	}
}

func (sa *SpreadsheetAgent) Sync() (map[string]Cell, error) {
	err := sa.sheet.Synchronize()
	if err != nil {
		return nil, fmt.Errorf("sync failed: %v", err)
	}
	return GetCells(sa, []string{}...)
}
