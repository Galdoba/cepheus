package gsagent

import (
	"testing"

	"github.com/Galdoba/edts/internal/transcode"
)

func TestSpreadsheetAgent_SetPath(t *testing.T) {
	cred := `c:\Users\pemaltynov\.credentials\tablegrabber.json`
	adress := `https://docs.google.com/spreadsheets/d/1Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg/edit?gid=250314867#gid=250314867`
	//adressBAD := `https://docs.google.com/spreadsheets/d/01Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg/edit?gid=250314867#gid=250314867`
	title := "График работ 2.0"
	sa, err := NewAgent(
		WithCredentials(cred),
		WithAdress(adress),
		WithTitle(title),
	)
	prj, err := transcode.Load(`c:\Users\pemaltynov\Programs\galdoba\edts\edts-project-manager-client\storage\03_obrabotka_30.01.2026.json`)
	if err != nil {
		t.Error(err)
	}
	err = sa.FillPathColumn(prj)
	if err != nil {
		t.Error(err)
	}

}
