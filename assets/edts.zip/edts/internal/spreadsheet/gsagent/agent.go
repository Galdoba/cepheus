package gsagent

import (
	"fmt"

	"github.com/Galdoba/edts/internal/spreadsheet/schema"
	"gopkg.in/Iwark/spreadsheet.v2"
)

/*
Агент записывает данные в 3 этапа:
	Чтение таблицы (Fetch)
	Формирование запросов на изменение (Update)
	Синхронизация (Synchronize)

*возможно имеет смысл добавить проверку изменились ли ячейки со времени последнего чтения, но это звучит как лишнее усложнение
Логика работы тогда должна быть следующей:
агент читает таблицу при запуске (6-8 секунд)
из вне я должен понять какие и сколько ячеек хочу изменить, привязывая их к проекту.
агент должен формировать относительные координаты ячеек (строка --> проект)
после агент еще раз считывает таблицу  и делает поправки на координаты
затем идет куча апдейтов по обновленным координатам
и после этого запускаем синхронизацию

*/

type SpreadsheetAgent struct {
	credentialsPath   string
	spreadsheetAdress string
	spreadsheetID     string
	spreadsheetTitle  string
	service           *spreadsheet.Service
	spreadsheet       spreadsheet.Spreadsheet
	sheet             *spreadsheet.Sheet
	schema            schema.SpreadsheetSchema
	cellsExtracted    map[string]Cell
	//columnDesignation map[string]int
}

func NewAgent(options ...AgentOptions) (*SpreadsheetAgent, error) {
	sa := SpreadsheetAgent{}
	sa.schema = schema.ContentcomSchema
	for _, enrich := range options {
		enrich(&sa)
	}
	if sa.credentialsPath == "" {
		return nil, fmt.Errorf("spreadsheet crederntials filepath is not set: use WithCredentials(string) option")
	}
	if sa.spreadsheetID == "" {
		return nil, fmt.Errorf("spreadsheet id is not set: use WithTableID(string) option")
	}
	service, err := initService(sa.credentialsPath)
	if err != nil {
		return nil, fmt.Errorf("failed to init agent: %v", err)
	}
	sa.service = service

	// ssID, err := SpreadsheetIDfromAdress(sa.spreadsheetAdress)
	// if err != nil {
	// 	return nil, fmt.Errorf("failed to get spreadsheet ID: %v", err)
	// }
	// sa.spreadsheetID = ssID
	sa.cellsExtracted = make(map[string]Cell)

	return &sa, nil

}

func (sa *SpreadsheetAgent) SetSheetName(sheetname string) {
	sa.spreadsheetTitle = sheetname
}

type AgentOptions func(*SpreadsheetAgent)

func WithCredentials(path string) AgentOptions {
	return func(sa *SpreadsheetAgent) {
		sa.credentialsPath = path
	}
}

func WithAdress(adress string) AgentOptions {
	return func(sa *SpreadsheetAgent) {
		sa.spreadsheetAdress = adress
	}
}

func WithTableID(id string) AgentOptions {
	return func(sa *SpreadsheetAgent) {
		sa.spreadsheetID = id
	}
}

func WithTitle(title string) AgentOptions {
	return func(sa *SpreadsheetAgent) {
		sa.spreadsheetTitle = title
	}
}

func WithCustomDesignation(schema schema.SpreadsheetSchema) AgentOptions {
	return func(sa *SpreadsheetAgent) {
		sa.schema = schema
	}
}

func (sa *SpreadsheetAgent) Sheet() *spreadsheet.Sheet {
	return sa.sheet
}
