package gsagent

import (
	"fmt"
	"strings"

	"github.com/Galdoba/edts/internal/spreadsheet/position"
	"github.com/Galdoba/edts/internal/spreadsheet/schema"
	"github.com/Galdoba/edts/internal/transcode"
)

func (sa *SpreadsheetAgent) FillPathColumn(prj *transcode.Project) error {
	titleValue := prj.Title
	dateValue := prj.DateBlock
	candidates := []int{}
	control := sa.schema.ColumnDesignatedAs(schema.COL_LABEL_PROJECT)
	titleColumn := sa.schema.ColumnDesignatedAs(schema.COL_Title)
	dateColumn := sa.schema.ColumnDesignatedAs(schema.COL_PublicationDate)
	pathColumn := sa.schema.ColumnDesignatedAs(schema.COL_Path)
	if err := sa.Fetch(); err != nil {
		return fmt.Errorf("failed to fetch: %v", err)
	}
	if len(sa.sheet.Rows) < 1 {
		return fmt.Errorf("no rows were found")
	}
	for k, v := range sa.schema.DesignationColumnMap {
		if len(sa.sheet.Columns) <= v {
			return fmt.Errorf("no designated column found for %v:%v", k, v)
		}
	}

	for r, row := range sa.sheet.Rows {
		//if row[sa.schema.ColumnDesignatedAs(schema.COL_LABEL_PROJECT)].Value != "" &&
		if row[control].Value != "" &&
			row[titleColumn].Value == titleValue &&
			row[dateColumn].Value == dateValue {
			candidates = append(candidates, r)
		}
	}
	switch len(candidates) {
	case 0:
		return fmt.Errorf("no candidate row found for %v:%v", titleValue, dateValue)
	default:
		return fmt.Errorf("multiple candidate rows found for %v:%v = %v", titleValue, dateValue, candidates)
	case 1:
	}
	//pos := CellCoordinates{row: candidates[0], col: pathColumn}.Position()
	pos := position.Coordinates(candidates[0], pathColumn).Position
	winpath := strings.ReplaceAll(prj.EditPath, "/", "\\")
	if err := sa.UpdateCellValue(pos, winpath); err != nil {
		return fmt.Errorf("failed to update: %v", err)
	}
	// if err := sa.sheet.Synchronize(); err != nil {
	// 	return fmt.Errorf("failed to syncrinize: %v", err)
	// }
	return nil
}
