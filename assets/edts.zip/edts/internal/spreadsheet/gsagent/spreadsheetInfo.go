package gsagent

import (
	"encoding/json"
	"fmt"
	"os"
	"regexp"
)

type SpreadsheetInfo struct {
	TableID         string `json:"TableID"`
	TabName         string `json:"TabName"`
	CredentialsPath string `json:"CredentialsPath"`
}

func GetFromFile(path string) (*SpreadsheetInfo, error) {
	fmt.Println(path)
	tfi := SpreadsheetInfo{}
	bt, err := os.ReadFile(path)
	fmt.Println(string(bt))
	if err != nil {
		return nil, fmt.Errorf("failed to read file: %v", err)
	}
	if err := json.Unmarshal(bt, &tfi); err != nil {
		return nil, fmt.Errorf("failed to unmarshal from file: %v", err)
	}
	return &tfi, nil
}

func SpreadsheetIDfromAdress(adress string) (string, error) {
	//https://docs.google.com/spreadsheets/d/1Waa58usrgEal2Da6tyayaowiWujpm0rzd06P5ASYlsg/edit?gid=250314867#gid=250314867
	re := regexp.MustCompile(`spreadsheets/d/(.*)/edit`)
	found := re.FindStringSubmatch(adress)
	switch len(found) {
	case 0, 1:
		return "", fmt.Errorf("failed to find in provided adress '%v'", adress)
	default:
		return "", fmt.Errorf("failed to find in provided adress '%v'", adress)
	case 2:
		return found[1], nil
	}
}
