package schema

const (
	COL_Comment               = "Комментарий"
	COL_Path                  = "Путь"
	COL_TrailerSourceExpected = "ГТ"
	COL_TrailerMaker          = "Т"
	COL_TrailerEditState      = "Трейлер"
	COL_PosterState           = "П"
	COL_PosterMaker           = "Постеры"
	COL_LABEL_PROJECT         = "М"
	COL_Title                 = "Наименование"
	COL_SourceState           = "С"
	COL_EditState             = "З"
	COL_LABEL_U1              = "О"
	COL_LABEL_U2              = "!"
	COL_Agent                 = "Контрагент"
	COL_PublicationDate       = "Дата публикации"
)

type SpreadsheetSchema struct {
	ColumnDesignationMap map[int]string
	RowDesignationMap    map[int]string
	CellDesignationMap   map[string]string
	DesignationColumnMap map[string]int
	DesignationRowMap    map[string]int
	DesignationCellMap   map[string]string

	RowConditions map[string][]RowValue
}

func New() SpreadsheetSchema {
	ss := SpreadsheetSchema{}
	ss.ColumnDesignationMap = make(map[int]string)
	ss.RowDesignationMap = make(map[int]string)
	ss.CellDesignationMap = make(map[string]string)
	ss.DesignationColumnMap = make(map[string]int)
	ss.DesignationRowMap = make(map[string]int)
	ss.DesignationCellMap = make(map[string]string)
	return ss
}

var ContentcomSchema = SpreadsheetSchema{
	ColumnDesignationMap: map[int]string{
		0:  COL_Comment,
		1:  COL_Path,
		2:  COL_TrailerSourceExpected,
		3:  COL_TrailerMaker,
		4:  COL_TrailerEditState,
		5:  COL_PosterState,
		6:  COL_PosterMaker,
		7:  COL_LABEL_PROJECT,
		8:  COL_Title,
		9:  COL_SourceState,
		10: COL_EditState,
		11: COL_LABEL_U1,
		12: COL_LABEL_U2,
		13: COL_Agent,
		14: COL_PublicationDate,
	},
	DesignationColumnMap: map[string]int{
		COL_Comment:               0,
		COL_Path:                  1,
		COL_TrailerSourceExpected: 2,
		COL_TrailerMaker:          3,
		COL_TrailerEditState:      4,
		COL_PosterState:           5,
		COL_PosterMaker:           6,
		COL_LABEL_PROJECT:         7,
		COL_Title:                 8,
		COL_SourceState:           9,
		COL_EditState:             10,
		COL_LABEL_U1:              11,
		COL_LABEL_U2:              12,
		COL_Agent:                 13,
		COL_PublicationDate:       14,
	},
}

type RowValue struct {
	Column int
	Value  string
}

func (ss SpreadsheetSchema) ColumnDesignation(i int) string {
	if val, ok := ss.ColumnDesignationMap[i]; ok {
		return val
	}
	return "[not designated]"
}

func (ss SpreadsheetSchema) ColumnDesignatedAs(designation string) int {
	if val, ok := ss.DesignationColumnMap[designation]; ok {
		return val
	}
	return -1
}

func (ss SpreadsheetSchema) evaluateCondition(condition string, row []string) bool {
	rowValues := []RowValue{}
	for i, val := range row {
		rowValues = append(rowValues, RowValue{i, val})
	}
	return false
}
