package setup

import (
	"fmt"
	"os"

	"github.com/Galdoba/edts/internal/definitions"
	"github.com/urfave/cli/v2"
)

func EDTS_Service(app *cli.App) {
	app.Version = definitions.Version(app.Name)
	app.Flags = append(app.Flags, &cli.StringFlag{
		Name:        "config",
		DefaultText: "key=default",
		Usage:       "determine which config to use",
		Value:       "default",
	},
	)
	//ДО НАЧАЛА ДЕЙСТВИЯ
	app.Before = func(c *cli.Context) error {
		fmt.Fprintf(os.Stderr, "%v version %v\n", c.App.Name, c.App.Version)
		return nil
	}
	app.DefaultCommand = "run"
	//ПО ОКОНЧАНИЮ ДЕЙСТВИЯ
	app.After = func(c *cli.Context) error {
		return nil
	}

}
