# molog - MOdular LOGger

A modular wrapper around Go's standard library `log/slog` package with flexible configuration options and extensible module system.

## Features

- **Full slog.Logger API Compatibility** - All standard logging methods (Debug, Info, Warn, Error)
- **Multiple Output Formats** - JSON and TEXT handlers
- **Multiple Writers** - Route logs to multiple destinations
- **Custom Attribute Transformation** - Transform log attributes before output
- **Async Module** - Non-blocking logging with worker routines
- **Extensible Module System** - Easy to add new functionality

## Installation

```bash
go get github.com/Galdoba/molog
```

## Quick Start

```go
package main

import (
    "github.com/Galdoba/molog"
)

func main() {
    logger, err := molog.New()
    if err != nil {
        panic(err)
    }

    logger.Info("application started")
    logger.Error("connection failed", "error", "timeout")
}
```

## Base Module Examples

### Basic Logger

```go
logger, _ := molog.New()
logger.Info("info message")
logger.Debug("debug message")
logger.Warn("warning message")
logger.Error("error message", "code", 500)
```

### With Options

```go
logger, err := molog.New(
    molog.WithHandlerType(molog.HANDLER_TEXT),
    molog.WithLevel(molog.LevelInfo),
    molog.WithAddSource(true),
    molog.WithWriter("file", os.Stdout),
)
if err != nil {
    panic(err)
}
```

### Static Attributes

```go
logger, _ := molog.New()
appLogger := logger.With("app", "myapp", "version", "1.0.0")
appLogger.Info("service started")
// Output includes: app=myapp version=1.0.0
```

### Attribute Groups

```go
logger, _ := molog.New(molog.WithHandlerType(molog.HANDLER_TEXT))
requestLogger := logger.WithGroup("request")
requestLogger.Info("incoming request", "method", "GET", "path", "/api")
// Output includes: request.method=GET request.path=/api
```

### Multiple Writers

```go
logger, err := molog.New(
    molog.WithWriter("console", os.Stdout),
    molog.WithWriter("file", file),
)
logger.Info("message goes to both destinations")
```

### Custom Attribute Transformation

```go
logger, _ := molog.New(
    molog.WithReplaceAttr("uppercase", func(groups []string, a slog.Attr) slog.Attr {
        if a.Key == "message" {
            return slog.String("message", strings.ToUpper(a.Value.String()))
        }
        return a
    }),
)
logger.Info("hello world")
// Output: message=HELLO WORLD
```

## Async Module Examples

The async module provides non-blocking logging using worker routines.

### Basic Async Usage

```go
logger, err := molog.New(
    molog.WithLevel(molog.LevelInfo),
    molog.WithAsync(1, 1024), // 1 routine, buffer size 1024
)
if err != nil {
    panic(err)
}

// These calls return immediately without blocking
logger.Info("async message 1")
logger.Info("async message 2")
logger.Info("async message 3")
```

### Multiple Workers

```go
logger, _ := molog.New(
    molog.WithAsync(4, 2048), // 4 workers, buffer 2048
)
```

### Toggle Async at Runtime

```go
logger, _ := molog.New(molog.WithLevel(molog.LevelInfo))

// Enable async mode
logger.ToggleAsync(true)

// Disable async mode (falls back to synchronous)
logger.ToggleAsync(false)
```

### Reconfigure at Runtime

```go
logger, _ := molog.New(
    molog.WithAsync(2, 512),
)

// Change number of workers
logger.AsyncReconfigure(8, 0)

// Change buffer size only
logger.AsyncReconfigure(0, 4096)

// Change both
logger.AsyncReconfigure(8, 4096)
```

### Handle Buffer Overflow

```go
logger, _ := molog.New(
    molog.WithAsync(1, 10),
)

// Enable overflow logging (logs warning when buffer is full)
// Note: Requires access to the underlying loggerBase
loggerBase := logger.(*molog.loggerBase)
// Use internal API or add public method to enable
```

## Configuration Options

| Option | Description | Default |
|--------|-------------|---------|
| `WithWriter(key, writer)` | Add named writer | os.Stderr |
| `WithHandlerType(type)` | JSON or TEXT | JSON |
| `WithAddSource(bool)` | Include file:line | false |
| `WithLevel(level)` | Minimum level | LevelDebug |
| `WithReplaceAttr(key, fn)` | Transform attributes | none |
| `WithAsync(routines, buffer)` | Enable async mode | sync |

## Project Structure

```
molog/
├── base.go          # Logger interface and implementation
├── config.go        # Types, constants, configuration
├── options.go       # Option functions
├── control.go       # Runtime control methods
├── base_test.go     # Tests
├── internal/
│   ├── modules/asyncm/
│   │   └── async.go    # Async module implementation
│   └── value/
│       └── values.go   # Internal values (IgnorePC)
└── doc/
    ├── base.md         # Base module documentation
    └── asyncModule.md  # Async module documentation
```

## Testing

```bash
# Run all tests
go test -v ./...

# Run single test
go test -v -run TestName ./...

# Run async module tests
go test -v ./internal/modules/asyncm/...
```

## Building

```bash
# Build all packages
go build ./...

# Run example
go run ./examples/basic
```

## Documentation

- [Base Module](doc/base.md) - Core logger functionality
- [Async Module](doc/asyncModule.md) - Non-blocking logging
- [AGENTS.md](AGENTS.md) - Developer documentation
