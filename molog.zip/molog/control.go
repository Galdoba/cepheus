package molog

import (
	"github.com/Galdoba/molog/modules/asyncmod"
	"github.com/Galdoba/molog/modules/rotatemod"
)

func (l *loggerBase) ToggleAsync(enabled bool) {
	if l.cfg.async == nil {
		return
	}
	l.cfg.async.ToggleAsync(l.slog, enabled)
}

func (l *loggerBase) AsyncReconfigure(cfg asyncmod.Config) error {
	if l.cfg.async == nil {
		return nil
	}
	initialState := l.cfg.async.IsEnabled()
	l.cfg.async.ToggleAsync(l.slog, false)
	err := l.cfg.async.Configure(cfg)
	if err != nil {
		return err
	}
	l.cfg.async.ToggleAsync(l.slog, initialState)
	return nil
}

func (l *loggerBase) RotateReconfigure(cfg rotatemod.Config) error {
	if l.cfg.rotate == nil {
		return nil
	}
	return l.cfg.rotate.Configure(cfg)
}
