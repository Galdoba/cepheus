package molog

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"os"
	"runtime"
	"time"

	"github.com/Galdoba/molog/internal/value"
)

const (
	baseRuntimeCallerDepth = 3
)

type Logger interface {
	Debug(msg string, args ...any)
	DebugContext(ctx context.Context, msg string, args ...any)
	Enabled(ctx context.Context, level Level) bool
	Error(msg string, args ...any)
	ErrorContext(ctx context.Context, msg string, args ...any)
	Handler() slog.Handler
	Info(msg string, args ...any)
	InfoContext(ctx context.Context, msg string, args ...any)
	Log(ctx context.Context, level Level, msg string, args ...any)
	LogAttrs(ctx context.Context, level Level, msg string, args ...slog.Attr)
	Warn(msg string, args ...any)
	WarnContext(ctx context.Context, msg string, args ...any)
	With(args ...any) Logger
	WithGroup(name string) Logger
}

type loggerBase struct {
	slog *slog.Logger
	cfg  modulesConfiguration
}

func New(opts ...Option) (Logger, error) {
	cfg := modulesConfiguration{
		base: base{
			handler:          HANDLER_JSON,
			addSource:        false,
			level:            LevelDebug,
			replaceAttrFuncs: make(map[string]func([]string, slog.Attr) slog.Attr),
			writers: map[string]io.Writer{
				"": os.Stderr,
			},
		},
	}
	for _, opt := range opts {
		if err := opt(&cfg); err != nil {
			return nil, err
		}
	}

	var handler slog.Handler
	switch len(cfg.base.writers) {
	case 0:
		cfg.base.designatedWriter = os.Stderr
	default:
		wrtrs := []io.Writer{}
		for _, w := range cfg.base.writers {
			wrtrs = append(wrtrs, w)
		}
		cfg.base.designatedWriter = io.MultiWriter(wrtrs...)
	}

	switch cfg.base.handler {
	case HANDLER_TEXT:
		handler = slog.NewTextHandler(cfg.base.designatedWriter, &slog.HandlerOptions{
			AddSource: cfg.base.addSource,
			Level:     cfg.base.level,
			ReplaceAttr: func(groups []string, a slog.Attr) slog.Attr {
				for _, fn := range cfg.base.replaceAttrFuncs {
					a = fn(groups, a)
				}
				return a
			},
		})
	case HANDLER_CUSTOM:
		return nil, errors.New("custom handlers not implemented")
	default:
		handler = slog.NewJSONHandler(cfg.base.designatedWriter, &slog.HandlerOptions{
			AddSource: cfg.base.addSource,
			Level:     cfg.base.level,
			ReplaceAttr: func(groups []string, a slog.Attr) slog.Attr {
				for _, fn := range cfg.base.replaceAttrFuncs {
					a = fn(groups, a)
				}
				return a
			},
		})
	}

	logBase := &loggerBase{slog: slog.New(handler), cfg: cfg}
	if logBase.cfg.async != nil {
		logBase.cfg.async.ToggleAsync(logBase.slog, true)
	}
	return logBase, nil
}

func (l *loggerBase) Debug(msg string, args ...any) {
	l.log(context.Background(), LevelDebug, msg, args...)
}
func (l *loggerBase) DebugContext(ctx context.Context, msg string, args ...any) {
	l.log(ctx, LevelDebug, msg, args...)
}
func (l *loggerBase) Enabled(ctx context.Context, level Level) bool {
	return l.slog.Enabled(ctx, level)
}
func (l *loggerBase) Error(msg string, args ...any) {
	l.log(context.Background(), LevelError, msg, args...)
}
func (l *loggerBase) ErrorContext(ctx context.Context, msg string, args ...any) {
	l.log(ctx, LevelError, msg, args...)
}
func (l *loggerBase) Handler() slog.Handler {
	return l.slog.Handler()
}
func (l *loggerBase) Info(msg string, args ...any) {
	l.log(context.Background(), LevelInfo, msg, args...)
}
func (l *loggerBase) InfoContext(ctx context.Context, msg string, args ...any) {
	l.log(ctx, LevelInfo, msg, args...)
}
func (l *loggerBase) Log(ctx context.Context, level Level, msg string, args ...any) {
	l.log(ctx, level, msg, args...)
}
func (l *loggerBase) LogAttrs(ctx context.Context, level Level, msg string, args ...slog.Attr) {
	l.logAttrs(ctx, level, msg, args...)
}
func (l *loggerBase) Warn(msg string, args ...any) {
	l.log(context.Background(), LevelWarn, msg, args...)
}
func (l *loggerBase) WarnContext(ctx context.Context, msg string, args ...any) {
	l.log(ctx, LevelWarn, msg, args...)
}
func (l *loggerBase) With(args ...any) Logger {
	return &loggerBase{
		slog: l.slog.With(args...),
		cfg:  l.cfg,
	}
}
func (l *loggerBase) WithGroup(name string) Logger {
	return &loggerBase{
		slog: l.slog.WithGroup(name),
		cfg:  l.cfg,
	}
}
func (l *loggerBase) log(ctx context.Context, level Level, msg string, args ...any) {
	//async module
	if l.cfg.async != nil && l.cfg.async.Log(l.slog, ctx, level, msg, args...) {
		return
	}

	//base
	if ctx == nil {
		ctx = context.Background()
	}
	if !l.Enabled(ctx, level) {
		return
	}
	var pc uintptr
	if !value.IgnorePC {
		var pcs [1]uintptr
		runtime.Callers(baseRuntimeCallerDepth, pcs[:])
		pc = pcs[0]
	}

	r := slog.NewRecord(time.Now(), level, msg, pc)
	r.Add(args...)

	_ = l.Handler().Handle(ctx, r)
	//rotation module
	if l.cfg.rotate != nil {
		err := l.cfg.rotate.Rotate()
		if err != nil {
			l.log(ctx, LevelError, "log file rotation failed", "error", err) //should call eventbus or fallback (not implemented)
		}
	}
}

func (l *loggerBase) logAttrs(ctx context.Context, level Level, msg string, attrs ...slog.Attr) {
	if l.cfg.async != nil && l.cfg.async.LogAttr(l.slog, ctx, level, msg, attrs...) {
		return
	}
	if ctx == nil {
		ctx = context.Background()
	}

	if !l.Enabled(ctx, level) {
		return
	}

	var pc uintptr
	if !value.IgnorePC {
		var pcs [1]uintptr
		runtime.Callers(baseRuntimeCallerDepth, pcs[:])
		pc = pcs[0]
	}

	r := slog.NewRecord(time.Now(), level, msg, pc)
	r.AddAttrs(attrs...)

	_ = l.Handler().Handle(ctx, r)
}
