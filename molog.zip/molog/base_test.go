package molog

import (
	"bytes"
	"context"
	"io"
	"log/slog"
	"strings"
	"testing"
	"time"

	"github.com/Galdoba/molog/modules/asyncmod"
)

var testAsyncConfig1 = asyncmod.Config{
	Routines:    1,
	Buffer:      10,
	LogOverflow: false,
}

var testAsyncConfig2 = asyncmod.Config{
	Routines:    2,
	Buffer:      20,
	LogOverflow: false,
}

func TestNew(t *testing.T) {

	tests := []struct {
		name    string
		opts    []Option
		wantErr bool
	}{
		{
			name:    "default options",
			opts:    []Option{},
			wantErr: false,
		},
		{
			name: "with level",
			opts: []Option{
				WithLevel(LevelDebug),
			},
			wantErr: false,
		},
		{
			name: "with text handler",
			opts: []Option{
				WithHandlerType(HANDLER_TEXT),
			},
			wantErr: false,
		},
		{
			name: "with add source",
			opts: []Option{
				WithAddSource(true),
			},
			wantErr: false,
		},
		{
			name: "with custom writer",
			opts: []Option{
				WithWriter("test", &bytes.Buffer{}),
			},
			wantErr: false,
		},
		{
			name: "with replace attr",
			opts: []Option{
				WithReplaceAttr("test", func(groups []string, a slog.Attr) slog.Attr {
					return a
				}),
			},
			wantErr: false,
		},
		{
			name: "multiple options",
			opts: []Option{
				WithLevel(LevelWarn),
				WithHandlerType(HANDLER_TEXT),
				WithAddSource(true),
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, err := New(tt.opts...)
			if (err != nil) != tt.wantErr {
				t.Errorf("New() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if logger == nil && !tt.wantErr {
				t.Error("New() returned nil logger")
			}
		})
	}
}

func TestLoggerMethods(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	ctx := context.Background()

	logger.Debug("debug message", "key", "value")
	logger.Info("info message", "key", "value")
	logger.Warn("warn message", "key", "value")
	logger.Error("error message", "key", "value")

	logger.DebugContext(ctx, "debug context message", "key", "value")
	logger.InfoContext(ctx, "info context message", "key", "value")
	logger.WarnContext(ctx, "warn context message", "key", "value")
	logger.ErrorContext(ctx, "error context message", "key", "value")

	logger.Log(ctx, LevelInfo, "log message", "key", "value")
	logger.LogAttrs(ctx, LevelInfo, "logattrs message", slog.String("key", "value"))

	if buf.Len() == 0 {
		t.Error("Logger wrote nothing to writer")
	}
}

func TestEnabled(t *testing.T) {
	logger, err := New(WithLevel(LevelInfo))
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	ctx := context.Background()

	if !logger.Enabled(ctx, LevelInfo) {
		t.Error("Enabled(LevelInfo) should return true when level is LevelInfo")
	}
	if !logger.Enabled(ctx, LevelError) {
		t.Error("Enabled(LevelError) should return true when level is LevelInfo")
	}
}

func TestWith(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	loggerWith := logger.With("staticKey", "staticValue")

	loggerWith.Info("message with static")

	if buf.Len() == 0 {
		t.Error("Logger.With() did not write anything")
	}
}

func TestWithGroup(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	loggerWithGroup := logger.WithGroup("group")

	loggerWithGroup.Info("message in group")

	if buf.Len() == 0 {
		t.Error("Logger.WithGroup() did not write anything")
	}
}

func TestChainedWith(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	loggerChained := logger.With("key1", "val1").WithGroup("group").With("key2", "val2")
	loggerChained.Info("chained message")

	if buf.Len() == 0 {
		t.Error("Chained With/WithGroup did not write anything")
	}
}

func TestWithWriterMultiple(t *testing.T) {
	buf1 := &bytes.Buffer{}
	buf2 := &bytes.Buffer{}
	multi := io.MultiWriter(buf1, buf2)

	logger, err := New(
		WithWriter("multi", multi),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	logger.Info("message")

	if buf1.Len() == 0 || buf2.Len() == 0 {
		t.Error("Multiple writers did not receive message")
	}
}

func TestHandlerTypeConstants(t *testing.T) {
	if HANDLER_JSON != "json" {
		t.Errorf("HANDLER_JSON = %v, want 'json'", HANDLER_JSON)
	}
	if HANDLER_TEXT != "text" {
		t.Errorf("HANDLER_TEXT = %v, want 'text'", HANDLER_TEXT)
	}
	if HANDLER_CUSTOM != "custom" {
		t.Errorf("HANDLER_CUSTOM = %v, want 'custom'", HANDLER_CUSTOM)
	}
}

func TestLevelConstants(t *testing.T) {
	if LevelDebug != slog.LevelDebug {
		t.Errorf("LevelDebug = %v, want %v", LevelDebug, slog.LevelDebug)
	}
	if LevelInfo != slog.LevelInfo {
		t.Errorf("LevelInfo = %v, want %v", LevelInfo, slog.LevelInfo)
	}
	if LevelWarn != slog.LevelWarn {
		t.Errorf("LevelWarn = %v, want %v", LevelWarn, slog.LevelWarn)
	}
	if LevelError != slog.LevelError {
		t.Errorf("LevelError = %v, want %v", LevelError, slog.LevelError)
	}
}

func TestDiscardWriter(t *testing.T) {
	logger, err := New(
		WithWriter("discard", io.Discard),
		WithLevel(LevelDebug),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	logger.Info("discard test")
	logger.Debug("discard debug")
	logger.Error("discard error")
}

func TestAsyncAutoStart(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
		WithModuleAsync(testAsyncConfig1),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	logger.Info("async auto start test", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "async auto start test") {
		t.Errorf("Async auto-start should log message, got: %s", output)
	}
}

func TestAsyncToggleOnOff(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
		WithModuleAsync(testAsyncConfig1),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	loggerBase := logger.(*loggerBase)

	buf.Reset()
	loggerBase.ToggleAsync(false)
	logger.Info("sync when async off", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "sync when async off") {
		t.Error("Messages should still appear synchronously when async is toggled off")
	}

	buf.Reset()
	loggerBase.ToggleAsync(true)
	logger.Info("async when on", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output = buf.String()
	if !strings.Contains(output, "async when on") {
		t.Error("Messages should appear when async is toggled on")
	}
}

func TestAsyncReconfigure(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
		WithModuleAsync(testAsyncConfig1),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	logger.(*loggerBase).AsyncReconfigure(asyncmod.Config{
		Routines: 2,
		Buffer:   20,
	})

	time.Sleep(50 * time.Millisecond)

	logger.Info("reconfigure test", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "reconfigure test") {
		t.Errorf("Logger should work after reconfigure, got: %s", output)
	}
}

func TestAsyncReconfigure_KeepState(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
		WithModuleAsync(testAsyncConfig1),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	loggerBase := logger.(*loggerBase)
	loggerBase.ToggleAsync(false)

	loggerBase.AsyncReconfigure(asyncmod.Config{
		Routines: 2,
		Buffer:   20,
	})

	logger.Info("sync while off after reconfigure", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "sync while off after reconfigure") {
		t.Error("Should log synchronously while async is off after reconfigure")
	}

	loggerBase.ToggleAsync(true)

	logger.Info("after re-enable", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output = buf.String()
	if !strings.Contains(output, "after re-enable") {
		t.Error("Should log after re-enabling")
	}
}

func TestAsyncWithLogAttrs(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
		WithModuleAsync(testAsyncConfig1),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	logger.LogAttrs(context.Background(), LevelInfo, "logattrs async test", slog.String("key", "value"))

	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "logattrs async test") {
		t.Errorf("LogAttrs should work with async, got: %s", output)
	}
}

func TestAsyncMultipleWriters(t *testing.T) {
	buf1 := &bytes.Buffer{}
	buf2 := &bytes.Buffer{}

	logger, err := New(
		WithWriter("first", buf1),
		WithWriter("second", buf2),
		WithHandlerType(HANDLER_TEXT),
		WithModuleAsync(testAsyncConfig1),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	logger.Info("multi writer async test", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output1 := buf1.String()
	output2 := buf2.String()

	if !strings.Contains(output1, "multi writer async test") {
		t.Errorf("First writer should receive message, got: %s", output1)
	}
	if !strings.Contains(output2, "multi writer async test") {
		t.Errorf("Second writer should receive message, got: %s", output2)
	}
}

func TestAsyncLevelFiltering(t *testing.T) {
	buf := &bytes.Buffer{}
	logger, err := New(
		WithWriter("test", buf),
		WithHandlerType(HANDLER_TEXT),
		WithModuleAsync(testAsyncConfig1),

		WithLevel(LevelWarn),
	)
	if err != nil {
		t.Fatalf("New() error = %v", err)
	}

	logger.Info("info should be filtered", "key", "value")
	logger.Warn("warn should appear", "key", "value")

	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if strings.Contains(output, "info should be filtered") {
		t.Error("Info level should be filtered")
	}
	if !strings.Contains(output, "warn should appear") {
		t.Error("Warn level should not be filtered")
	}
}
