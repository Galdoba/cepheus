# Molog - Agent Documentation

## Project Overview

Molog (MOdular LOGger) is a modular wrapper around Go's standard library `log/slog` package. The library provides a flexible logger constructor with various configuration options while maintaining full compatibility with the slog.Logger interface.

## Current Status

### Implemented Modules

#### Base Module (✅ Stable)
- Full slog.Logger API compatibility
- Multiple writer support
- JSON/TEXT handlers
- Custom attribute transformation

#### Async Module (Refactoring)
- Non-blocking logging with worker routines
- Configurable routines and buffer size
- Runtime toggle and reconfiguration
- Overflow handling

#### Rotate Module (Early Layout)
- Main functions signature only

### Configuration Options
- `WithWriter(key, writer)` - Multiple writer support with named keys
- `WithHandlerType(JSON/TEXT)` - Output format selection
- `WithAddSource(bool)` - Source location inclusion
- `WithLevel(Level)` - Minimum log level filtering
- `WithReplaceAttr(key, fn)` - Attribute transformation functions
- `WithAsync(config)` - Enable async mode
- `WithRotate(config)` - Enable automatic logfiles rotation

## Build, Lint & Test Commands

```bash
# Build all packages
go build ./...

# Run all tests
go test -v ./...

# Run single test
go test -v -run TestName ./...

# Run async module tests only
go test -v ./internal/modules/asyncm/...

# Run with coverage
go test -cover ./...

# Format code
gofmt -w .

# Vet checks
go vet ./...
```


## Design Principles

1. **Simplicity First** - Keep the API simple and intuitive
2. **Flexibility** - Allow customization through options
3. **Clear Naming** - Use unambiguous names for functions, methods, and types
4. **Maintainability** - Self-Documenting variable names, as clear as possible
5. **Modularity** - Extensible architecture with modulesConfiguration

## Code Style Guidelines

### Imports
- Standard library first, then external packages
- Blank line between groups
```go
import (
    "context"
    "io"
    "log/slog"

    "github.com/Galdoba/molog/internal/value"
)
```

### Types
- Use type aliases for slog compatibility: `type Level = slog.Level`
- Use const groups for related constants

### Naming
- Exported: PascalCase (e.g., `New`, `WithWriter`)
- Unexported: camelCase (e.g., `loggerBase`, `modulesConfiguration`)
- Constants: SCREAMING_SNAKE for values, PascalCase for types

### Functions
- Option functions: `func WithX(...) Option`
- Return `error` as last value
- Use descriptive error messages

### Comments
- Full sentences in English
- Start with identifier name for methods
- Write comments only when asked
```go
// New creates a new Logger with the specified options.
func New(opts ...Option) (Logger, error) {
```

### Error Handling
- Return errors as values, not exceptions
- Descriptive error messages
- Validate inputs early

### Testing
- Use table-driven tests for variations
- Test both success and failure cases
- Use meaningful test names: `TestName_Scenario_Expected`

## Development Directives

### Language Requirements
- All documentation and comments must be in English
- Maintain consistent comment style across all files

### API Changes
- Adding new API or changing signatures is allowed but should be done carefully
- Consider backward compatibility implications
- Document any breaking changes

### Clarification Policy
- When task is unclear, ask the user for clarification
- Provide analysis of options with pros/cons when user needs to choose
- Don't assume intent - verify with user

### Code Quality
- Follow Go best practices where reasonable
- Target: small to meduim level projects, so some production-level requirements can be relaxed
- Prioritize: simplicity, flexibility, clear naming, maintainability

## Planned Features

### High Priority
1. **Hook Module** - Add callbacks on log events for alerting/metrics
2. **Rate Limiter** - Prevent log flooding, complement async module
3. **Custom Handlers** - Implement HANDLER_CUSTOM support

### Medium Priority
- Buffer/Flush Module - Batch I/O optimization
- Multi-Handler Module - Route logs to different handlers based on level
- Filter Module - Filter messages based on predicates

See `doc/TODO.md` for detailed analysis.

## Open Questions

1. **Module Placement**: Keep modules in main package or use subpackages?
   - Current: main package (simpler API)
   - Consider: subpackages if >5 modules added

2. **Hook Implementation**: Synchronous or asynchronous callbacks?
   - Sync: simpler, blocks logging
   - Async: more complex, non-blocking

## Quick Start for Future Agents

When continuing development:

1. Review `doc/TODO.md` for recommended next modules
2. Review `doc/base.md` for current API documentation
3. Review `doc/asyncModule.md` for async module specification
4. Check existing code style in `base.go`, `config.go`, `options.go`
5. Run tests: `go test -v ./...`
6. Build: `go build ./...`

## Key Files Reference

| File | Purpose |
|------|---------|
| `base.go` | Logger interface, constructors, logging methods |
| `config.go` | Types (Level, Attr, Record), constants, config structs |
| `options.go` | All With* option functions |
| `base_test.go` | Comprehensive test suite |
