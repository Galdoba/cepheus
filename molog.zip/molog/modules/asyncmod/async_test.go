package asyncmod

import (
	"bytes"
	"context"
	"log/slog"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestConfigValidate(t *testing.T) {
	tests := []struct {
		name        string
		cfg         Config
		wantErr     bool
		errContains string
	}{
		{
			name:    "valid config",
			cfg:     Config{Routines: 1, Buffer: 0},
			wantErr: false,
		},
		{
			name:    "valid with buffer",
			cfg:     Config{Routines: 4, Buffer: 1024},
			wantErr: false,
		},
		{
			name:    "zero routines",
			cfg:     Config{Routines: 0, Buffer: 0},
			wantErr: true,
		},
		{
			name:    "negative routines",
			cfg:     Config{Routines: -5, Buffer: 0},
			wantErr: true,
		},
		{
			name:    "negative buffer",
			cfg:     Config{Routines: 1, Buffer: -1},
			wantErr: true,
		},
		{
			name:    "too many routines",
			cfg:     Config{Routines: 100, Buffer: 0},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.cfg.Validate()
			if (err != nil) != tt.wantErr {
				t.Errorf("Config.Validate() error = %v, wantErr %v", err, tt.wantErr)
				return
			}

			if tt.wantErr && err != nil && tt.errContains != "" {
				if !strings.Contains(err.Error(), tt.errContains) {
					t.Errorf("Validate() error = %v, want contains %v", err, tt.errContains)
				}
			}
		})
	}
}

func TestModule_New(t *testing.T) {
	m := New()
	if m.IsEnabled() {
		t.Error("New() should create disabled module")
	}
}

func TestModule_Configure(t *testing.T) {
	m := New()
	cfg := Config{Routines: 2, Buffer: 100, LogOverflow: true}
	err := m.Configure(cfg)
	if err != nil {
		t.Errorf("Configure() error = %v", err)
	}
}

func TestModule_Configure_Invalid(t *testing.T) {
	m := New()
	cfg := Config{Routines: 0, Buffer: 0}
	err := m.Configure(cfg)
	if err == nil {
		t.Error("Configure() should return error for invalid config")
	}
}

func TestToggleAsync_StartStop(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 2, Buffer: 10}
	_ = m.Configure(cfg)

	if m.IsEnabled() {
		t.Error("New() should create disabled module")
	}

	m.ToggleAsync(logger, true)

	if !m.IsEnabled() {
		t.Error("ToggleAsync(true) should enable module")
	}

	time.Sleep(10 * time.Millisecond)

	m.ToggleAsync(logger, false)

	if m.IsEnabled() {
		t.Error("ToggleAsync(false) should disable module")
	}
}

func TestToggleAsync_AlreadyInState(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 0}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	initialState := m.IsEnabled()

	m.ToggleAsync(logger, true)

	if m.IsEnabled() != initialState {
		t.Error("ToggleAsync with same state should not change anything")
	}
}

func TestLog_RecordsProcessed(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 100}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	m.Log(logger, context.Background(), slog.LevelInfo, "test message", "key", "value")

	m.ToggleAsync(logger, false)
	time.Sleep(10 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "test message") {
		t.Errorf("Output should contain message, got: %s", output)
	}
	if !strings.Contains(output, "key") {
		t.Errorf("Output should contain key, got: %s", output)
	}
}

func TestLog_Disabled(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()

	m.Log(logger, context.Background(), slog.LevelInfo, "should not appear", "key", "value")

	if buf.Len() > 0 {
		t.Error("Disabled module should not process logs")
	}
}

func TestLog_LevelCheck(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, &slog.HandlerOptions{
		Level: slog.LevelWarn,
	})
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 10}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	m.Log(logger, context.Background(), slog.LevelInfo, "info should be filtered", "key", "value")
	m.Log(logger, context.Background(), slog.LevelWarn, "warn should appear", "key", "value")

	m.ToggleAsync(logger, false)
	time.Sleep(10 * time.Millisecond)

	output := buf.String()
	if strings.Contains(output, "info should be filtered") {
		t.Error("Info level should be filtered by handler")
	}
	if !strings.Contains(output, "warn should appear") {
		t.Error("Warn level should not be filtered")
	}
}

func TestLogAttr_RecordsProcessed(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 100}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	m.LogAttr(logger, context.Background(), slog.LevelInfo, "attr test", slog.String("key", "value"))

	m.ToggleAsync(logger, false)
	time.Sleep(10 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "attr test") {
		t.Errorf("Output should contain message, got: %s", output)
	}
	if !strings.Contains(output, "key") {
		t.Errorf("Output should contain key, got: %s", output)
	}
}

func TestLogOverflow_BufferFull(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 1, LogOverflow: true}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	for i := 0; i < 10; i++ {
		m.Log(logger, context.Background(), slog.LevelInfo, "overflow test", "i", i)
	}

	m.ToggleAsync(logger, false)
	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "log overflow") {
		t.Error("Should log overflow warning when buffer is full")
	}
}

func TestLogOverflow_Disabled(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 1, LogOverflow: false}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	for i := 0; i < 10; i++ {
		m.Log(logger, context.Background(), slog.LevelInfo, "overflow test", "i", i)
	}

	m.ToggleAsync(logger, false)
	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	if strings.Contains(output, "log overflow") {
		t.Error("Should not log overflow when disabled")
	}
}

func TestMultipleRoutines(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 4, Buffer: 100}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			m.Log(logger, context.Background(), slog.LevelInfo, "concurrent message", "idx", idx)
		}(i)
	}
	wg.Wait()

	m.ToggleAsync(logger, false)
	time.Sleep(50 * time.Millisecond)

	count := strings.Count(buf.String(), "concurrent message")
	if count != 100 {
		t.Errorf("Expected 100 messages, got %d", count)
	}
}

func TestNilContext(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 10}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	m.Log(logger, nil, slog.LevelInfo, "nil context test", "key", "value")

	m.ToggleAsync(logger, false)
	time.Sleep(10 * time.Millisecond)

	output := buf.String()
	if !strings.Contains(output, "nil context test") {
		t.Error("Should handle nil context")
	}
}

func TestSetEnabled(t *testing.T) {
	m := New()

	if m.IsEnabled() {
		t.Error("New module should be disabled")
	}

	m.SetEnabled(true)

	if !m.IsEnabled() {
		t.Error("SetEnabled(true) should enable module")
	}

	m.SetEnabled(false)

	if m.IsEnabled() {
		t.Error("SetEnabled(false) should disable module")
	}
}

func TestDrainOnStop(t *testing.T) {
	buf := &bytes.Buffer{}
	handler := slog.NewJSONHandler(buf, nil)
	logger := slog.New(handler)

	m := New()
	cfg := Config{Routines: 1, Buffer: 10}
	_ = m.Configure(cfg)

	m.ToggleAsync(logger, true)
	time.Sleep(10 * time.Millisecond)

	for i := 0; i < 5; i++ {
		m.Log(logger, context.Background(), slog.LevelInfo, "drain test", "i", i)
	}

	m.ToggleAsync(logger, false)
	time.Sleep(50 * time.Millisecond)

	output := buf.String()
	for i := 0; i < 5; i++ {
		if !strings.Contains(output, "drain test") {
			t.Errorf("Message %d should be drained on stop", i)
		}
	}
}
