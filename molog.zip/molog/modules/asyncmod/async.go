package asyncmod

import (
	"context"
	"fmt"
	"log/slog"
	"runtime"
	"sync"
	"time"

	"github.com/Galdoba/molog/internal/value"
)

const (
	Version                 = "0.2.0"
	ModuleName              = "Async Module"
	asyncRuntimeCallerDepth = 4 // must be baseRuntimeCallerDepth + 1
	minimumRoutinesAllowed  = 1
	maximumRoutinesAllowed  = 10 //testing: might be increased after release
	noBuffer                = 0
)

type Config struct {
	Routines    int
	Buffer      int
	LogOverflow bool
}

func (cfg Config) Validate() error {
	if cfg.Routines < minimumRoutinesAllowed {
		return fmt.Errorf("minimum routines allowed: %v", minimumRoutinesAllowed)
	}
	if cfg.Routines > maximumRoutinesAllowed {
		return fmt.Errorf("maximum routines allowed: %v", maximumRoutinesAllowed)
	}
	if cfg.Buffer < noBuffer {
		return fmt.Errorf("buffer is negative")
	}
	return nil
}

type Module struct {
	enabled     bool
	routines    int
	buffer      int
	logOverflow bool
	mu          sync.Mutex
	recordCh    chan slog.Record
	stopCh      chan struct{}
	wg          sync.WaitGroup
}

func New() *Module {
	m := Module{
		enabled:     false,
		routines:    1,
		buffer:      0,
		logOverflow: false,
		mu:          sync.Mutex{},
		recordCh:    make(chan slog.Record),
		stopCh:      make(chan struct{}),
		wg:          sync.WaitGroup{},
	}
	return &m
}

func (m *Module) Configure(cfg Config) error {
	if err := cfg.Validate(); err != nil {
		return fmt.Errorf("invalid %s configuration: %w", ModuleName, err)
	}
	m.buffer = cfg.Buffer
	m.routines = cfg.Routines
	m.logOverflow = cfg.LogOverflow
	return nil
}

func (m *Module) SetEnabled(enabled bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.enabled = enabled
}

func (m *Module) IsEnabled() bool {
	return m.enabled
}

func (m *Module) ToggleAsync(l *slog.Logger, enabled bool) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if enabled == m.enabled {
		return
	}
	m.enabled = enabled

	if m.enabled {
		m.startWorkers(l)
	} else {
		m.stopWorkers()
	}

}

// func (m *Module) Validate() error {
// 	if m.buffer < 0 {
// 		return fmt.Errorf("buffer is negative")
// 	}
// 	if m.routines < 1 {
// 		return fmt.Errorf("routines are less than 1")
// 	}
// 	return nil
// }

func (m *Module) startWorkers(l *slog.Logger) {
	m.recordCh = make(chan slog.Record, m.buffer)
	m.stopCh = make(chan struct{})

	for i := 0; i < m.routines; i++ {
		m.wg.Add(1)
		go m.worker(l)
	}
}

func (m *Module) worker(l *slog.Logger) {
	defer m.wg.Done()

	for {
		select {
		case record := <-m.recordCh:
			l.Handler().Handle(context.Background(), record)
		case <-m.stopCh:
			for {
				select {
				case record := <-m.recordCh:
					l.Handler().Handle(context.Background(), record)
				default:
					return
				}
			}
		}
	}
}
func (m *Module) stopWorkers() {
	close(m.stopCh)
	m.wg.Wait()
	close(m.recordCh)
}

func (m *Module) Log(l *slog.Logger, ctx context.Context, level slog.Level, msg string, args ...any) bool {
	if !m.enabled {
		return false
	}

	if ctx == nil {
		ctx = context.Background()
	}

	if !l.Enabled(ctx, level) {
		return true
	}

	var pc uintptr
	if !value.IgnorePC {
		var pcs [1]uintptr
		runtime.Callers(asyncRuntimeCallerDepth, pcs[:])
		pc = pcs[0]
	}

	r := slog.NewRecord(time.Now(), level, msg, pc)
	r.Add(args...)

	select {
	case m.recordCh <- r:
	default:
		if m.logOverflow {
			l.Warn("log overflow")
			return false
		}
	}
	return true
}

func (m *Module) LogAttr(l *slog.Logger, ctx context.Context, level slog.Level, msg string, attrs ...slog.Attr) bool {
	if !m.enabled {
		return false
	}

	if ctx == nil {
		ctx = context.Background()
	}

	if !l.Enabled(ctx, level) {
		return true
	}

	var pc uintptr
	if !value.IgnorePC {
		var pcs [1]uintptr
		runtime.Callers(asyncRuntimeCallerDepth, pcs[:])
		pc = pcs[0]
	}

	r := slog.NewRecord(time.Now(), level, msg, pc)
	r.AddAttrs(attrs...)

	select {
	case m.recordCh <- r:
	default:
		if m.logOverflow {
			l.Warn("log overflow")
			return false
		}
	}
	return true
}

//TODO: learn more about log buffering before implementation
