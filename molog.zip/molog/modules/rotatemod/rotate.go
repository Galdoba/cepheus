package rotatemod

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const (
	ModuleName      = "Rotate Module"
	timestampFormat = "20060102150405"
)

type Config struct {
	SizeMB        int
	AgeHours      int
	RecordsInFile int
	OnSignalUP    bool
	Archive       Archive
}

func (cfg *Config) Validate() error {
	//Validate parameters
	return nil
}

type Archive struct {
	Directory     string
	FilePrefix    string
	FileSuffix    string
	FileExtention string
}

func (a Archive) newBackupPath(path string) string {
	dir, file := filepath.Split(path)
	ext := filepath.Ext(file)
	base := strings.TrimSuffix(file, ext)

	var parts []string

	parts = append(parts, time.Now().Format(timestampFormat))
	if a.FilePrefix != "" {
		parts = append(parts, a.FilePrefix)
	}
	parts = append(parts, base)
	if a.FileSuffix != "" {
		parts = append(parts, a.FileSuffix)
	}
	newBase := strings.Join(parts, "_")

	newExt := ext
	if a.FileExtention != "" {
		if newExt == "" {
			newExt = "." + a.FileExtention
		} else {
			newExt = newExt + "." + a.FileExtention
		}
	}

	newFilename := newBase + newExt
	if a.Directory != "" {
		return filepath.Join(a.Directory, newFilename)
	}

	return filepath.Join(dir, newFilename)
}

type Module struct {
	enabled      bool
	mu           sync.Mutex
	trackedFiles map[string]*os.File
	archive      Archive
	maxSizeMB    int
	//TODO: add other fields
}

func New(trackedFiles []*os.File) (*Module, error) {
	if len(trackedFiles) < 1 {
		return nil, fmt.Errorf("no files to track was passed")
	}

	files := make(map[string]*os.File)
	for _, f := range trackedFiles {
		path, err := filepath.Abs(f.Name())
		if err != nil {
			return nil, fmt.Errorf("failed to get path for tracked file: %w", err)
		}
		files[path] = f
	}

	return &Module{
		enabled:      true,
		trackedFiles: files,
		mu:           sync.Mutex{},
	}, nil
}

func (m *Module) Configure(cfg Config) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := cfg.Validate(); err != nil {
		return fmt.Errorf("invalid configuration: %w", err)
	}
	m.maxSizeMB = cfg.SizeMB
	//apply config
	return nil
}

func (m *Module) Rotate() error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if !m.enabled {
		return nil
	}
	for _, f := range m.trackedFiles {
		if !wantRotation(m, f) {
			continue
		}

		err := m.rotate(f)
		if err != nil {
			return err
		}
	}
	return nil
}

func wantRotation(m *Module, f *os.File) bool {
	//check rotation triggers: return true if any of them is match
	s, _ := f.Stat()
	if s.Size() > int64(m.maxSizeMB*1024) {
		return true
	}
	return false
}

func (m *Module) rotate(f *os.File) error {
	path, err := filepath.Abs(f.Name())
	if err != nil {
		return fmt.Errorf("failed to get log filepath: %w", err)
	}

	backup := m.archive.newBackupPath(path)
	if err := os.Rename(path, backup); err != nil {
		return fmt.Errorf("failed to save backup file: %w", err)
	}
	newFile, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0666)
	if err != nil {
		return fmt.Errorf("failed to recreate log file: %w", err)
	}
	m.trackedFiles[path] = newFile

	return nil
}
