module github.com/Galdoba/molog

go 1.25.1
