package molog

import (
	"io"
	"log/slog"
	"os"

	"github.com/Galdoba/molog/modules/asyncmod"
	"github.com/Galdoba/molog/modules/rotatemod"
)

type Level = slog.Level

type Attr = slog.Attr

type Record = slog.Record

const (
	LevelDebug Level = slog.LevelDebug
	LevelInfo  Level = slog.LevelInfo
	LevelWarn  Level = slog.LevelWarn
	LevelError Level = slog.LevelError
)

type handlerType string

const (
	HANDLER_JSON   handlerType = "json"
	HANDLER_TEXT   handlerType = "text"
	HANDLER_CUSTOM handlerType = "custom"
)

type modulesConfiguration struct {
	base   base
	async  *asyncmod.Module
	rotate *rotatemod.Module
}

type base struct {
	writers          map[string]io.Writer
	designatedWriter io.Writer
	handler          handlerType
	addSource        bool
	level            Level
	replaceAttrFuncs map[string]func([]string, slog.Attr) slog.Attr
	customHandler    slog.Handler
	logFiles         []*os.File
}
