package molog

import (
	"errors"
	"fmt"
	"io"
	"log/slog"
	"os"

	"github.com/Galdoba/molog/modules/asyncmod"
	"github.com/Galdoba/molog/modules/rotatemod"
)

type Option func(*modulesConfiguration) error

func WithWriter(writerKey string, writer io.Writer) Option {
	return func(mc *modulesConfiguration) error {
		if mc.base.writers == nil {
			mc.base.writers = make(map[string]io.Writer)
		}
		if writerKey == "" {
			return errors.New("options: empty key is not allowed")
		}
		delete(mc.base.writers, "")
		mc.base.writers[writerKey] = writer
		if f, ok := writer.(*os.File); ok {
			mc.base.logFiles = append(mc.base.logFiles, f)
		}
		return nil
	}
}

func WithHandlerType(ht handlerType) Option {
	return func(mc *modulesConfiguration) error {
		mc.base.handler = ht
		return nil
	}
}

func WithAddSource(addSource bool) Option {
	return func(mc *modulesConfiguration) error {
		mc.base.addSource = addSource
		return nil
	}
}

func WithLevel(level Level) Option {
	return func(mc *modulesConfiguration) error {
		mc.base.level = level
		return nil
	}
}

func WithReplaceAttr(key string, fn func([]string, slog.Attr) slog.Attr) Option {
	return func(mc *modulesConfiguration) error {
		if mc.base.replaceAttrFuncs == nil {
			mc.base.replaceAttrFuncs = make(map[string]func([]string, slog.Attr) slog.Attr)
		}
		mc.base.replaceAttrFuncs[key] = fn
		return nil
	}
}

func WithCustomHandler(h slog.Handler) Option {
	return func(mc *modulesConfiguration) error {
		mc.base.customHandler = h
		mc.base.handler = HANDLER_CUSTOM
		return nil
	}
}

func WithModuleAsync(cfg asyncmod.Config) Option {
	return func(mc *modulesConfiguration) error {
		if err := cfg.Validate(); err != nil {
			return fmt.Errorf("invalid %s configuration: %w", asyncmod.ModuleName, err)
		}

		m := asyncmod.New()

		if err := m.Configure(cfg); err != nil {
			return fmt.Errorf("failed to configure %s: %w", asyncmod.ModuleName, err)
		}

		mc.async = m
		return nil
	}
}

func WithModuleRotate(cfg rotatemod.Config) Option {
	return func(mc *modulesConfiguration) error {
		if err := cfg.Validate(); err != nil {
			return fmt.Errorf("invalid %s configuration: %w", rotatemod.ModuleName, err)
		}

		m, err := rotatemod.New(mc.base.logFiles)
		if err != nil {
			return fmt.Errorf("failed to create %s: %w", rotatemod.ModuleName, err)
		}

		if err := m.Configure(cfg); err != nil {
			return fmt.Errorf("failed to configure %s: %w", rotatemod.ModuleName, err)
		}

		mc.rotate = m
		return nil
	}
}
